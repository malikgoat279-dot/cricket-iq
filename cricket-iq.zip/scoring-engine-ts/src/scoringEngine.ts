import {
  FORMAT_DEFAULTS,
  WICKET_METADATA,
  type BatterInningsStats,
  type BowlerInningsStats,
  type DeliveryInput,
  type EngineActionResult,
  type ExtraType,
  type FallOfWicket,
  type InningsScorecard,
  type MatchEngineConfig,
  type MatchEngineState,
  type MatchFormat,
  type Partnership,
  type RecordedDelivery,
  type WicketType,
} from "./types.ts";

export function formatOvers(legalBalls: number): string {
  const safeBalls = Math.max(0, Math.floor(legalBalls));
  return `${Math.floor(safeBalls / 6)}.${safeBalls % 6}`;
}

export function formatDismissal(
  type: WicketType,
  bowler: string,
  fielder: string
): string {
  const trimmedFielder = fielder.trim();
  switch (type) {
    case "NONE":
      return "not out";
    case "BOWLED":
      return `b ${bowler}`;
    case "CAUGHT":
      return trimmedFielder
        ? `c ${trimmedFielder} b ${bowler}`
        : `c & b ${bowler}`;
    case "LBW":
      return `lbw b ${bowler}`;
    case "RUN_OUT":
      return trimmedFielder ? `run out (${trimmedFielder})` : "run out";
    case "STUMPED":
      return trimmedFielder ? `st ${trimmedFielder} b ${bowler}` : `st b ${bowler}`;
    case "HIT_WICKET":
      return `hit wicket b ${bowler}`;
    case "RETIRED_HURT":
      return "retired hurt";
  }
}

export function formatShortNotation(
  batterRuns: number,
  extraType: ExtraType,
  extraRuns: number,
  wicketType: WicketType
): string {
  if (wicketType === "RETIRED_HURT") return "RH";
  if (wicketType !== "NONE") {
    const total = batterRuns + (extraType !== "NONE" ? extraRuns : 0);
    return total > 0 ? `W+${total}` : "W";
  }
  switch (extraType) {
    case "WIDE":
      return extraRuns > 1 ? `${extraRuns}Wd` : "Wd";
    case "NO_BALL": {
      const total = batterRuns + extraRuns;
      return total > 1 ? `${total}Nb` : "Nb";
    }
    case "BYE":
      return `${extraRuns}B`;
    case "LEG_BYE":
      return `${extraRuns}Lb`;
    case "PENALTY":
      return `${extraRuns}P`;
    case "NONE":
      return String(batterRuns);
  }
}

/**
 * Official Net Run Rate:
 * (Total Runs Scored / Overs Faced) - (Total Runs Conceded / Overs Bowled).
 */
export function calculateNrr(
  runsFor: number,
  ballsFaced: number,
  runsAgainst: number,
  ballsBowled: number
): number {
  const rf = ballsFaced > 0 ? runsFor / (ballsFaced / 6) : 0;
  const ra = ballsBowled > 0 ? runsAgainst / (ballsBowled / 6) : 0;
  return Math.round((rf - ra) * 1000) / 1000;
}

/**
 * Deterministic ball-by-ball cricket scoring engine in TypeScript.
 * Recomputes batting, bowling, extras, partnerships, fall-of-wickets,
 * strike rotation, and match completion invariants directly from delivery history
 * so undo and live synchronization always reconcile identically.
 */
export class CricketScoringEngine {
  readonly format: MatchFormat;
  readonly oversLimit: number;
  readonly playersPerSide: number;
  readonly maxOversPerBowler: number;
  readonly teamAName: string;
  readonly teamBName: string;
  readonly firstBattingTeam: string;
  readonly firstBowlingTeam: string;
  readonly initialStriker: string;
  readonly initialNonStriker: string;
  readonly initialBowler: string;
  readonly secondInningsInitialStriker: string;
  readonly secondInningsInitialNonStriker: string;
  readonly secondInningsInitialBowler: string;

  private deliveries: RecordedDelivery[] = [];
  private currentInningsNumber: 1 | 2 = 1;
  private activeBowlerOverrideInnings1: string | null = null;
  private activeBowlerOverrideInnings2: string | null = null;
  private secStrikerOverride: string | null = null;
  private secNonStrikerOverride: string | null = null;
  private manualInnings1Ended = false;
  private manualInnings2Ended = false;
  private manualSwapsAtSeq = new Set<number>();

  constructor(config: MatchEngineConfig = {}) {
    this.format = config.format ?? "T20";
    const defaults = FORMAT_DEFAULTS[this.format];
    this.oversLimit = config.oversLimit ?? defaults.defaultOvers;
    this.playersPerSide = config.playersPerSide ?? 11;
    this.maxOversPerBowler =
      config.maxOversPerBowler ?? defaults.defaultMaxOversPerBowler;
    this.teamAName = config.teamAName ?? "Home XI";
    this.teamBName = config.teamBName ?? "Away XI";
    this.firstBattingTeam = config.firstBattingTeam ?? this.teamAName;
    this.firstBowlingTeam = config.firstBowlingTeam ?? this.teamBName;
    this.initialStriker = config.initialStriker ?? "Batter 1";
    this.initialNonStriker = config.initialNonStriker ?? "Batter 2";
    this.initialBowler = config.initialBowler ?? "Bowler 1";
    this.secondInningsInitialStriker =
      config.secondInningsInitialStriker ?? "Opener 1";
    this.secondInningsInitialNonStriker =
      config.secondInningsInitialNonStriker ?? "Opener 2";
    this.secondInningsInitialBowler =
      config.secondInningsInitialBowler ?? "Opening Bowler";
  }

  loadDeliveries(
    existing: RecordedDelivery[],
    activeInnings: 1 | 2 = 1
  ): void {
    this.deliveries = [...existing].sort(
      (a, b) => a.sequenceNumber - b.sequenceNumber
    );
    this.currentInningsNumber =
      activeInnings === 2 || this.deliveries.some((d) => d.inningsNumber === 2)
        ? 2
        : 1;
  }

  getState(): MatchEngineState {
    const inn1Deliveries = this.deliveries.filter((d) => d.inningsNumber === 1);
    const inn1 = this.computeInnings({
      inningsNumber: 1,
      battingTeam: this.firstBattingTeam,
      bowlingTeam: this.firstBowlingTeam,
      defaultStriker: this.initialStriker,
      defaultNonStriker: this.initialNonStriker,
      defaultBowler: this.initialBowler,
      bowlerOverride: this.activeBowlerOverrideInnings1,
      targetRuns: 0,
      manuallyEnded: this.manualInnings1Ended,
      list: inn1Deliveries,
    });

    const inn2Deliveries = this.deliveries.filter((d) => d.inningsNumber === 2);
    const target = inn1.totalRuns + 1;
    const inn2 =
      this.currentInningsNumber === 2 || inn2Deliveries.length > 0
        ? this.computeInnings({
            inningsNumber: 2,
            battingTeam: this.firstBowlingTeam,
            bowlingTeam: this.firstBattingTeam,
            defaultStriker: this.secondInningsInitialStriker,
            defaultNonStriker: this.secondInningsInitialNonStriker,
            defaultBowler: this.secondInningsInitialBowler,
            bowlerOverride: this.activeBowlerOverrideInnings2,
            targetRuns: target,
            manuallyEnded: this.manualInnings2Ended,
            list: inn2Deliveries,
          })
        : null;

    const matchCompleted = inn2 !== null && inn2.inningsComplete;
    let winnerTeamName = "";
    let resultSummary = "";

    if (matchCompleted && inn2 !== null) {
      if (inn2.totalRuns >= target) {
        const wicketsRemaining = Math.max(
          1,
          this.playersPerSide - 1 - inn2.wickets
        );
        winnerTeamName = inn2.battingTeamName;
        resultSummary = `${winnerTeamName} won by ${wicketsRemaining} wicket${
          wicketsRemaining === 1 ? "" : "s"
        }`;
      } else if (inn2.totalRuns === inn1.totalRuns) {
        winnerTeamName = "Tie";
        resultSummary = `Match Tied (${inn1.totalRuns} each)`;
      } else {
        const runMargin = inn1.totalRuns - inn2.totalRuns;
        winnerTeamName = inn1.battingTeamName;
        resultSummary = `${winnerTeamName} won by ${runMargin} run${
          runMargin === 1 ? "" : "s"
        }`;
      }
    } else if (inn2 !== null) {
      const needed = Math.max(0, target - inn2.totalRuns);
      const ballsLeft =
        this.format === "TEST"
          ? 540
          : Math.max(0, this.oversLimit * 6 - inn2.legalBalls);
      resultSummary = `${inn2.battingTeamName} need ${needed} run${
        needed === 1 ? "" : "s"
      } from ${ballsLeft} ball${ballsLeft === 1 ? "" : "s"}`;
    } else if (inn1.inningsComplete) {
      resultSummary = `Innings Break • Target ${inn1.totalRuns + 1}`;
    } else {
      resultSummary = `${inn1.battingTeamName} ${inn1.totalRuns}/${inn1.wickets} (${inn1.oversString} ov)`;
    }

    const activeInnings =
      this.currentInningsNumber === 2 && inn2 !== null ? inn2 : inn1;

    return {
      format: this.format,
      oversLimit: this.oversLimit,
      playersPerSide: this.playersPerSide,
      maxOversPerBowler: this.maxOversPerBowler,
      teamAName: this.teamAName,
      teamBName: this.teamBName,
      currentInnings: this.currentInningsNumber,
      innings1: inn1,
      innings2: inn2,
      activeInnings,
      matchCompleted,
      winnerTeamName,
      resultSummary,
      allDeliveries: [...this.deliveries],
    };
  }

  validateDelivery(rawInput: DeliveryInput): string | null {
    const batterRuns = rawInput.batterRuns ?? 0;
    const extraType: ExtraType = rawInput.extraType ?? "NONE";
    const additionalExtraRuns = rawInput.additionalExtraRuns ?? 0;
    const wicketType: WicketType = rawInput.wicketType ?? "NONE";

    const state = this.getState();
    const active = state.activeInnings;
    if (state.matchCompleted) return "Match is already completed.";
    if (active.inningsComplete) return "Current innings is complete.";
    if (active.needsBowlerChange) return "Select a new bowler for the new over.";
    if (active.needsNextBatter) return "Select the incoming batter first.";
    if (!Number.isInteger(batterRuns) || batterRuns < 0 || batterRuns > 12) {
      return "Invalid batter runs.";
    }
    if (
      !Number.isInteger(additionalExtraRuns) ||
      additionalExtraRuns < 0 ||
      additionalExtraRuns > 12
    ) {
      return "Invalid extra runs.";
    }

    if (extraType === "WIDE" && batterRuns > 0) {
      return "Runs cannot be scored off the bat on a Wide ball.";
    }
    if (
      (extraType === "BYE" ||
        extraType === "LEG_BYE" ||
        extraType === "PENALTY") &&
      batterRuns > 0
    ) {
      return "Byes/Leg-Byes/Penalties do not credit batter runs.";
    }
    if (
      extraType === "NO_BALL" &&
      (wicketType === "BOWLED" ||
        wicketType === "CAUGHT" ||
        wicketType === "LBW" ||
        wicketType === "STUMPED" ||
        wicketType === "HIT_WICKET")
    ) {
      return "Only Run Out (or Retired Hurt) is allowed on a No-Ball.";
    }
    if (
      extraType === "WIDE" &&
      (wicketType === "BOWLED" ||
        wicketType === "CAUGHT" ||
        wicketType === "LBW")
    ) {
      return "Batter cannot be Bowled, Caught, or LBW off a Wide.";
    }

    const currentBowlerStats = active.bowlers.find(
      (b) => b.name === active.currentBowlerName
    );
    if (
      this.format !== "TEST" &&
      this.maxOversPerBowler > 0 &&
      currentBowlerStats &&
      currentBowlerStats.completedOvers >= this.maxOversPerBowler
    ) {
      return `${active.currentBowlerName} has reached the max ${this.maxOversPerBowler} overs limit.`;
    }

    return null;
  }

  recordDelivery(rawInput: DeliveryInput): EngineActionResult<RecordedDelivery> {
    const error = this.validateDelivery(rawInput);
    if (error !== null) {
      return { ok: false, error };
    }

    const extraType: ExtraType = rawInput.extraType ?? "NONE";
    const additionalExtraRuns = rawInput.additionalExtraRuns ?? 0;
    const wicketType: WicketType = rawInput.wicketType ?? "NONE";
    const inputBatterRuns = rawInput.batterRuns ?? 0;

    const active = this.getState().activeInnings;
    const legalDelivery =
      extraType === "NONE" || extraType === "BYE" || extraType === "LEG_BYE";

    let extraRuns = 0;
    if (extraType === "WIDE" || extraType === "NO_BALL") {
      extraRuns = 1 + additionalExtraRuns;
    } else if (
      extraType === "BYE" ||
      extraType === "LEG_BYE" ||
      extraType === "PENALTY"
    ) {
      extraRuns = Math.max(1, additionalExtraRuns);
    }

    const batterRuns =
      extraType === "NONE" || extraType === "NO_BALL" ? inputBatterRuns : 0;
    const totalRunsOnBall = batterRuns + extraRuns;
    const overNumber = Math.floor(active.legalBalls / 6);
    const ballNumber = legalDelivery
      ? (active.legalBalls % 6) + 1
      : active.legalBalls % 6;

    const dismissedPlayerName =
      wicketType !== "NONE"
        ? (rawInput.dismissedBatterName?.trim() || active.strikerName)
        : "";

    const maxSeq = this.deliveries.reduce(
      (max, d) => (d.sequenceNumber > max ? d.sequenceNumber : max),
      0
    );

    const recorded: RecordedDelivery = {
      sequenceNumber: maxSeq + 1,
      inningsNumber: this.currentInningsNumber,
      overNumber,
      ballNumber,
      legalDelivery,
      strikerName: active.strikerName,
      nonStrikerName: active.nonStrikerName,
      bowlerName: active.currentBowlerName,
      batterRuns,
      extraType,
      extraRuns,
      totalRunsOnBall,
      wicketType,
      dismissedPlayerName,
      fielderName: rawInput.fielderName?.trim() ?? "",
      nextBatterName: rawInput.nextBatterName?.trim() ?? "",
      shortNotation: formatShortNotation(
        batterRuns,
        extraType,
        extraRuns,
        wicketType
      ),
    };

    this.deliveries.push(recorded);
    if (this.currentInningsNumber === 1) {
      this.activeBowlerOverrideInnings1 = null;
    } else {
      this.activeBowlerOverrideInnings2 = null;
    }

    return { ok: true, value: recorded };
  }

  undoLastDelivery(): RecordedDelivery | null {
    const removed = this.deliveries.pop() ?? null;
    if (!removed) return null;
    this.manualSwapsAtSeq.delete(removed.sequenceNumber);
    if (
      removed.inningsNumber === 1 &&
      this.currentInningsNumber === 2 &&
      !this.deliveries.some((d) => d.inningsNumber === 2)
    ) {
      this.currentInningsNumber = 1;
    }
    return removed;
  }

  setBowler(bowlerName: string): EngineActionResult<void> {
    const trimmed = bowlerName.trim();
    if (!trimmed) {
      return { ok: false, error: "Bowler name required." };
    }
    const active = this.getState().activeInnings;
    if (
      active.legalBalls > 0 &&
      active.legalBalls % 6 === 0 &&
      trimmed === active.lastCompletedOverBowlerName
    ) {
      return {
        ok: false,
        error: `${trimmed} bowled the previous over and cannot bowl consecutive overs.`,
      };
    }
    const bowlerStats = active.bowlers.find((b) => b.name === trimmed);
    if (
      this.format !== "TEST" &&
      this.maxOversPerBowler > 0 &&
      bowlerStats &&
      bowlerStats.completedOvers >= this.maxOversPerBowler
    ) {
      return {
        ok: false,
        error: `${trimmed} has completed max ${this.maxOversPerBowler} overs.`,
      };
    }
    if (this.currentInningsNumber === 1) {
      this.activeBowlerOverrideInnings1 = trimmed;
    } else {
      this.activeBowlerOverrideInnings2 = trimmed;
    }
    return { ok: true, value: undefined };
  }

  toggleStrikeAtCurrentPoint(): void {
    const inningsDeliveries = this.deliveries.filter(
      (d) => d.inningsNumber === this.currentInningsNumber
    );
    const lastSeq =
      inningsDeliveries.length > 0
        ? inningsDeliveries[inningsDeliveries.length - 1].sequenceNumber
        : 0;
    if (this.manualSwapsAtSeq.has(lastSeq)) {
      this.manualSwapsAtSeq.delete(lastSeq);
    } else {
      this.manualSwapsAtSeq.add(lastSeq);
    }
  }

  startSecondInnings(
    striker: string,
    nonStriker: string,
    bowler: string
  ): void {
    this.currentInningsNumber = 2;
    this.secStrikerOverride = striker.trim() || this.secondInningsInitialStriker;
    this.secNonStrikerOverride =
      nonStriker.trim() || this.secondInningsInitialNonStriker;
    this.activeBowlerOverrideInnings2 =
      bowler.trim() || this.secondInningsInitialBowler;
  }

  declareOrEndCurrentInnings(): void {
    if (this.currentInningsNumber === 1) {
      this.manualInnings1Ended = true;
    } else {
      this.manualInnings2Ended = true;
    }
  }

  setNextBatter(batterName: string): EngineActionResult<void> {
    const trimmed = batterName.trim();
    if (!trimmed) {
      return { ok: false, error: "Batter name cannot be blank." };
    }
    const active = this.getState().activeInnings;
    const alreadyUsed = active.batters.some(
      (b) =>
        b.name.toLowerCase() === trimmed.toLowerCase() &&
        !b.retiredHurt &&
        (b.out ||
          b.name === active.strikerName ||
          b.name === active.nonStrikerName)
    );
    if (alreadyUsed) {
      return {
        ok: false,
        error: `${trimmed} is already batting or dismissed.`,
      };
    }

    for (let i = this.deliveries.length - 1; i >= 0; i--) {
      if (this.deliveries[i].inningsNumber === this.currentInningsNumber) {
        this.deliveries[i] = {
          ...this.deliveries[i],
          nextBatterName: trimmed,
        };
        break;
      }
    }
    return { ok: true, value: undefined };
  }

  private computeInnings(params: {
    inningsNumber: 1 | 2;
    battingTeam: string;
    bowlingTeam: string;
    defaultStriker: string;
    defaultNonStriker: string;
    defaultBowler: string;
    bowlerOverride: string | null;
    targetRuns: number;
    manuallyEnded: boolean;
    list: RecordedDelivery[];
  }): InningsScorecard {
    const batterMap = new Map<string, BatterInningsStats>();
    const bowlerMap = new Map<string, BowlerInningsStats>();
    const fowList: FallOfWicket[] = [];
    const partnerships: Partnership[] = [];

    const ensureBatter = (name: string): BatterInningsStats => {
      let existing = batterMap.get(name);
      if (!existing) {
        existing = {
          name,
          runs: 0,
          ballsFaced: 0,
          fours: 0,
          sixes: 0,
          strikeRate: 0,
          out: false,
          retiredHurt: false,
          dismissalText: "not out",
        };
        batterMap.set(name, existing);
      }
      return existing;
    };

    const ensureBowler = (name: string): BowlerInningsStats => {
      let existing = bowlerMap.get(name);
      if (!existing) {
        existing = {
          name,
          legalBalls: 0,
          oversString: "0.0",
          completedOvers: 0,
          maidens: 0,
          runsConceded: 0,
          wickets: 0,
          wides: 0,
          noBalls: 0,
          economy: 0,
        };
        bowlerMap.set(name, existing);
      }
      return existing;
    };

    let striker =
      params.inningsNumber === 2 && this.secStrikerOverride
        ? this.secStrikerOverride
        : params.defaultStriker;
    let nonStriker =
      params.inningsNumber === 2 && this.secNonStrikerOverride
        ? this.secNonStrikerOverride
        : params.defaultNonStriker;
    let currentBowler = params.defaultBowler;
    let lastCompletedOverBowler = "";

    ensureBatter(striker);
    ensureBatter(nonStriker);

    let totalRuns = 0;
    let totalWickets = 0;
    let legalBalls = 0;
    let wides = 0;
    let noBalls = 0;
    let byes = 0;
    let legByes = 0;
    let penalties = 0;

    let partnershipOne = striker;
    let partnershipTwo = nonStriker;
    let partnershipOneRuns = 0;
    let partnershipTwoRuns = 0;
    let partnershipExtras = 0;
    let partnershipRuns = 0;
    let partnershipBalls = 0;

    let currentOverRunsForMaiden = 0;
    let currentOverLegalBalls = 0;
    let needsNextBatter = false;
    let needsBowlerChange = false;

    if (params.inningsNumber === 1 && this.manualSwapsAtSeq.has(0)) {
      [striker, nonStriker] = [nonStriker, striker];
    }

    for (const d of params.list) {
      striker = d.strikerName;
      nonStriker = d.nonStrikerName;
      currentBowler = d.bowlerName;
      needsBowlerChange = false;
      needsNextBatter = false;

      // Sync partnership pair if batters changed (e.g. start or post-swap)
      if (
        (striker !== partnershipOne && striker !== partnershipTwo) ||
        (nonStriker !== partnershipOne && nonStriker !== partnershipTwo)
      ) {
        partnershipOne = striker;
        partnershipTwo = nonStriker;
      }

      const bStats = ensureBatter(striker);
      ensureBatter(nonStriker);
      const bwStats = ensureBowler(currentBowler);

      totalRuns += d.totalRunsOnBall;
      partnershipRuns += d.totalRunsOnBall;
      partnershipExtras += d.extraRuns;
      if (striker === partnershipOne) {
        partnershipOneRuns += d.batterRuns;
      } else if (striker === partnershipTwo) {
        partnershipTwoRuns += d.batterRuns;
      }

      if (d.legalDelivery) {
        legalBalls += 1;
        partnershipBalls += 1;
        currentOverLegalBalls += 1;
      }

      switch (d.extraType) {
        case "WIDE":
          wides += d.extraRuns;
          break;
        case "NO_BALL":
          noBalls += d.extraRuns;
          break;
        case "BYE":
          byes += d.extraRuns;
          break;
        case "LEG_BYE":
          legByes += d.extraRuns;
          break;
        case "PENALTY":
          penalties += d.extraRuns;
          break;
        case "NONE":
          break;
      }

      const ballFacedInc =
        d.extraType !== "WIDE" && d.extraType !== "PENALTY" ? 1 : 0;
      const newRuns = bStats.runs + d.batterRuns;
      const newBallsFaced = bStats.ballsFaced + ballFacedInc;
      batterMap.set(striker, {
        ...bStats,
        runs: newRuns,
        ballsFaced: newBallsFaced,
        fours: bStats.fours + (d.batterRuns === 4 ? 1 : 0),
        sixes: bStats.sixes + (d.batterRuns === 6 ? 1 : 0),
        strikeRate: newBallsFaced > 0 ? (newRuns * 100) / newBallsFaced : 0,
      });

      const runsChargedToBowler =
        d.extraType === "NONE" ||
        d.extraType === "WIDE" ||
        d.extraType === "NO_BALL"
          ? d.batterRuns + d.extraRuns
          : 0;
      currentOverRunsForMaiden += runsChargedToBowler;
      const maidenInc =
        d.legalDelivery &&
        currentOverLegalBalls === 6 &&
        currentOverRunsForMaiden === 0
          ? 1
          : 0;
      const newBowlerBalls = bwStats.legalBalls + (d.legalDelivery ? 1 : 0);
      const newRunsConceded = bwStats.runsConceded + runsChargedToBowler;
      const wicketMeta = WICKET_METADATA[d.wicketType];
      const bowlerWicketInc =
        wicketMeta.countsAsTeamWicket && wicketMeta.creditsBowler ? 1 : 0;

      bowlerMap.set(currentBowler, {
        ...bwStats,
        legalBalls: newBowlerBalls,
        oversString: formatOvers(newBowlerBalls),
        completedOvers: Math.floor(newBowlerBalls / 6),
        maidens: bwStats.maidens + maidenInc,
        runsConceded: newRunsConceded,
        wickets: bwStats.wickets + bowlerWicketInc,
        wides: bwStats.wides + (d.extraType === "WIDE" ? d.extraRuns : 0),
        noBalls: bwStats.noBalls + (d.extraType === "NO_BALL" ? 1 : 0),
        economy:
          newBowlerBalls > 0 ? newRunsConceded / (newBowlerBalls / 6) : 0,
      });

      // Strike rotation due to runs completed on delivery
      let runsCrossed = 0;
      switch (d.extraType) {
        case "NONE":
          runsCrossed = d.batterRuns;
          break;
        case "WIDE":
          runsCrossed = Math.max(0, d.extraRuns - 1);
          break;
        case "NO_BALL":
          runsCrossed = d.batterRuns + Math.max(0, d.extraRuns - 1);
          break;
        case "BYE":
        case "LEG_BYE":
          runsCrossed = d.extraRuns;
          break;
        case "PENALTY":
          runsCrossed = 0;
          break;
      }
      if (runsCrossed % 2 === 1) {
        [striker, nonStriker] = [nonStriker, striker];
      }

      if (d.wicketType !== "NONE") {
        const outName = d.dismissedPlayerName || striker;
        const outStats = ensureBatter(outName);
        const dismissalStr = formatDismissal(
          d.wicketType,
          d.bowlerName,
          d.fielderName
        );
        if (d.wicketType === "RETIRED_HURT") {
          batterMap.set(outName, {
            ...outStats,
            out: false,
            retiredHurt: true,
            dismissalText: "retired hurt",
          });
          // Close the retired-hurt pair stand cleanly if partnership continues with replacement
          partnerships.push({
            wicketNumber: totalWickets + 1,
            batterOne: partnershipOne,
            batterTwo: partnershipTwo,
            batterOneRuns: partnershipOneRuns,
            batterTwoRuns: partnershipTwoRuns,
            extras: partnershipExtras,
            runs: partnershipRuns,
            balls: partnershipBalls,
            active: false,
          });
          partnershipRuns = 0;
          partnershipBalls = 0;
          partnershipOneRuns = 0;
          partnershipTwoRuns = 0;
          partnershipExtras = 0;
        } else {
          totalWickets += 1;
          batterMap.set(outName, {
            ...outStats,
            out: true,
            retiredHurt: false,
            dismissalText: dismissalStr,
          });
          fowList.push({
            wicketNumber: totalWickets,
            score: totalRuns,
            oversString: formatOvers(legalBalls),
            batterName: outName,
            dismissalText: dismissalStr,
          });
          partnerships.push({
            wicketNumber: totalWickets,
            batterOne: partnershipOne,
            batterTwo: partnershipTwo,
            batterOneRuns: partnershipOneRuns,
            batterTwoRuns: partnershipTwoRuns,
            extras: partnershipExtras,
            runs: partnershipRuns,
            balls: partnershipBalls,
            active: false,
          });
          partnershipRuns = 0;
          partnershipBalls = 0;
          partnershipOneRuns = 0;
          partnershipTwoRuns = 0;
          partnershipExtras = 0;
        }

        const allOut = totalWickets >= this.playersPerSide - 1;
        if (!allOut) {
          if (d.nextBatterName) {
            const incoming = d.nextBatterName;
            const prev = ensureBatter(incoming);
            batterMap.set(incoming, {
              ...prev,
              retiredHurt: false,
              out: false,
              dismissalText: "not out",
            });
            if (outName === striker) {
              striker = incoming;
            } else {
              nonStriker = incoming;
            }
            partnershipOne = striker;
            partnershipTwo = nonStriker;
          } else {
            needsNextBatter = true;
          }
        }
      }

      if (d.legalDelivery && legalBalls % 6 === 0) {
        lastCompletedOverBowler = currentBowler;
        currentOverRunsForMaiden = 0;
        currentOverLegalBalls = 0;
        [striker, nonStriker] = [nonStriker, striker];
        needsBowlerChange = true;
      }

      if (this.manualSwapsAtSeq.has(d.sequenceNumber)) {
        [striker, nonStriker] = [nonStriker, striker];
      }
    }

    if (
      params.bowlerOverride !== null &&
      params.bowlerOverride !== lastCompletedOverBowler
    ) {
      currentBowler = params.bowlerOverride;
      needsBowlerChange = false;
      ensureBowler(params.bowlerOverride);
    } else if (bowlerMap.size === 0) {
      ensureBowler(currentBowler);
    }

    const maxLegalBalls =
      this.format === "TEST" ? Number.MAX_SAFE_INTEGER : this.oversLimit * 6;
    const targetReached =
      params.targetRuns > 0 && totalRuns >= params.targetRuns;
    const allOut = totalWickets >= this.playersPerSide - 1;
    const oversFinished = legalBalls >= maxLegalBalls;

    const inningsComplete =
      params.manuallyEnded || targetReached || allOut || oversFinished;
    const completionReason = targetReached
      ? "Target chased"
      : allOut
      ? "All out"
      : oversFinished
      ? "Overs completed"
      : params.manuallyEnded
      ? this.format === "TEST"
        ? "Innings declared"
        : "Innings ended"
      : "";

    if (inningsComplete) {
      needsBowlerChange = false;
      needsNextBatter = false;
    }

    if (partnershipRuns > 0 || partnershipBalls > 0 || !inningsComplete) {
      partnerships.push({
        wicketNumber: totalWickets + 1,
        batterOne: partnershipOne,
        batterTwo: partnershipTwo,
        batterOneRuns: partnershipOneRuns,
        batterTwoRuns: partnershipTwoRuns,
        extras: partnershipExtras,
        runs: partnershipRuns,
        balls: partnershipBalls,
        active: !inningsComplete,
      });
    }

    const currentRunRate =
      legalBalls > 0 ? totalRuns / (legalBalls / 6) : 0;
    let requiredRunRate: number | null = null;
    if (params.targetRuns > 0 && !inningsComplete) {
      const remainingBalls = Math.max(0, maxLegalBalls - legalBalls);
      const runsNeeded = Math.max(0, params.targetRuns - totalRuns);
      requiredRunRate =
        remainingBalls > 0 ? runsNeeded / (remainingBalls / 6) : null;
    }

    const completedOversCount =
      legalBalls > 0 && legalBalls % 6 === 0 && needsBowlerChange
        ? Math.floor(legalBalls / 6) - 1
        : Math.floor(legalBalls / 6);

    const currentOverBalls = params.list.filter(
      (d) => d.overNumber === completedOversCount
    );

    return {
      inningsNumber: params.inningsNumber,
      battingTeamName: params.battingTeam,
      bowlingTeamName: params.bowlingTeam,
      totalRuns,
      wickets: totalWickets,
      legalBalls,
      oversString: formatOvers(legalBalls),
      oversLimit: this.oversLimit,
      targetRuns: params.targetRuns,
      currentRunRate,
      requiredRunRate,
      extras: {
        wides,
        noBalls,
        byes,
        legByes,
        penalties,
        total: wides + noBalls + byes + legByes + penalties,
      },
      batters: Array.from(batterMap.values()),
      bowlers: Array.from(bowlerMap.values()),
      fallOfWickets: fowList,
      partnerships,
      currentOverBalls,
      recentDeliveries: params.list.slice(-12),
      strikerName: striker,
      nonStrikerName: nonStriker,
      currentBowlerName: currentBowler,
      lastCompletedOverBowlerName: lastCompletedOverBowler,
      needsBowlerChange,
      needsNextBatter,
      inningsComplete,
      completionReason,
    };
  }
}
