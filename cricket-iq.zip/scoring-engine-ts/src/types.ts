export type MatchFormat = "T10" | "T20" | "ODI" | "TEST" | "CUSTOM";

export interface FormatDefaults {
  displayName: string;
  defaultOvers: number;
  defaultMaxOversPerBowler: number;
}

export const FORMAT_DEFAULTS: Record<MatchFormat, FormatDefaults> = {
  T10: { displayName: "T10", defaultOvers: 10, defaultMaxOversPerBowler: 2 },
  T20: { displayName: "T20", defaultOvers: 20, defaultMaxOversPerBowler: 4 },
  ODI: { displayName: "ODI", defaultOvers: 50, defaultMaxOversPerBowler: 10 },
  TEST: { displayName: "Test", defaultOvers: 90, defaultMaxOversPerBowler: 90 },
  CUSTOM: { displayName: "Custom", defaultOvers: 15, defaultMaxOversPerBowler: 3 },
};

export type ExtraType =
  | "NONE"
  | "WIDE"
  | "NO_BALL"
  | "BYE"
  | "LEG_BYE"
  | "PENALTY";

export type WicketType =
  | "NONE"
  | "BOWLED"
  | "CAUGHT"
  | "LBW"
  | "RUN_OUT"
  | "STUMPED"
  | "HIT_WICKET"
  | "RETIRED_HURT";

export interface WicketMetadata {
  label: string;
  countsAsTeamWicket: boolean;
  creditsBowler: boolean;
}

export const WICKET_METADATA: Record<WicketType, WicketMetadata> = {
  NONE: { label: "Not Out", countsAsTeamWicket: false, creditsBowler: false },
  BOWLED: { label: "Bowled", countsAsTeamWicket: true, creditsBowler: true },
  CAUGHT: { label: "Caught", countsAsTeamWicket: true, creditsBowler: true },
  LBW: { label: "LBW", countsAsTeamWicket: true, creditsBowler: true },
  RUN_OUT: { label: "Run Out", countsAsTeamWicket: true, creditsBowler: false },
  STUMPED: { label: "Stumped", countsAsTeamWicket: true, creditsBowler: true },
  HIT_WICKET: { label: "Hit Wicket", countsAsTeamWicket: true, creditsBowler: true },
  RETIRED_HURT: { label: "Retired Hurt", countsAsTeamWicket: false, creditsBowler: false },
};

export interface DeliveryInput {
  batterRuns?: number;
  extraType?: ExtraType;
  /**
   * Additional runs on Wide/No-Ball (e.g., 1 wide = additionalExtraRuns: 0;
   * wide + 1 bye = additionalExtraRuns: 1; bye/leg-bye/penalty total extra runs).
   */
  additionalExtraRuns?: number;
  wicketType?: WicketType;
  dismissedBatterName?: string;
  fielderName?: string;
  nextBatterName?: string;
}

export interface RecordedDelivery {
  sequenceNumber: number;
  inningsNumber: 1 | 2;
  overNumber: number;
  ballNumber: number;
  legalDelivery: boolean;
  strikerName: string;
  nonStrikerName: string;
  bowlerName: string;
  batterRuns: number;
  extraType: ExtraType;
  extraRuns: number;
  totalRunsOnBall: number;
  wicketType: WicketType;
  dismissedPlayerName: string;
  fielderName: string;
  nextBatterName: string;
  shortNotation: string;
}

export interface BatterInningsStats {
  name: string;
  runs: number;
  ballsFaced: number;
  fours: number;
  sixes: number;
  strikeRate: number;
  out: boolean;
  retiredHurt: boolean;
  dismissalText: string;
}

export interface BowlerInningsStats {
  name: string;
  legalBalls: number;
  oversString: string;
  completedOvers: number;
  maidens: number;
  runsConceded: number;
  wickets: number;
  wides: number;
  noBalls: number;
  economy: number;
}

export interface FallOfWicket {
  wicketNumber: number;
  score: number;
  oversString: string;
  batterName: string;
  dismissalText: string;
}

export interface Partnership {
  wicketNumber: number;
  batterOne: string;
  batterTwo: string;
  batterOneRuns: number;
  batterTwoRuns: number;
  extras: number;
  runs: number;
  balls: number;
  active: boolean;
}

export interface ExtrasBreakdown {
  wides: number;
  noBalls: number;
  byes: number;
  legByes: number;
  penalties: number;
  total: number;
}

export interface InningsScorecard {
  inningsNumber: 1 | 2;
  battingTeamName: string;
  bowlingTeamName: string;
  totalRuns: number;
  wickets: number;
  legalBalls: number;
  oversString: string;
  oversLimit: number;
  targetRuns: number;
  currentRunRate: number;
  requiredRunRate: number | null;
  extras: ExtrasBreakdown;
  batters: BatterInningsStats[];
  bowlers: BowlerInningsStats[];
  fallOfWickets: FallOfWicket[];
  partnerships: Partnership[];
  currentOverBalls: RecordedDelivery[];
  recentDeliveries: RecordedDelivery[];
  strikerName: string;
  nonStrikerName: string;
  currentBowlerName: string;
  lastCompletedOverBowlerName: string;
  needsBowlerChange: boolean;
  needsNextBatter: boolean;
  inningsComplete: boolean;
  completionReason: string;
}

export interface MatchEngineConfig {
  format?: MatchFormat;
  oversLimit?: number;
  playersPerSide?: number;
  maxOversPerBowler?: number;
  teamAName?: string;
  teamBName?: string;
  firstBattingTeam?: string;
  firstBowlingTeam?: string;
  initialStriker?: string;
  initialNonStriker?: string;
  initialBowler?: string;
  secondInningsInitialStriker?: string;
  secondInningsInitialNonStriker?: string;
  secondInningsInitialBowler?: string;
}

export interface MatchEngineState {
  format: MatchFormat;
  oversLimit: number;
  playersPerSide: number;
  maxOversPerBowler: number;
  teamAName: string;
  teamBName: string;
  currentInnings: 1 | 2;
  innings1: InningsScorecard;
  innings2: InningsScorecard | null;
  activeInnings: InningsScorecard;
  matchCompleted: boolean;
  winnerTeamName: string;
  resultSummary: string;
  allDeliveries: RecordedDelivery[];
}

export type EngineActionResult<T> =
  | { ok: true; value: T }
  | { ok: false; error: string };
