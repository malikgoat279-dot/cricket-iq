import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { CricketScoringEngine, calculateNrr } from "../src/scoringEngine.ts";

describe("CricketScoringEngine (TypeScript)", () => {
  it("calculates runs (0, 1, 2, 3, 4, 6) and rotates strike accurately per ball", () => {
    const engine = new CricketScoringEngine({
      format: "T20",
      initialStriker: "A. Khan",
      initialNonStriker: "R. Patel",
      initialBowler: "J. Smith",
    });

    // Ball 1: Dot ball -> strike stays A. Khan
    let res = engine.recordDelivery({ batterRuns: 0 });
    assert.equal(res.ok, true);
    assert.equal(engine.getState().activeInnings.strikerName, "A. Khan");

    // Ball 2: 1 run -> strike rotates to R. Patel
    res = engine.recordDelivery({ batterRuns: 1 });
    assert.equal(res.ok, true);
    assert.equal(engine.getState().activeInnings.strikerName, "R. Patel");
    assert.equal(engine.getState().activeInnings.nonStrikerName, "A. Khan");

    // Ball 3: 4 runs -> even runs keep R. Patel on strike
    engine.recordDelivery({ batterRuns: 4 });
    assert.equal(engine.getState().activeInnings.strikerName, "R. Patel");

    // Ball 4: 3 runs -> odd runs rotate strike back to A. Khan
    engine.recordDelivery({ batterRuns: 3 });
    assert.equal(engine.getState().activeInnings.strikerName, "A. Khan");

    // Ball 5: 6 runs -> even runs keep A. Khan on strike
    engine.recordDelivery({ batterRuns: 6 });
    const inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 14);
    assert.equal(inn.legalBalls, 5);
    assert.equal(inn.oversString, "0.5");

    const khan = inn.batters.find((b) => b.name === "A. Khan");
    const patel = inn.batters.find((b) => b.name === "R. Patel");
    assert.equal(khan?.runs, 7);
    assert.equal(khan?.sixes, 1);
    assert.equal(khan?.ballsFaced, 3);
    assert.equal(patel?.runs, 7);
    assert.equal(patel?.fours, 1);
    assert.equal(patel?.ballsFaced, 2);
  });

  it("does NOT count no-balls or wides toward over totals and enforces no-ball dismissal laws", () => {
    const engine = new CricketScoringEngine({
      format: "T20",
      initialStriker: "Opener 1",
      initialNonStriker: "Opener 2",
      initialBowler: "Bowler 1",
    });

    // No-ball with 4 off the bat: +5 runs, 0 legal balls, batter gets 4 & 1 ball faced
    const nbFour = engine.recordDelivery({
      batterRuns: 4,
      extraType: "NO_BALL",
    });
    assert.equal(nbFour.ok, true);
    let inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 5);
    assert.equal(inn.legalBalls, 0);
    assert.equal(inn.oversString, "0.0");
    assert.equal(inn.extras.noBalls, 1);
    assert.equal(inn.bowlers[0].runsConceded, 5);
    assert.equal(inn.bowlers[0].noBalls, 1);
    assert.equal(inn.batters[0].runs, 4);
    assert.equal(inn.batters[0].ballsFaced, 1);

    // Wide + 1 bye run (2 wides): 0 legal balls, 0 balls faced, strike rotates
    const wideTwo = engine.recordDelivery({
      extraType: "WIDE",
      additionalExtraRuns: 1,
    });
    assert.equal(wideTwo.ok, true);
    inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 7);
    assert.equal(inn.legalBalls, 0);
    assert.equal(inn.extras.wides, 2);
    assert.equal(inn.strikerName, "Opener 2");
    assert.equal(inn.batters[0].ballsFaced, 1);

    // Cannot be Bowled/Caught/LBW/Stumped/Hit Wicket off a No-Ball
    for (const illegalWicket of [
      "BOWLED",
      "CAUGHT",
      "LBW",
      "STUMPED",
      "HIT_WICKET",
    ] as const) {
      const bad = engine.recordDelivery({
        extraType: "NO_BALL",
        wicketType: illegalWicket,
      });
      assert.equal(bad.ok, false);
    }

    // Run Out IS legal on a No-Ball
    const runOutOnNb = engine.recordDelivery({
      batterRuns: 1,
      extraType: "NO_BALL",
      wicketType: "RUN_OUT",
      dismissedBatterName: "Opener 1",
      fielderName: "Point Fielder",
      nextBatterName: "Number 3",
    });
    assert.equal(runOutOnNb.ok, true);
    inn = engine.getState().activeInnings;
    assert.equal(inn.legalBalls, 0); // Still 0 legal balls in over!
    assert.equal(inn.wickets, 1);
    assert.equal(inn.bowlers[0].wickets, 0); // Run out does not credit bowler

    // Now bowl 6 legal balls to complete the 1st over
    for (let i = 0; i < 6; i++) {
      const ok = engine.recordDelivery({ batterRuns: 0 });
      assert.equal(ok.ok, true);
    }
    inn = engine.getState().activeInnings;
    assert.equal(inn.legalBalls, 6);
    assert.equal(inn.oversString, "1.0");
    assert.equal(inn.needsBowlerChange, true);
    // Over-end rotated strike from Opener 2 to Number 3 (who replaced Opener 1 and had crossed on the NB+1)
    assert.equal(inn.currentOverBalls.length, 9); // 3 extras + 6 legal balls in over 0
  });

  it("rotates strike properly at over-ends (including odd run on 6th ball)", () => {
    const engine = new CricketScoringEngine({
      format: "T10",
      initialStriker: "Batter A",
      initialNonStriker: "Batter B",
      initialBowler: "Bowler 1",
    });

    // Balls 1-5: dots
    for (let i = 0; i < 5; i++) {
      engine.recordDelivery({ batterRuns: 0 });
    }
    assert.equal(engine.getState().activeInnings.strikerName, "Batter A");

    // Ball 6: 1 run -> Batter A crosses to non-striker, then over-end swaps ends back so Batter A stays on strike!
    engine.recordDelivery({ batterRuns: 1 });
    let inn = engine.getState().activeInnings;
    assert.equal(inn.oversString, "1.0");
    assert.equal(inn.strikerName, "Batter A");
    assert.equal(inn.nonStrikerName, "Batter B");
    assert.equal(inn.needsBowlerChange, true);

    // Consecutive over by Bowler 1 is rejected
    const sameBowler = engine.setBowler("Bowler 1");
    assert.equal(sameBowler.ok, false);

    // Select Bowler 2 and bowl 6 dots (maiden over) -> over-end swaps strike to Batter B
    assert.equal(engine.setBowler("Bowler 2").ok, true);
    for (let i = 0; i < 6; i++) {
      engine.recordDelivery({ batterRuns: 0 });
    }
    inn = engine.getState().activeInnings;
    assert.equal(inn.oversString, "2.0");
    assert.equal(inn.strikerName, "Batter B");
    assert.equal(inn.nonStrikerName, "Batter A");
    const bowler2 = inn.bowlers.find((b) => b.name === "Bowler 2");
    assert.equal(bowler2?.maidens, 1);
  });

  it("handles Byes, Leg-Byes, and Penalties without charging bowler runs conceded", () => {
    const engine = new CricketScoringEngine({
      format: "T20",
      initialStriker: "S1",
      initialNonStriker: "S2",
      initialBowler: "B1",
    });

    // 1 Bye -> legal ball, 1 team run, 0 batter runs, 0 bowler runs conceded, strike swaps
    engine.recordDelivery({ extraType: "BYE", additionalExtraRuns: 1 });
    let inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 1);
    assert.equal(inn.legalBalls, 1);
    assert.equal(inn.extras.byes, 1);
    assert.equal(inn.strikerName, "S2");
    assert.equal(inn.bowlers[0].runsConceded, 0);
    assert.equal(inn.batters[0].runs, 0);
    assert.equal(inn.batters[0].ballsFaced, 1);

    // 2 Leg Byes -> legal ball, 2 team runs, 0 bowler runs, strike stays S2
    engine.recordDelivery({ extraType: "LEG_BYE", additionalExtraRuns: 2 });
    inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 3);
    assert.equal(inn.legalBalls, 2);
    assert.equal(inn.extras.legByes, 2);
    assert.equal(inn.strikerName, "S2");
    assert.equal(inn.bowlers[0].runsConceded, 0);

    // 5 Penalty runs -> not a legal ball, 5 team runs, 0 bowler runs
    engine.recordDelivery({ extraType: "PENALTY", additionalExtraRuns: 5 });
    inn = engine.getState().activeInnings;
    assert.equal(inn.totalRuns, 8);
    assert.equal(inn.legalBalls, 2);
    assert.equal(inn.extras.penalties, 5);
    assert.equal(inn.bowlers[0].runsConceded, 0);
  });

  it("tracks partnerships accurately across wickets, extras, and retired hurt", () => {
    const engine = new CricketScoringEngine({
      format: "T20",
      initialStriker: "Virat",
      initialNonStriker: "Rohit",
      initialBowler: "Starc",
    });

    // Opening stand:
    // Virat hits 4 (ball 1)
    engine.recordDelivery({ batterRuns: 4 });
    // Virat takes 1 (ball 2) -> Rohit on strike
    engine.recordDelivery({ batterRuns: 1 });
    // Wide + 0 (1 extra, illegal)
    engine.recordDelivery({ extraType: "WIDE" });
    // Rohit hits 6 (ball 3)
    engine.recordDelivery({ batterRuns: 6 });
    // Rohit caught on ball 4, Gill comes in
    engine.recordDelivery({
      wicketType: "CAUGHT",
      dismissedBatterName: "Rohit",
      fielderName: "Carey",
      nextBatterName: "Gill",
    });

    let inn = engine.getState().activeInnings;
    assert.equal(inn.partnerships.length, 2);
    const p1 = inn.partnerships[0];
    assert.equal(p1.wicketNumber, 1);
    assert.equal(p1.batterOne, "Virat");
    assert.equal(p1.batterTwo, "Rohit");
    assert.equal(p1.batterOneRuns, 5);
    assert.equal(p1.batterTwoRuns, 6);
    assert.equal(p1.extras, 1);
    assert.equal(p1.runs, 12);
    assert.equal(p1.balls, 4);
    assert.equal(p1.active, false);

    // Second stand: Virat & Gill
    // Ball 5: Gill scores 2
    engine.recordDelivery({ batterRuns: 2 });
    // Ball 6: Gill scores 4 -> end of over 1
    engine.recordDelivery({ batterRuns: 4 });

    inn = engine.getState().activeInnings;
    const p2 = inn.partnerships[1];
    assert.equal(p2.wicketNumber, 2);
    assert.equal(p2.runs, 6);
    assert.equal(p2.balls, 2);
    assert.equal(p2.active, true);
    assert.equal(inn.fallOfWickets.length, 1);
    assert.equal(inn.fallOfWickets[0].score, 12);
    assert.equal(inn.fallOfWickets[0].oversString, "0.4");

    // Retired hurt does NOT increment team wickets
    engine.setBowler("Cummins");
    engine.recordDelivery({
      wicketType: "RETIRED_HURT",
      dismissedBatterName: "Virat",
      nextBatterName: "Surya",
    });
    inn = engine.getState().activeInnings;
    assert.equal(inn.wickets, 1);
    assert.equal(
      inn.batters.find((b) => b.name === "Virat")?.retiredHurt,
      true
    );
  });

  it("supports undo delivery reconciliation, 2nd innings chase completion, and NRR", () => {
    const engine = new CricketScoringEngine({
      format: "T10",
      oversLimit: 1,
      maxOversPerBowler: 1,
      teamAName: "Alpha",
      teamBName: "Beta",
      initialStriker: "A1",
      initialNonStriker: "A2",
      initialBowler: "B1",
    });

    // 1st innings: 1 over = 10 runs
    engine.recordDelivery({ batterRuns: 4 });
    engine.recordDelivery({ batterRuns: 6 });
    engine.recordDelivery({ batterRuns: 4 }); // will undo this
    assert.equal(engine.getState().innings1.totalRuns, 14);
    engine.undoLastDelivery();
    assert.equal(engine.getState().innings1.totalRuns, 10);
    assert.equal(engine.getState().innings1.legalBalls, 2);

    for (let i = 0; i < 4; i++) {
      engine.recordDelivery({ batterRuns: 0 });
    }
    assert.equal(engine.getState().innings1.inningsComplete, true);
    assert.equal(engine.getState().innings1.totalRuns, 10);

    // Start 2nd innings: Target is 11
    engine.startSecondInnings("B1_bat", "B2_bat", "A_bowl");
    engine.recordDelivery({ batterRuns: 6 });
    engine.recordDelivery({ batterRuns: 6 });
    const state = engine.getState();
    assert.equal(state.matchCompleted, true);
    assert.equal(state.winnerTeamName, "Beta");
    assert.equal(state.resultSummary, "Beta won by 10 wickets");

    // NRR verification: 120 runs in 20 overs (120 balls) vs 100 conceded in 20 overs = +1.000
    assert.equal(calculateNrr(120, 120, 100, 120), 1.0);
  });
});
