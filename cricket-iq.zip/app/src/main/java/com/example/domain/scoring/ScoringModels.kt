package com.example.domain.scoring

enum class MatchFormat(
    val displayName: String,
    val defaultOvers: Int,
    val defaultMaxOversPerBowler: Int
) {
    T10("T10", 10, 2),
    T20("T20", 20, 4),
    ODI("ODI", 50, 10),
    TEST("Test", 90, 90),
    CUSTOM("Custom", 15, 3);

    companion object {
        fun fromRaw(raw: String): MatchFormat =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: T20
    }
}

enum class ExtraType(val label: String, val shortCode: String) {
    NONE("None", ""),
    WIDE("Wide", "Wd"),
    NO_BALL("No Ball", "Nb"),
    BYE("Bye", "B"),
    LEG_BYE("Leg Bye", "Lb"),
    PENALTY("Penalty", "Pen");

    companion object {
        fun fromRaw(raw: String): ExtraType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: NONE
    }
}

enum class WicketType(val label: String, val countsAsTeamWicket: Boolean, val creditsBowler: Boolean) {
    NONE("Not Out", false, false),
    BOWLED("Bowled", true, true),
    CAUGHT("Caught", true, true),
    LBW("LBW", true, true),
    RUN_OUT("Run Out", true, false),
    STUMPED("Stumped", true, true),
    HIT_WICKET("Hit Wicket", true, true),
    RETIRED_HURT("Retired Hurt", false, false);

    companion object {
        fun fromRaw(raw: String): WicketType =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: NONE
    }
}

data class DeliveryInput(
    val batterRuns: Int = 0,
    val extraType: ExtraType = ExtraType.NONE,
    val additionalExtraRuns: Int = 0,
    val wicketType: WicketType = WicketType.NONE,
    val dismissedBatterName: String? = null,
    val dismissedBatterId: String = "",
    val fielderName: String = "",
    val nextBatterName: String? = null,
    val nextBatterId: String = ""
)

data class RecordedDelivery(
    val sequenceNumber: Int,
    val inningsNumber: Int,
    val overNumber: Int,
    val ballNumber: Int,
    val legalDelivery: Boolean,
    val strikerId: String,
    val strikerName: String,
    val nonStrikerId: String,
    val nonStrikerName: String,
    val bowlerId: String,
    val bowlerName: String,
    val batterRuns: Int,
    val extraType: ExtraType,
    val extraRuns: Int,
    val totalRunsOnBall: Int,
    val wicketType: WicketType,
    val dismissedPlayerId: String,
    val dismissedPlayerName: String,
    val fielderName: String,
    val nextBatterName: String = "",
    val nextBatterId: String = ""
) {
    fun shortNotation(): String {
        val base = when {
            wicketType == WicketType.RETIRED_HURT -> "RH"
            wicketType != WicketType.NONE -> {
                val r = batterRuns + (if (extraType != ExtraType.NONE) extraRuns else 0)
                if (r > 0) "W+$r" else "W"
            }
            extraType == ExtraType.WIDE -> if (extraRuns > 1) "${extraRuns}Wd" else "Wd"
            extraType == ExtraType.NO_BALL -> {
                val total = batterRuns + extraRuns
                if (total > 1) "${total}Nb" else "Nb"
            }
            extraType == ExtraType.BYE -> "${extraRuns}B"
            extraType == ExtraType.LEG_BYE -> "${extraRuns}Lb"
            extraType == ExtraType.PENALTY -> "${extraRuns}P"
            else -> batterRuns.toString()
        }
        return base
    }
}

data class BatterInningsStats(
    val playerId: String,
    val name: String,
    val runs: Int = 0,
    val ballsFaced: Int = 0,
    val fours: Int = 0,
    val sixes: Int = 0,
    val out: Boolean = false,
    val retiredHurt: Boolean = false,
    val dismissalText: String = "not out"
) {
    val strikeRate: Double
        get() = if (ballsFaced > 0) (runs * 100.0) / ballsFaced else 0.0
}

data class BowlerInningsStats(
    val playerId: String,
    val name: String,
    val legalBalls: Int = 0,
    val maidens: Int = 0,
    val runsConceded: Int = 0,
    val wickets: Int = 0,
    val wides: Int = 0,
    val noBalls: Int = 0
) {
    val oversString: String
        get() = "${legalBalls / 6}.${legalBalls % 6}"

    val completedOvers: Int
        get() = legalBalls / 6

    val economy: Double
        get() = if (legalBalls > 0) runsConceded / (legalBalls / 6.0) else 0.0
}

data class FallOfWicket(
    val wicketNumber: Int,
    val score: Int,
    val oversString: String,
    val batterName: String,
    val dismissalText: String
)

data class Partnership(
    val batterOne: String,
    val batterTwo: String,
    val runs: Int,
    val balls: Int,
    val active: Boolean
)

data class ExtrasBreakdown(
    val wides: Int = 0,
    val noBalls: Int = 0,
    val byes: Int = 0,
    val legByes: Int = 0,
    val penalties: Int = 0
) {
    val total: Int get() = wides + noBalls + byes + legByes + penalties
}

data class InningsScorecard(
    val inningsNumber: Int,
    val battingTeamName: String,
    val bowlingTeamName: String,
    val totalRuns: Int,
    val wickets: Int,
    val legalBalls: Int,
    val oversLimit: Int,
    val targetRuns: Int,
    val currentRunRate: Double,
    val requiredRunRate: Double?,
    val extras: ExtrasBreakdown,
    val batters: List<BatterInningsStats>,
    val bowlers: List<BowlerInningsStats>,
    val fallOfWickets: List<FallOfWicket>,
    val partnerships: List<Partnership>,
    val currentOverBalls: List<RecordedDelivery>,
    val recentDeliveries: List<RecordedDelivery>,
    val strikerName: String,
    val nonStrikerName: String,
    val currentBowlerName: String,
    val lastCompletedOverBowlerName: String,
    val needsBowlerChange: Boolean,
    val needsNextBatter: Boolean,
    val inningsComplete: Boolean,
    val completionReason: String
) {
    val oversString: String get() = "${legalBalls / 6}.${legalBalls % 6}"
}

data class MatchEngineState(
    val format: MatchFormat,
    val oversLimit: Int,
    val playersPerSide: Int,
    val maxOversPerBowler: Int,
    val teamAName: String,
    val teamBName: String,
    val currentInnings: Int,
    val innings1: InningsScorecard,
    val innings2: InningsScorecard?,
    val matchCompleted: Boolean,
    val winnerTeamName: String,
    val resultSummary: String,
    val winProbabilityTeamA: Int,
    val allDeliveries: List<RecordedDelivery>
) {
    val activeInnings: InningsScorecard
        get() = if (currentInnings == 2 && innings2 != null) innings2 else innings1
}
