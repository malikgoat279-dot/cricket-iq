package com.example.domain.scoring

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Deterministic ball-by-ball cricket scoring engine.
 * Recomputes all batting, bowling, extras, partnerships, fall-of-wickets,
 * strike rotation, and match completion invariants directly from delivery history
 * so undo and live synchronization always reconcile 100%.
 */
class CricketScoringEngine(
    val format: MatchFormat = MatchFormat.T20,
    val oversLimit: Int = format.defaultOvers,
    val playersPerSide: Int = 11,
    val maxOversPerBowler: Int = format.defaultMaxOversPerBowler,
    val teamAName: String = "Home XI",
    val teamBName: String = "Away XI",
    val firstBattingTeam: String = teamAName,
    val firstBowlingTeam: String = teamBName,
    val initialStriker: String = "Batter 1",
    val initialNonStriker: String = "Batter 2",
    val initialBowler: String = "Bowler 1",
    val secondInningsInitialStriker: String = "Opener 1",
    val secondInningsInitialNonStriker: String = "Opener 2",
    val secondInningsInitialBowler: String = "Opening Bowler"
) {
    private val deliveries = mutableListOf<RecordedDelivery>()
    private var currentInningsNumber: Int = 1
    private var activeBowlerOverrideInnings1: String? = null
    private var activeBowlerOverrideInnings2: String? = null
    private var manualInnings1Ended: Boolean = false
    private var manualInnings2Ended: Boolean = false

    fun loadDeliveries(existing: List<RecordedDelivery>, activeInnings: Int = 1) {
        deliveries.clear()
        deliveries.addAll(existing.sortedBy { it.sequenceNumber })
        currentInningsNumber = if (activeInnings >= 2 || deliveries.any { it.inningsNumber == 2 }) 2 else 1
    }

    fun getState(): MatchEngineState {
        val inn1Deliveries = deliveries.filter { it.inningsNumber == 1 }
        val inn1 = computeInnings(
            inningsNumber = 1,
            battingTeam = firstBattingTeam,
            bowlingTeam = firstBowlingTeam,
            defaultStriker = initialStriker,
            defaultNonStriker = initialNonStriker,
            defaultBowler = initialBowler,
            bowlerOverride = activeBowlerOverrideInnings1,
            targetRuns = 0,
            manuallyEnded = manualInnings1Ended,
            list = inn1Deliveries
        )

        val inn2Deliveries = deliveries.filter { it.inningsNumber == 2 }
        val target = inn1.totalRuns + 1
        val inn2 = if (currentInningsNumber == 2 || inn2Deliveries.isNotEmpty()) {
            computeInnings(
                inningsNumber = 2,
                battingTeam = firstBowlingTeam,
                bowlingTeam = firstBattingTeam,
                defaultStriker = secondInningsInitialStriker,
                defaultNonStriker = secondInningsInitialNonStriker,
                defaultBowler = secondInningsInitialBowler,
                bowlerOverride = activeBowlerOverrideInnings2,
                targetRuns = target,
                manuallyEnded = manualInnings2Ended,
                list = inn2Deliveries
            )
        } else null

        val matchFinished = inn2 != null && inn2.inningsComplete
        var winner = ""
        var summary = ""
        if (matchFinished && inn2 != null) {
            when {
                inn2.totalRuns >= target -> {
                    val wicketsRemaining = max(1, (playersPerSide - 1) - inn2.wickets)
                    winner = inn2.battingTeamName
                    summary = "$winner won by $wicketsRemaining wicket${if (wicketsRemaining == 1) "" else "s"}"
                }
                inn2.totalRuns == inn1.totalRuns -> {
                    winner = "Tie"
                    summary = "Match Tied (${inn1.totalRuns} each)"
                }
                else -> {
                    val runMargin = inn1.totalRuns - inn2.totalRuns
                    winner = inn1.battingTeamName
                    summary = "$winner won by $runMargin run${if (runMargin == 1) "" else "s"}"
                }
            }
        } else if (inn2 != null) {
            val needed = max(0, target - inn2.totalRuns)
            val ballsLeft = if (format == MatchFormat.TEST) 540 else max(0, oversLimit * 6 - inn2.legalBalls)
            summary = "${inn2.battingTeamName} need $needed run${if (needed == 1) "" else "s"} from $ballsLeft ball${if (ballsLeft == 1) "" else "s"}"
        } else if (inn1.inningsComplete) {
            summary = "Innings Break • Target ${inn1.totalRuns + 1}"
        } else {
            summary = "${inn1.battingTeamName} ${inn1.totalRuns}/${inn1.wickets} (${inn1.oversString} ov)"
        }

        val winProbA = estimateWinProbabilityTeamA(inn1, inn2)

        return MatchEngineState(
            format = format,
            oversLimit = oversLimit,
            playersPerSide = playersPerSide,
            maxOversPerBowler = maxOversPerBowler,
            teamAName = teamAName,
            teamBName = teamBName,
            currentInnings = currentInningsNumber,
            innings1 = inn1,
            innings2 = inn2,
            matchCompleted = matchFinished,
            winnerTeamName = winner,
            resultSummary = summary,
            winProbabilityTeamA = winProbA,
            allDeliveries = deliveries.toList()
        )
    }

    fun validateDelivery(input: DeliveryInput): String? {
        val state = getState()
        val active = state.activeInnings
        if (state.matchCompleted) return "Match is already completed."
        if (active.inningsComplete) return "Current innings is complete."
        if (active.needsBowlerChange) return "Select a new bowler for the new over."
        if (active.needsNextBatter) return "Select the incoming batter first."
        if (input.batterRuns < 0 || input.batterRuns > 12) return "Invalid batter runs."
        if (input.additionalExtraRuns < 0 || input.additionalExtraRuns > 12) return "Invalid extra runs."

        // Cricket rule: On Wide, batter cannot score runs off the bat
        if (input.extraType == ExtraType.WIDE && input.batterRuns > 0) {
            return "Runs cannot be scored off the bat on a Wide ball."
        }
        // Cricket rule: On Bye/Leg-Bye/Penalty, batter runs must be 0
        if ((input.extraType == ExtraType.BYE || input.extraType == ExtraType.LEG_BYE || input.extraType == ExtraType.PENALTY) && input.batterRuns > 0) {
            return "Byes/Leg-Byes/Penalties do not credit batter runs."
        }
        // Cricket rule: On a No-Ball, batter cannot be out Bowled, Caught, LBW, Stumped, or Hit Wicket
        if (input.extraType == ExtraType.NO_BALL && input.wicketType in listOf(
                WicketType.BOWLED, WicketType.CAUGHT, WicketType.LBW, WicketType.STUMPED, WicketType.HIT_WICKET
            )
        ) {
            return "Only Run Out (or Retired Hurt) is allowed on a No-Ball."
        }
        // Cricket rule: On a Wide, batter cannot be out Bowled, Caught, LBW
        if (input.extraType == ExtraType.WIDE && input.wicketType in listOf(
                WicketType.BOWLED, WicketType.CAUGHT, WicketType.LBW
            )
        ) {
            return "Batter cannot be Bowled, Caught, or LBW off a Wide."
        }
        // Bowler max overs check
        val currentBowlerStats = active.bowlers.firstOrNull { it.name == active.currentBowlerName }
        if (format != MatchFormat.TEST && maxOversPerBowler > 0 && currentBowlerStats != null &&
            currentBowlerStats.completedOvers >= maxOversPerBowler
        ) {
            return "${active.currentBowlerName} has reached the max $maxOversPerBowler overs limit."
        }
        return null
    }

    fun recordDelivery(input: DeliveryInput): Result<RecordedDelivery> {
        val error = validateDelivery(input)
        if (error != null) return Result.failure(IllegalArgumentException(error))

        val active = getState().activeInnings
        val isLegal = when (input.extraType) {
            ExtraType.WIDE, ExtraType.NO_BALL, ExtraType.PENALTY -> false
            ExtraType.NONE, ExtraType.BYE, ExtraType.LEG_BYE -> true
        }

        val extraRuns = when (input.extraType) {
            ExtraType.NONE -> 0
            ExtraType.WIDE -> 1 + input.additionalExtraRuns
            ExtraType.NO_BALL -> 1 + input.additionalExtraRuns
            ExtraType.BYE, ExtraType.LEG_BYE, ExtraType.PENALTY -> max(1, input.additionalExtraRuns)
        }

        val batterRuns = if (input.extraType == ExtraType.NONE || input.extraType == ExtraType.NO_BALL) {
            input.batterRuns
        } else 0

        val totalOnBall = batterRuns + extraRuns
        val currentOver = active.legalBalls / 6
        val ballInOver = if (isLegal) (active.legalBalls % 6) + 1 else (active.legalBalls % 6)

        val dismissedName = if (input.wicketType != WicketType.NONE) {
            input.dismissedBatterName ?: active.strikerName
        } else ""

        val nextSeq = (deliveries.maxOfOrNull { it.sequenceNumber } ?: 0) + 1
        val recorded = RecordedDelivery(
            sequenceNumber = nextSeq,
            inningsNumber = currentInningsNumber,
            overNumber = currentOver,
            ballNumber = ballInOver,
            legalDelivery = isLegal,
            strikerId = active.strikerName.lowercase().replace(" ", "_"),
            strikerName = active.strikerName,
            nonStrikerId = active.nonStrikerName.lowercase().replace(" ", "_"),
            nonStrikerName = active.nonStrikerName,
            bowlerId = active.currentBowlerName.lowercase().replace(" ", "_"),
            bowlerName = active.currentBowlerName,
            batterRuns = batterRuns,
            extraType = input.extraType,
            extraRuns = extraRuns,
            totalRunsOnBall = totalOnBall,
            wicketType = input.wicketType,
            dismissedPlayerId = dismissedName.lowercase().replace(" ", "_"),
            dismissedPlayerName = dismissedName,
            fielderName = input.fielderName,
            nextBatterName = input.nextBatterName ?: "",
            nextBatterId = input.nextBatterId
        )

        deliveries.add(recorded)
        if (currentInningsNumber == 1) activeBowlerOverrideInnings1 = null else activeBowlerOverrideInnings2 = null
        return Result.success(recorded)
    }

    fun undoLastDelivery(): RecordedDelivery? {
        if (deliveries.isEmpty()) return null
        val removed = deliveries.removeAt(deliveries.lastIndex)
        if (removed.inningsNumber == 1 && currentInningsNumber == 2 && deliveries.none { it.inningsNumber == 2 }) {
            currentInningsNumber = 1
        }
        return removed
    }

    fun setBowler(bowlerName: String): Result<Unit> {
        val trimmed = bowlerName.trim()
        if (trimmed.isBlank()) return Result.failure(IllegalArgumentException("Bowler name required."))
        val active = getState().activeInnings
        if (active.legalBalls % 6 == 0 && active.legalBalls > 0 && trimmed == active.lastCompletedOverBowlerName) {
            return Result.failure(IllegalArgumentException("$trimmed bowled the previous over and cannot bowl consecutive overs."))
        }
        val bowlerStats = active.bowlers.firstOrNull { it.name == trimmed }
        if (format != MatchFormat.TEST && maxOversPerBowler > 0 && bowlerStats != null &&
            bowlerStats.completedOvers >= maxOversPerBowler
        ) {
            return Result.failure(IllegalArgumentException("$trimmed has completed max $maxOversPerBowler overs."))
        }
        if (currentInningsNumber == 1) activeBowlerOverrideInnings1 = trimmed else activeBowlerOverrideInnings2 = trimmed
        return Result.success(Unit)
    }

    fun swapStrikeManually() {
        // Handled cleanly via a lightweight synthetic non-scoring marker or UI swap?
        // Better: swap initial striker/nonStriker if 0 balls bowled, or track manual swap count?
        // Actually, let's check if 0 balls bowled we swap initialStriker/nonStriker, otherwise record a 0-run swap state.
        manualSwapToggle = !manualSwapToggle
    }

    private var manualSwapToggle: Boolean = false
    private val manualSwapsAtSeq = mutableSetOf<Int>()

    fun toggleStrikeAtCurrentPoint() {
        val lastSeq = deliveries.lastOrNull { it.inningsNumber == currentInningsNumber }?.sequenceNumber ?: 0
        if (manualSwapsAtSeq.contains(lastSeq)) {
            manualSwapsAtSeq.remove(lastSeq)
        } else {
            manualSwapsAtSeq.add(lastSeq)
        }
    }

    fun startSecondInnings(
        striker: String,
        nonStriker: String,
        bowler: String
    ) {
        currentInningsNumber = 2
        secStrikerOverride = striker
        secNonStrikerOverride = nonStriker
        activeBowlerOverrideInnings2 = bowler
    }

    private var secStrikerOverride: String? = null
    private var secNonStrikerOverride: String? = null

    fun declareOrEndCurrentInnings() {
        if (currentInningsNumber == 1) manualInnings1Ended = true else manualInnings2Ended = true
    }

    fun setNextBatter(batterName: String): Result<Unit> {
        val trimmed = batterName.trim()
        if (trimmed.isBlank()) return Result.failure(IllegalArgumentException("Batter name cannot be blank."))
        val active = getState().activeInnings
        if (active.batters.any { it.name.equals(trimmed, ignoreCase = true) && !it.retiredHurt && (it.out || it.name == active.strikerName || it.name == active.nonStrikerName) }) {
            return Result.failure(IllegalArgumentException("$trimmed is already batting or dismissed."))
        }
        val idx = deliveries.indexOfLast { it.inningsNumber == currentInningsNumber }
        if (idx >= 0) {
            val last = deliveries[idx]
            deliveries[idx] = last.copy(nextBatterName = trimmed, nextBatterId = trimmed.lowercase().replace(" ", "_"))
        }
        return Result.success(Unit)
    }

    private fun computeInnings(
        inningsNumber: Int,
        battingTeam: String,
        bowlingTeam: String,
        defaultStriker: String,
        defaultNonStriker: String,
        defaultBowler: String,
        bowlerOverride: String?,
        targetRuns: Int,
        manuallyEnded: Boolean,
        list: List<RecordedDelivery>
    ): InningsScorecard {
        val batterMap = linkedMapOf<String, BatterInningsStats>()
        val bowlerMap = linkedMapOf<String, BowlerInningsStats>()
        val fowList = mutableListOf<FallOfWicket>()
        val partnerships = mutableListOf<Partnership>()

        val startStriker = if (inningsNumber == 2 && secStrikerOverride != null) secStrikerOverride!! else defaultStriker
        val startNonStriker = if (inningsNumber == 2 && secNonStrikerOverride != null) secNonStrikerOverride!! else defaultNonStriker

        var striker = startStriker
        var nonStriker = startNonStriker
        var currentBowler = defaultBowler
        var lastCompletedOverBowler = ""

        batterMap[striker] = BatterInningsStats(striker.lowercase().replace(" ", "_"), striker)
        batterMap[nonStriker] = BatterInningsStats(nonStriker.lowercase().replace(" ", "_"), nonStriker)

        var totalRuns = 0
        var totalWickets = 0
        var legalBalls = 0
        var wides = 0
        var noBalls = 0
        var byes = 0
        var legByes = 0
        var penalties = 0

        var partnershipRuns = 0
        var partnershipBalls = 0
        var currentOverRunsForMaiden = 0
        var currentOverLegalBalls = 0
        var needsNextBatter = false
        var needsBowlerChange = false

        // Apply initial manual swap before first delivery if toggled at seq 0
        if (inningsNumber == 1 && manualSwapsAtSeq.contains(0)) {
            val tmp = striker; striker = nonStriker; nonStriker = tmp
        }

        for (d in list) {
            striker = d.strikerName
            nonStriker = d.nonStrikerName
            currentBowler = d.bowlerName
            needsBowlerChange = false
            needsNextBatter = false

            val bStats = batterMap.getOrPut(striker) {
                BatterInningsStats(d.strikerId, striker)
            }
            batterMap.putIfAbsent(nonStriker, BatterInningsStats(d.nonStrikerId, nonStriker))

            val bwStats = bowlerMap.getOrPut(currentBowler) {
                BowlerInningsStats(d.bowlerId, currentBowler)
            }

            // Update totals
            totalRuns += d.totalRunsOnBall
            partnershipRuns += d.totalRunsOnBall
            if (d.legalDelivery) {
                legalBalls += 1
                partnershipBalls += 1
                currentOverLegalBalls += 1
            }

            // Extras accounting
            when (d.extraType) {
                ExtraType.WIDE -> wides += d.extraRuns
                ExtraType.NO_BALL -> noBalls += d.extraRuns
                ExtraType.BYE -> byes += d.extraRuns
                ExtraType.LEG_BYE -> legByes += d.extraRuns
                ExtraType.PENALTY -> penalties += d.extraRuns
                ExtraType.NONE -> Unit
            }

            // Batter stats (wide does not count as ball faced)
            val ballFacedInc = if (d.extraType != ExtraType.WIDE && d.extraType != ExtraType.PENALTY) 1 else 0
            val fourInc = if (d.batterRuns == 4) 1 else 0
            val sixInc = if (d.batterRuns == 6) 1 else 0
            batterMap[striker] = bStats.copy(
                runs = bStats.runs + d.batterRuns,
                ballsFaced = bStats.ballsFaced + ballFacedInc,
                fours = bStats.fours + fourInc,
                sixes = bStats.sixes + sixInc
            )

            // Bowler stats (byes, leg byes, penalties do NOT charge bowler)
            val runsChargedToBowler = when (d.extraType) {
                ExtraType.NONE, ExtraType.WIDE, ExtraType.NO_BALL -> d.batterRuns + d.extraRuns
                ExtraType.BYE, ExtraType.LEG_BYE, ExtraType.PENALTY -> 0
            }
            currentOverRunsForMaiden += runsChargedToBowler
            val maidenInc = if (d.legalDelivery && currentOverLegalBalls == 6 && currentOverRunsForMaiden == 0) 1 else 0
            bowlerMap[currentBowler] = bwStats.copy(
                legalBalls = bwStats.legalBalls + (if (d.legalDelivery) 1 else 0),
                maidens = bwStats.maidens + maidenInc,
                runsConceded = bwStats.runsConceded + runsChargedToBowler,
                wickets = bwStats.wickets + (if (d.wicketType.countsAsTeamWicket && d.wicketType.creditsBowler) 1 else 0),
                wides = bwStats.wides + (if (d.extraType == ExtraType.WIDE) d.extraRuns else 0),
                noBalls = bwStats.noBalls + (if (d.extraType == ExtraType.NO_BALL) 1 else 0)
            )

            // Strike rotation due to runs completed on ball
            val runsCrossed = when (d.extraType) {
                ExtraType.NONE -> d.batterRuns
                ExtraType.WIDE -> max(0, d.extraRuns - 1)
                ExtraType.NO_BALL -> d.batterRuns + max(0, d.extraRuns - 1)
                ExtraType.BYE, ExtraType.LEG_BYE -> d.extraRuns
                ExtraType.PENALTY -> 0
            }
            if (runsCrossed % 2 == 1) {
                val tmp = striker; striker = nonStriker; nonStriker = tmp
            }

            // Wicket processing
            if (d.wicketType != WicketType.NONE) {
                val outName = d.dismissedPlayerName.ifBlank { striker }
                val outStats = batterMap[outName] ?: BatterInningsStats(d.dismissedPlayerId, outName)
                val dismissalStr = formatDismissal(d.wicketType, d.bowlerName, d.fielderName)
                if (d.wicketType == WicketType.RETIRED_HURT) {
                    batterMap[outName] = outStats.copy(
                        out = false,
                        retiredHurt = true,
                        dismissalText = "retired hurt"
                    )
                } else {
                    totalWickets += 1
                    batterMap[outName] = outStats.copy(
                        out = true,
                        retiredHurt = false,
                        dismissalText = dismissalStr
                    )
                    fowList.add(
                        FallOfWicket(
                            wicketNumber = totalWickets,
                            score = totalRuns,
                            oversString = "${legalBalls / 6}.${legalBalls % 6}",
                            batterName = outName,
                            dismissalText = dismissalStr
                        )
                    )
                    partnerships.add(
                        Partnership(
                            batterOne = striker,
                            batterTwo = nonStriker,
                            runs = partnershipRuns,
                            balls = partnershipBalls,
                            active = false
                        )
                    )
                    partnershipRuns = 0
                    partnershipBalls = 0
                }

                val allOut = totalWickets >= (playersPerSide - 1)
                if (!allOut) {
                    if (d.nextBatterName.isNotBlank()) {
                        val incoming = d.nextBatterName
                        batterMap.putIfAbsent(incoming, BatterInningsStats(d.nextBatterId.ifBlank { incoming.lowercase().replace(" ", "_") }, incoming, retiredHurt = false))
                        // Restore retired hurt if returning
                        batterMap[incoming] = batterMap[incoming]!!.copy(retiredHurt = false, out = false, dismissalText = "not out")
                        if (outName == striker) striker = incoming else nonStriker = incoming
                    } else {
                        needsNextBatter = true
                    }
                }
            }

            // End of over check -> strike rotates & prompt bowler change
            if (d.legalDelivery && legalBalls % 6 == 0) {
                lastCompletedOverBowler = currentBowler
                currentOverRunsForMaiden = 0
                currentOverLegalBalls = 0
                val tmp = striker; striker = nonStriker; nonStriker = tmp
                needsBowlerChange = true
            }

            // Manual swap toggled right after this delivery
            if (manualSwapsAtSeq.contains(d.sequenceNumber)) {
                val tmp = striker; striker = nonStriker; nonStriker = tmp
            }
        }

        if (bowlerOverride != null && bowlerOverride != lastCompletedOverBowler) {
            currentBowler = bowlerOverride
            needsBowlerChange = false
            bowlerMap.putIfAbsent(bowlerOverride, BowlerInningsStats(bowlerOverride.lowercase().replace(" ", "_"), bowlerOverride))
        } else if (bowlerMap.isEmpty()) {
            bowlerMap[currentBowler] = BowlerInningsStats(currentBowler.lowercase().replace(" ", "_"), currentBowler)
        }

        val maxLegalBalls = if (format == MatchFormat.TEST) Int.MAX_VALUE else oversLimit * 6
        val targetReached = targetRuns > 0 && totalRuns >= targetRuns
        val allOut = totalWickets >= (playersPerSide - 1)
        val oversFinished = legalBalls >= maxLegalBalls

        val inningsComplete = manuallyEnded || targetReached || allOut || oversFinished
        val completionReason = when {
            targetReached -> "Target chased"
            allOut -> "All out"
            oversFinished -> "Overs completed"
            manuallyEnded -> if (format == MatchFormat.TEST) "Innings declared" else "Innings ended"
            else -> ""
        }
        if (inningsComplete) {
            needsBowlerChange = false
            needsNextBatter = false
        }

        if (partnershipRuns > 0 || partnershipBalls > 0 || !inningsComplete) {
            partnerships.add(
                Partnership(
                    batterOne = striker,
                    batterTwo = nonStriker,
                    runs = partnershipRuns,
                    balls = partnershipBalls,
                    active = !inningsComplete
                )
            )
        }

        val crr = if (legalBalls > 0) totalRuns / (legalBalls / 6.0) else 0.0
        val rrr = if (targetRuns > 0 && !inningsComplete) {
            val remainingBalls = max(0, maxLegalBalls - legalBalls)
            val runsNeeded = max(0, targetRuns - totalRuns)
            if (remainingBalls > 0) runsNeeded / (remainingBalls / 6.0) else null
        } else null

        val completedOversCount = if (legalBalls > 0 && legalBalls % 6 == 0 && needsBowlerChange) {
            (legalBalls / 6) - 1
        } else {
            legalBalls / 6
        }
        val currentOverBalls = list.filter { it.overNumber == completedOversCount }

        return InningsScorecard(
            inningsNumber = inningsNumber,
            battingTeamName = battingTeam,
            bowlingTeamName = bowlingTeam,
            totalRuns = totalRuns,
            wickets = totalWickets,
            legalBalls = legalBalls,
            oversLimit = oversLimit,
            targetRuns = targetRuns,
            currentRunRate = crr,
            requiredRunRate = rrr,
            extras = ExtrasBreakdown(wides, noBalls, byes, legByes, penalties),
            batters = batterMap.values.toList(),
            bowlers = bowlerMap.values.toList(),
            fallOfWickets = fowList,
            partnerships = partnerships,
            currentOverBalls = currentOverBalls,
            recentDeliveries = list.takeLast(12),
            strikerName = striker,
            nonStrikerName = nonStriker,
            currentBowlerName = currentBowler,
            lastCompletedOverBowlerName = lastCompletedOverBowler,
            needsBowlerChange = needsBowlerChange,
            needsNextBatter = needsNextBatter,
            inningsComplete = inningsComplete,
            completionReason = completionReason
        )
    }

    private fun formatDismissal(type: WicketType, bowler: String, fielder: String): String {
        return when (type) {
            WicketType.NONE -> "not out"
            WicketType.BOWLED -> "b $bowler"
            WicketType.CAUGHT -> if (fielder.isNotBlank()) "c $fielder b $bowler" else "c & b $bowler"
            WicketType.LBW -> "lbw b $bowler"
            WicketType.RUN_OUT -> if (fielder.isNotBlank()) "run out ($fielder)" else "run out"
            WicketType.STUMPED -> if (fielder.isNotBlank()) "st $fielder b $bowler" else "st b $bowler"
            WicketType.HIT_WICKET -> "hit wicket b $bowler"
            WicketType.RETIRED_HURT -> "retired hurt"
        }
    }

    /**
     * Heuristic win probability estimate (transparently labelled as an estimate in UI).
     */
    private fun estimateWinProbabilityTeamA(inn1: InningsScorecard, inn2: InningsScorecard?): Int {
        if (inn2 == null) {
            val parRate = when (format) {
                MatchFormat.T10 -> 10.5
                MatchFormat.T20 -> 8.2
                MatchFormat.ODI -> 5.6
                else -> 3.6
            }
            val projected = if (inn1.legalBalls > 6) inn1.currentRunRate * oversLimit else parRate * oversLimit
            val parTotal = parRate * oversLimit
            val diff = projected - parTotal
            val wicketPenalty = inn1.wickets * 3.0
            val probBattingFirst = (50.0 + diff * 0.45 - wicketPenalty).roundToInt().coerceIn(12, 88)
            return if (inn1.battingTeamName == teamAName) probBattingFirst else 100 - probBattingFirst
        }
        val target = inn1.totalRuns + 1
        if (inn2.totalRuns >= target) {
            return if (inn2.battingTeamName == teamAName) 100 else 0
        }
        if (inn2.inningsComplete) {
            return when {
                inn2.totalRuns == inn1.totalRuns -> 50
                inn2.battingTeamName == teamAName -> 0
                else -> 100
            }
        }
        val maxBalls = if (format == MatchFormat.TEST) 540 else max(1, oversLimit * 6)
        val ballsRemaining = max(1, maxBalls - inn2.legalBalls)
        val wicketsRemaining = max(0, (playersPerSide - 1) - inn2.wickets)
        val runsNeeded = max(0, target - inn2.totalRuns)
        val reqRate = runsNeeded / (ballsRemaining / 6.0)
        val crr = if (inn2.legalBalls > 6) inn2.currentRunRate else 7.5
        val rateDiff = crr - reqRate
        val wicketFactor = (wicketsRemaining - 5) * 4.5
        val probChasing = (52.0 + rateDiff * 6.5 + wicketFactor).roundToInt().coerceIn(5, 95)
        return if (inn2.battingTeamName == teamAName) probChasing else 100 - probChasing
    }

    companion object {
        /**
         * Official Net Run Rate: (Total Runs Scored / Overs Faced) - (Total Runs Conceded / Overs Bowled).
         * Note: if a team is bowled out, full quota of overs applies if oversLimit > 0.
         */
        fun calculateNrr(
            runsFor: Int,
            ballsFaced: Int,
            runsAgainst: Int,
            ballsBowled: Int
        ): Double {
            val rf = if (ballsFaced > 0) runsFor / (ballsFaced / 6.0) else 0.0
            val ra = if (ballsBowled > 0) runsAgainst / (ballsBowled / 6.0) else 0.0
            return ((rf - ra) * 1000.0).roundToInt() / 1000.0
        }
    }
}
