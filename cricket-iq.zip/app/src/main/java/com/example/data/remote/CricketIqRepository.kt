package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.CricketMatch
import com.example.data.model.DeliveryRecord
import com.example.data.model.DrsReview
import com.example.data.model.MatchStatus
import com.example.data.model.PlayerProfile
import com.example.data.model.PlayerRole
import com.example.data.model.SubscriptionTier
import com.example.data.model.Team
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.domain.scoring.CricketScoringEngine
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.InningsScorecard
import com.example.domain.scoring.MatchEngineState
import com.example.domain.scoring.MatchFormat
import com.example.domain.scoring.RecordedDelivery
import com.example.domain.scoring.WicketType
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CricketIqRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid?.takeIf { it.isNotBlank() }
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun <T> Flow<T>.wrapStreamError(
        uid: String,
        operationType: OperationType,
        path: String
    ): Flow<T> = this.catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val ex = firestoreError ?: (error as? Exception)
        if (ex != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(ex, operationType, path)
        }
        throw error
    }

    suspend fun ensureUserProfile(): Result<UserProfile> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val profile = snap.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfile(userId = uid)
                Result.success(profile)
            } else {
                val initial = UserProfile(
                    userId = uid,
                    displayName = user.displayName?.take(60)?.ifBlank { "Cricket IQ User" } ?: "Cricket IQ User",
                    email = user.email?.take(120) ?: "",
                    photoUrl = user.photoUrl?.toString()?.take(500),
                    role = UserRole.SCORER.name,
                    clubName = "Independent Club",
                    subscriptionTier = SubscriptionTier.FREE.name,
                    subscriptionMode = "FREE",
                    subscriptionStatus = "ACTIVE"
                )
                docRef.set(initial.toCreateMap()).await()
                Result.success(initial)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        val path = "users/$uid"
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapStreamError(uid, OperationType.GET, path)
        )
    }

    suspend fun updateUserProfile(
        displayName: String,
        role: UserRole,
        clubName: String
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            require(displayName.trim().isNotEmpty()) { "Display name cannot be empty." }
            db.collection("users").document(uid).update(
                mapOf(
                    "displayName" to displayName.trim().take(60),
                    "role" to role.name,
                    "clubName" to clubName.trim().take(80),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateSubscriptionPreview(
        tier: SubscriptionTier,
        status: String = "ACTIVE"
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            val mode = if (tier == SubscriptionTier.FREE) "FREE" else "PREVIEW_SANDBOX"
            db.collection("users").document(uid).update(
                mapOf(
                    "subscriptionTier" to tier.name,
                    "subscriptionMode" to mode,
                    "subscriptionStatus" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeMyMatches(uid: String): Flow<List<CricketMatch>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("matches")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CricketMatch::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .wrapStreamError(uid, OperationType.LIST, "matches")
        )
    }

    fun observePublicSharedMatches(uid: String): Flow<List<CricketMatch>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("matches")
                .whereEqualTo("publicShared", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(CricketMatch::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .wrapStreamError(uid, OperationType.LIST, "matches")
        )
    }

    fun observeMatch(uid: String, matchId: String): Flow<CricketMatch?> = flow {
        if (uid.isBlank() || matchId.isBlank()) throw IllegalStateException("Invalid match query")
        emitAll(
            db.collection("matches").document(matchId)
                .snapshots()
                .map { snap ->
                    if (!snap.exists()) null
                    else snap.toObject(CricketMatch::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .wrapStreamError(uid, OperationType.GET, "matches/$matchId")
        )
    }

    fun observeDeliveries(uid: String, matchId: String): Flow<List<DeliveryRecord>> = flow {
        if (uid.isBlank() || matchId.isBlank()) throw IllegalStateException("Invalid deliveries query")
        emitAll(
            db.collection("matches").document(matchId)
                .collection("deliveries")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DeliveryRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.sequenceNumber }
                }
                .wrapStreamError(uid, OperationType.LIST, "matches/$matchId/deliveries")
        )
    }

    suspend fun fetchPublicDeliveries(matchId: String): Result<List<DeliveryRecord>> {
        return try {
            requireUserId()
            val snap = db.collection("matches").document(matchId)
                .collection("deliveries")
                .whereEqualTo("publicShared", true)
                .get()
                .await()
            val list = snap.toObjects(DeliveryRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { it.sequenceNumber }
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "matches/$matchId/deliveries")
            Result.failure(e)
        }
    }

    suspend fun findSharedMatchByCode(shareCode: String): Result<CricketMatch?> {
        return try {
            requireUserId()
            val clean = shareCode.trim().uppercase()
            require(clean.length in 4..16) { "Invalid match share code." }
            val snap = db.collection("matches")
                .whereEqualTo("publicShared", true)
                .whereEqualTo("shareCode", clean)
                .limit(1)
                .get()
                .await()
            val match = snap.toObjects(CricketMatch::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .firstOrNull()
            Result.success(match)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "matches")
            Result.failure(e)
        }
    }

    suspend fun createMatch(match: CricketMatch): Result<String> {
        var docPath = "matches"
        return try {
            val uid = requireUserId()
            val docRef = db.collection("matches").document()
            docPath = docRef.path
            val prepared = match.copy(
                userId = uid,
                controllerUids = listOf(uid),
                shareCode = match.shareCode.ifBlank { "CIQ" + (100..999).random() }
            )
            docRef.set(prepared.toCreateMap()).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun recordDeliveryAndSyncMatch(
        match: CricketMatch,
        delivery: RecordedDelivery,
        engineState: MatchEngineState
    ): Result<Unit> {
        val matchId = match.id
        var docPath = "matches/$matchId"
        return try {
            val uid = requireUserId()
            require(matchId.isNotBlank()) { "Match ID required." }
            val deliveryId = "seq_${delivery.sequenceNumber}_${System.currentTimeMillis()}"
            val deliveryRef = db.collection("matches").document(matchId)
                .collection("deliveries").document(deliveryId)
            docPath = deliveryRef.path

            val deliveryPayload = DeliveryRecord.createPayload(
                uid = uid,
                controllerUids = match.controllerUids.ifEmpty { listOf(uid) },
                publicShared = match.publicShared,
                matchId = matchId,
                d = delivery
            )
            deliveryRef.set(deliveryPayload).await()
            syncMatchSummaryInternal(matchId, engineState)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun undoLastDeliveryAndSync(
        matchId: String,
        lastDeliveryDocId: String?,
        engineState: MatchEngineState
    ): Result<Unit> {
        return try {
            requireUserId()
            if (!lastDeliveryDocId.isNullOrBlank()) {
                db.collection("matches").document(matchId)
                    .collection("deliveries").document(lastDeliveryDocId)
                    .delete().await()
            }
            syncMatchSummaryInternal(matchId, engineState)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, "matches/$matchId/deliveries")
            Result.failure(e)
        }
    }

    suspend fun syncMatchSummary(matchId: String, engineState: MatchEngineState): Result<Unit> {
        return try {
            requireUserId()
            syncMatchSummaryInternal(matchId, engineState)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "matches/$matchId")
            Result.failure(e)
        }
    }

    private suspend fun syncMatchSummaryInternal(matchId: String, state: MatchEngineState) {
        val active = state.activeInnings
        val newStatus = when {
            state.matchCompleted -> MatchStatus.COMPLETED.name
            state.currentInnings == 1 && state.innings1.inningsComplete -> MatchStatus.INNINGS_BREAK.name
            else -> MatchStatus.LIVE.name
        }
        val summaries = buildList {
            add(inningsToSummaryMap(state.innings1))
            if (state.innings2 != null) add(inningsToSummaryMap(state.innings2))
        }
        val recentLabels = active.recentDeliveries.takeLast(12).map { it.shortNotation() }
        db.collection("matches").document(matchId).update(
            mapOf(
                "status" to newStatus,
                "currentInnings" to state.currentInnings.toLong(),
                "battingTeamName" to active.battingTeamName.take(60),
                "bowlingTeamName" to active.bowlingTeamName.take(60),
                "totalRuns" to active.totalRuns.toLong(),
                "wickets" to active.wickets.coerceIn(0, 10).toLong(),
                "legalBalls" to active.legalBalls.toLong(),
                "targetRuns" to active.targetRuns.toLong(),
                "strikerName" to active.strikerName.take(60),
                "nonStrikerName" to active.nonStrikerName.take(60),
                "bowlerName" to active.currentBowlerName.take(60),
                "recentBalls" to recentLabels,
                "inningsSummaries" to summaries,
                "resultSummary" to state.resultSummary.take(200),
                "winnerTeamName" to state.winnerTeamName.take(60),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    private fun inningsToSummaryMap(inn: InningsScorecard): Map<String, Any> = mapOf(
        "inningsNumber" to inn.inningsNumber.toLong(),
        "battingTeamName" to inn.battingTeamName,
        "bowlingTeamName" to inn.bowlingTeamName,
        "totalRuns" to inn.totalRuns.toLong(),
        "wickets" to inn.wickets.toLong(),
        "legalBalls" to inn.legalBalls.toLong(),
        "oversString" to inn.oversString,
        "extrasTotal" to inn.extras.total.toLong()
    )

    fun observePublicDeliveries(uid: String, matchId: String): Flow<List<DeliveryRecord>> = flow {
        if (uid.isBlank() || matchId.isBlank()) throw IllegalStateException("Invalid deliveries query")
        emitAll(
            db.collection("matches").document(matchId)
                .collection("deliveries")
                .whereEqualTo("publicShared", true)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DeliveryRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.sequenceNumber }
                }
                .wrapStreamError(uid, OperationType.LIST, "matches/$matchId/deliveries")
        )
    }

    suspend fun toggleMatchPublicShare(matchId: String, publicShared: Boolean): Result<Unit> {
        return try {
            val uid = requireUserId()
            db.collection("matches").document(matchId).update(
                mapOf(
                    "publicShared" to publicShared,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val delSnap = db.collection("matches").document(matchId)
                .collection("deliveries")
                .whereEqualTo("userId", uid)
                .get()
                .await()
            if (!delSnap.isEmpty) {
                val batch = db.batch()
                delSnap.documents.forEach { doc ->
                    batch.update(doc.reference, "publicShared", publicShared)
                }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "matches/$matchId")
            Result.failure(e)
        }
    }

    /**
     * Automatically updates matching PlayerProfile career stats after a match finishes.
     */
    suspend fun updatePlayerStatsAfterMatch(
        engineState: MatchEngineState,
        existingPlayers: List<PlayerProfile>
    ): Result<Int> {
        return try {
            val uid = requireUserId()
            val ownedPlayers = existingPlayers.filter { it.userId == uid }
            if (ownedPlayers.isEmpty()) return Result.success(0)

            var updatedCount = 0
            val inningsList = listOfNotNull(engineState.innings1, engineState.innings2)
            for (player in ownedPlayers) {
                var participated = false
                var addRuns = 0L
                var addBallsFaced = 0L
                var addFours = 0L
                var addSixes = 0L
                var addInningsBatted = 0L
                var addNotOuts = 0L
                var newHigh = player.highestScore
                val recent = player.recentScores.toMutableList()

                var addWickets = 0L
                var addBallsBowled = 0L
                var addRunsConceded = 0L
                var bestW = player.bestBowlingWickets
                var bestR = player.bestBowlingRuns

                for (inn in inningsList) {
                    val bat = inn.batters.firstOrNull { it.name.equals(player.name, ignoreCase = true) }
                    if (bat != null && (bat.ballsFaced > 0 || bat.out)) {
                        participated = true
                        addInningsBatted += 1
                        addRuns += bat.runs
                        addBallsFaced += bat.ballsFaced
                        addFours += bat.fours
                        addSixes += bat.sixes
                        if (!bat.out) addNotOuts += 1
                        if (bat.runs > newHigh) newHigh = bat.runs.toLong()
                        recent.add(bat.runs.toLong())
                    }
                    val bowl = inn.bowlers.firstOrNull { it.name.equals(player.name, ignoreCase = true) }
                    if (bowl != null && bowl.legalBalls > 0) {
                        participated = true
                        addWickets += bowl.wickets
                        addBallsBowled += bowl.legalBalls
                        addRunsConceded += bowl.runsConceded
                        if (bowl.wickets > bestW || (bowl.wickets.toLong() == bestW && bowl.runsConceded < bestR)) {
                            bestW = bowl.wickets.toLong()
                            bestR = bowl.runsConceded.toLong()
                        }
                    }
                }
                if (participated) {
                    updatedCount += 1
                    db.collection("players").document(player.id).update(
                        mapOf(
                            "matchesPlayed" to player.matchesPlayed + 1,
                            "inningsBatted" to player.inningsBatted + addInningsBatted,
                            "runs" to player.runs + addRuns,
                            "ballsFaced" to player.ballsFaced + addBallsFaced,
                            "fours" to player.fours + addFours,
                            "sixes" to player.sixes + addSixes,
                            "highestScore" to newHigh,
                            "notOuts" to player.notOuts + addNotOuts,
                            "wickets" to player.wickets + addWickets,
                            "ballsBowled" to player.ballsBowled + addBallsBowled,
                            "runsConceded" to player.runsConceded + addRunsConceded,
                            "bestBowlingWickets" to bestW,
                            "bestBowlingRuns" to bestR,
                            "recentScores" to recent.takeLast(20),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(updatedCount)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "players")
            Result.failure(e)
        }
    }

    fun observeTeams(uid: String): Flow<List<Team>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("teams")
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Team::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .wrapStreamError(uid, OperationType.LIST, "teams")
        )
    }

    suspend fun createTeam(name: String, shortName: String): Result<String> {
        var docPath = "teams"
        return try {
            val uid = requireUserId()
            require(name.trim().isNotEmpty()) { "Team name required." }
            val docRef = db.collection("teams").document()
            docPath = docRef.path
            val team = Team(
                userId = uid,
                controllerUids = listOf(uid),
                memberUids = listOf(uid),
                name = name.trim().take(60),
                shortName = shortName.trim().uppercase().take(8).ifBlank {
                    name.trim().take(3).uppercase()
                },
                inviteCode = "CIQ" + (1000..9999).random()
            )
            docRef.set(team.toCreateMap()).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateTeamLineup(
        teamId: String,
        captainPlayerId: String,
        wicketkeeperPlayerId: String,
        playingXiIds: List<String>,
        substituteIds: List<String>,
        playerIds: List<String>
    ): Result<Unit> {
        return try {
            requireUserId()
            db.collection("teams").document(teamId).update(
                mapOf(
                    "captainPlayerId" to captainPlayerId.take(128),
                    "wicketkeeperPlayerId" to wicketkeeperPlayerId.take(128),
                    "playingXiIds" to playingXiIds.take(11),
                    "substituteIds" to substituteIds.take(10),
                    "playerIds" to playerIds.take(30),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "teams/$teamId")
            Result.failure(e)
        }
    }

    fun observePlayers(uid: String): Flow<List<PlayerProfile>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("players")
                .whereArrayContains("memberUids", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PlayerProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.runs }
                }
                .wrapStreamError(uid, OperationType.LIST, "players")
        )
    }

    suspend fun createPlayer(
        name: String,
        teamId: String,
        teamName: String,
        role: PlayerRole,
        battingStyle: String,
        bowlingStyle: String
    ): Result<String> {
        var docPath = "players"
        return try {
            val uid = requireUserId()
            require(name.trim().isNotEmpty()) { "Player name required." }
            val docRef = db.collection("players").document()
            docPath = docRef.path
            val player = PlayerProfile(
                userId = uid,
                memberUids = listOf(uid),
                name = name.trim().take(60),
                teamId = teamId.take(128),
                teamName = teamName.trim().take(60),
                role = role.name,
                battingStyle = battingStyle.take(40),
                bowlingStyle = bowlingStyle.take(40)
            )
            docRef.set(player.toCreateMap()).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    fun observeTournaments(uid: String): Flow<List<Tournament>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("tournaments")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Tournament::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .wrapStreamError(uid, OperationType.LIST, "tournaments")
        )
    }

    suspend fun createTournament(
        name: String,
        format: MatchFormat,
        oversLimit: Int,
        tournamentType: String,
        teamNames: List<String>
    ): Result<String> {
        var docPath = "tournaments"
        return try {
            val uid = requireUserId()
            val cleanTeams = teamNames.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(20)
            require(cleanTeams.size >= 2) { "At least 2 teams are required for a tournament." }
            val docRef = db.collection("tournaments").document()
            docPath = docRef.path

            val standings = cleanTeams.map { team ->
                mapOf(
                    "teamName" to team,
                    "played" to 0L,
                    "won" to 0L,
                    "lost" to 0L,
                    "tied" to 0L,
                    "points" to 0L,
                    "runsFor" to 0L,
                    "ballsFaced" to 0L,
                    "runsAgainst" to 0L,
                    "ballsBowled" to 0L,
                    "nrr" to 0.0
                )
            }

            val fixtures = mutableListOf<Map<String, Any>>()
            if (tournamentType != "KNOCKOUT") {
                var idx = 1
                for (i in cleanTeams.indices) {
                    for (j in i + 1 until cleanTeams.size) {
                        if (fixtures.size < 34) {
                            fixtures.add(
                                mapOf(
                                    "fixtureId" to "fx_$idx",
                                    "round" to "Group Stage",
                                    "teamAName" to cleanTeams[i],
                                    "teamBName" to cleanTeams[j],
                                    "status" to "SCHEDULED",
                                    "scoreSummary" to "Scheduled",
                                    "winnerName" to ""
                                )
                            )
                            idx++
                        }
                    }
                }
            }
            if (tournamentType != "LEAGUE") {
                if (cleanTeams.size >= 4) {
                    fixtures.add(
                        mapOf(
                            "fixtureId" to "sf_1",
                            "round" to "Semi-Final 1",
                            "teamAName" to cleanTeams[0],
                            "teamBName" to cleanTeams[3],
                            "status" to "SCHEDULED",
                            "scoreSummary" to "1st vs 4th",
                            "winnerName" to ""
                        )
                    )
                    fixtures.add(
                        mapOf(
                            "fixtureId" to "sf_2",
                            "round" to "Semi-Final 2",
                            "teamAName" to cleanTeams[1],
                            "teamBName" to cleanTeams[2],
                            "status" to "SCHEDULED",
                            "scoreSummary" to "2nd vs 3rd",
                            "winnerName" to ""
                        )
                    )
                }
                fixtures.add(
                    mapOf(
                        "fixtureId" to "final",
                        "round" to "Final",
                        "teamAName" to if (cleanTeams.size >= 4) "Winner SF1" else cleanTeams[0],
                        "teamBName" to if (cleanTeams.size >= 4) "Winner SF2" else cleanTeams[1],
                        "status" to "SCHEDULED",
                        "scoreSummary" to "Championship Final",
                        "winnerName" to ""
                    )
                )
            }

            val tournament = Tournament(
                userId = uid,
                controllerUids = listOf(uid),
                publicShared = false,
                name = name.trim().take(80),
                format = format.name,
                oversLimit = oversLimit.toLong(),
                tournamentType = tournamentType,
                teamNames = cleanTeams,
                standings = standings,
                fixtures = fixtures.take(40),
                status = "ACTIVE"
            )
            docRef.set(tournament.toCreateMap()).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun recordTournamentFixtureResult(
        tournament: Tournament,
        fixtureId: String,
        teamAScore: Int,
        teamABalls: Int,
        teamBScore: Int,
        teamBBalls: Int
    ): Result<Unit> {
        return try {
            requireUserId()
            val updatedFixtures = tournament.fixtures.map { fx ->
                if ((fx["fixtureId"] as? String) == fixtureId) {
                    val tA = fx["teamAName"] as? String ?: ""
                    val tB = fx["teamBName"] as? String ?: ""
                    val winner = when {
                        teamAScore > teamBScore -> tA
                        teamBScore > teamAScore -> tB
                        else -> "Tie"
                    }
                    fx.toMutableMap().apply {
                        put("status", "COMPLETED")
                        put("winnerName", winner)
                        put("scoreSummary", "$tA $teamAScore vs $tB $teamBScore")
                    }
                } else fx
            }

            val targetFx = tournament.fixtures.firstOrNull { (it["fixtureId"] as? String) == fixtureId }
            val tAName = targetFx?.get("teamAName") as? String ?: ""
            val tBName = targetFx?.get("teamBName") as? String ?: ""

            val updatedStandings = tournament.standings.map { st ->
                val tName = st["teamName"] as? String ?: ""
                if (tName != tAName && tName != tBName) st
                else {
                    val isA = tName == tAName
                    val myScore = if (isA) teamAScore else teamBScore
                    val myBalls = (if (isA) teamABalls else teamBBalls).coerceAtLeast(1)
                    val oppScore = if (isA) teamBScore else teamAScore
                    val oppBalls = (if (isA) teamBBalls else teamABalls).coerceAtLeast(1)

                    val played = ((st["played"] as? Number)?.toLong() ?: 0L) + 1L
                    val won = ((st["won"] as? Number)?.toLong() ?: 0L) + (if (myScore > oppScore) 1L else 0L)
                    val lost = ((st["lost"] as? Number)?.toLong() ?: 0L) + (if (myScore < oppScore) 1L else 0L)
                    val tied = ((st["tied"] as? Number)?.toLong() ?: 0L) + (if (myScore == oppScore) 1L else 0L)
                    val points = won * 2L + tied
                    val rf = ((st["runsFor"] as? Number)?.toLong() ?: 0L) + myScore
                    val bf = ((st["ballsFaced"] as? Number)?.toLong() ?: 0L) + myBalls
                    val ra = ((st["runsAgainst"] as? Number)?.toLong() ?: 0L) + oppScore
                    val bb = ((st["ballsBowled"] as? Number)?.toLong() ?: 0L) + oppBalls
                    val nrr = CricketScoringEngine.calculateNrr(rf.toInt(), bf.toInt(), ra.toInt(), bb.toInt())

                    mapOf(
                        "teamName" to tName,
                        "played" to played,
                        "won" to won,
                        "lost" to lost,
                        "tied" to tied,
                        "points" to points,
                        "runsFor" to rf,
                        "ballsFaced" to bf,
                        "runsAgainst" to ra,
                        "ballsBowled" to bb,
                        "nrr" to nrr
                    )
                }
            }.sortedWith(
                compareByDescending<Map<String, Any>> { (it["points"] as? Number)?.toLong() ?: 0L }
                    .thenByDescending { (it["nrr"] as? Number)?.toDouble() ?: 0.0 }
            )

            db.collection("tournaments").document(tournament.id).update(
                mapOf(
                    "fixtures" to updatedFixtures,
                    "standings" to updatedStandings,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "tournaments/${tournament.id}")
            Result.failure(e)
        }
    }

    fun observeDrsReviews(uid: String): Flow<List<DrsReview>> = flow {
        if (uid.isBlank()) throw IllegalStateException("Blank UID")
        emitAll(
            db.collection("drs_reviews")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DrsReview::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .wrapStreamError(uid, OperationType.LIST, "drs_reviews")
        )
    }

    suspend fun saveDrsReview(review: DrsReview): Result<String> {
        var docPath = "drs_reviews"
        return try {
            val uid = requireUserId()
            val docRef = if (review.id.isNotBlank()) {
                db.collection("drs_reviews").document(review.id)
            } else {
                db.collection("drs_reviews").document()
            }
            docPath = docRef.path
            if (review.id.isNotBlank()) {
                docRef.update(
                    mapOf(
                        "umpireDecision" to review.umpireDecision,
                        "finalOutcome" to review.finalOutcome,
                        "notes" to review.notes.take(500),
                        "primaryTimestampMs" to review.primaryTimestampMs.coerceAtLeast(0L),
                        "compareTimestampMs" to review.compareTimestampMs.coerceAtLeast(0L),
                        "annotations" to review.annotations.take(30),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                docRef.set(review.copy(userId = uid).toCreateMap()).await()
            }
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    /**
     * Loads clearly-labelled Demonstration Club Data so users can immediately explore
     * live scorecards, NRR tournament tables, and analytics before scoring their own matches.
     */
    suspend fun loadDemoClubData(): Result<Unit> {
        return try {
            val uid = requireUserId()

            val team1Ref = db.collection("teams").document("demo_team_royal_${uid.take(8)}")
            val team2Ref = db.collection("teams").document("demo_team_surrey_${uid.take(8)}")

            val p1Ref = db.collection("players").document("demo_p1_${uid.take(8)}")
            val p2Ref = db.collection("players").document("demo_p2_${uid.take(8)}")
            val p3Ref = db.collection("players").document("demo_p3_${uid.take(8)}")
            val p4Ref = db.collection("players").document("demo_p4_${uid.take(8)}")

            p1Ref.set(
                PlayerProfile(
                    userId = uid, memberUids = listOf(uid), name = "Aarav Sharma (Demo)",
                    teamId = team1Ref.id, teamName = "Metro Kings XI (Demo)", role = PlayerRole.BATTER.name,
                    battingStyle = "Right-hand bat", bowlingStyle = "Right-arm offbreak",
                    matchesPlayed = 18, inningsBatted = 17, runs = 642, ballsFaced = 438,
                    fours = 68, sixes = 24, highestScore = 94, notOuts = 3,
                    wickets = 4, ballsBowled = 60, runsConceded = 71, bestBowlingWickets = 2, bestBowlingRuns = 19,
                    catches = 9, recentScores = listOf(42, 68, 19, 94, 53, 77), demoData = true
                ).toCreateMap()
            ).await()

            p2Ref.set(
                PlayerProfile(
                    userId = uid, memberUids = listOf(uid), name = "Liam Bennett (Demo)",
                    teamId = team1Ref.id, teamName = "Metro Kings XI (Demo)", role = PlayerRole.ALL_ROUNDER.name,
                    battingStyle = "Left-hand bat", bowlingStyle = "Left-arm fast-medium",
                    matchesPlayed = 18, inningsBatted = 15, runs = 385, ballsFaced = 270,
                    fours = 34, sixes = 17, highestScore = 61, notOuts = 4,
                    wickets = 27, ballsBowled = 384, runsConceded = 412, bestBowlingWickets = 4, bestBowlingRuns = 21,
                    catches = 11, recentScores = listOf(28, 44, 61, 12, 39, 51), demoData = true
                ).toCreateMap()
            ).await()

            p3Ref.set(
                PlayerProfile(
                    userId = uid, memberUids = listOf(uid), name = "Zaid Qureshi (Demo)",
                    teamId = team2Ref.id, teamName = "Thames Strikers (Demo)", role = PlayerRole.WICKETKEEPER.name,
                    battingStyle = "Right-hand bat", bowlingStyle = "Does not bowl",
                    matchesPlayed = 16, inningsBatted = 16, runs = 514, ballsFaced = 362,
                    fours = 55, sixes = 15, highestScore = 82, notOuts = 2,
                    catches = 14, stumpings = 7, recentScores = listOf(31, 82, 24, 49, 66, 38), demoData = true
                ).toCreateMap()
            ).await()

            p4Ref.set(
                PlayerProfile(
                    userId = uid, memberUids = listOf(uid), name = "Marcus Cole (Demo)",
                    teamId = team2Ref.id, teamName = "Thames Strikers (Demo)", role = PlayerRole.BOWLER.name,
                    battingStyle = "Right-hand bat", bowlingStyle = "Right-arm fast",
                    matchesPlayed = 16, inningsBatted = 8, runs = 76, ballsFaced = 62,
                    fours = 6, sixes = 3, highestScore = 22, notOuts = 3,
                    wickets = 31, ballsBowled = 360, runsConceded = 378, bestBowlingWickets = 5, bestBowlingRuns = 18,
                    catches = 5, recentScores = listOf(8, 14, 22, 4, 11), demoData = true
                ).toCreateMap()
            ).await()

            team1Ref.set(
                Team(
                    userId = uid, controllerUids = listOf(uid), memberUids = listOf(uid),
                    name = "Metro Kings XI (Demo)", shortName = "MKX",
                    captainPlayerId = p1Ref.id, wicketkeeperPlayerId = p2Ref.id,
                    playingXiIds = listOf(p1Ref.id, p2Ref.id),
                    playerIds = listOf(p1Ref.id, p2Ref.id),
                    inviteCode = "MKX26", matchesPlayed = 18, wins = 13, losses = 5, netRunRate = 1.245,
                    demoData = true
                ).toCreateMap()
            ).await()

            team2Ref.set(
                Team(
                    userId = uid, controllerUids = listOf(uid), memberUids = listOf(uid),
                    name = "Thames Strikers (Demo)", shortName = "THS",
                    captainPlayerId = p3Ref.id, wicketkeeperPlayerId = p3Ref.id,
                    playingXiIds = listOf(p3Ref.id, p4Ref.id),
                    playerIds = listOf(p3Ref.id, p4Ref.id),
                    inviteCode = "THS26", matchesPlayed = 16, wins = 10, losses = 6, netRunRate = 0.680,
                    demoData = true
                ).toCreateMap()
            ).await()

            val matchId = "demo_live_${uid.take(8)}"
            val matchRef = db.collection("matches").document(matchId)
            val engine = CricketScoringEngine(
                format = MatchFormat.T20,
                oversLimit = 20,
                playersPerSide = 11,
                maxOversPerBowler = 4,
                teamAName = "Metro Kings XI (Demo)",
                teamBName = "Thames Strikers (Demo)",
                firstBattingTeam = "Metro Kings XI (Demo)",
                firstBowlingTeam = "Thames Strikers (Demo)",
                initialStriker = "Aarav Sharma (Demo)",
                initialNonStriker = "Liam Bennett (Demo)",
                initialBowler = "Marcus Cole (Demo)"
            )
            val sampleBalls = listOf(
                com.example.domain.scoring.DeliveryInput(batterRuns = 4),
                com.example.domain.scoring.DeliveryInput(batterRuns = 1),
                com.example.domain.scoring.DeliveryInput(extraType = ExtraType.WIDE),
                com.example.domain.scoring.DeliveryInput(batterRuns = 0),
                com.example.domain.scoring.DeliveryInput(batterRuns = 6),
                com.example.domain.scoring.DeliveryInput(batterRuns = 2),
                com.example.domain.scoring.DeliveryInput(batterRuns = 1)
            )
            matchRef.set(
                CricketMatch(
                    userId = uid, controllerUids = listOf(uid), publicShared = false, shareCode = "DEMO20",
                    format = MatchFormat.T20.name, oversLimit = 20, playersPerSide = 11, maxOversPerBowler = 4,
                    teamAId = team1Ref.id, teamAName = "Metro Kings XI (Demo)", teamAShort = "MKX",
                    teamBId = team2Ref.id, teamBName = "Thames Strikers (Demo)", teamBShort = "THS",
                    venue = "Regent's Park Oval (Demo)", status = MatchStatus.LIVE.name,
                    tossWinnerName = "Metro Kings XI (Demo)", tossDecision = "BAT",
                    currentInnings = 1, battingTeamName = "Metro Kings XI (Demo)", bowlingTeamName = "Thames Strikers (Demo)",
                    teamAPlayerNames = listOf("Aarav Sharma (Demo)", "Liam Bennett (Demo)", "Dev Patel", "Noah Grant", "Samir Rao"),
                    teamBPlayerNames = listOf("Marcus Cole (Demo)", "Zaid Qureshi (Demo)", "Owen Bell", "Tariq Ali", "Harry Fox"),
                    demoData = true
                ).toCreateMap()
            ).await()

            for (inp in sampleBalls) {
                val res = engine.recordDelivery(inp)
                val d = res.getOrNull() ?: continue
                matchRef.collection("deliveries").document("demo_seq_${d.sequenceNumber}")
                    .set(DeliveryRecord.createPayload(uid, listOf(uid), false, matchId, d)).await()
            }
            syncMatchSummaryInternal(matchId, engine.getState())

            db.collection("tournaments").document("demo_tour_${uid.take(8)}").set(
                Tournament(
                    userId = uid, controllerUids = listOf(uid), publicShared = false,
                    name = "London Club T20 Cup (Demo)",
                    format = MatchFormat.T20.name, oversLimit = 20, tournamentType = "LEAGUE_KNOCKOUT",
                    teamNames = listOf("Metro Kings XI (Demo)", "Thames Strikers (Demo)", "Camden Royals", "Richmond CC"),
                    standings = listOf(
                        mapOf("teamName" to "Metro Kings XI (Demo)", "played" to 4L, "won" to 3L, "lost" to 1L, "tied" to 0L, "points" to 6L, "runsFor" to 684L, "ballsFaced" to 468L, "runsAgainst" to 612L, "ballsBowled" to 480L, "nrr" to 1.120),
                        mapOf("teamName" to "Thames Strikers (Demo)", "played" to 4L, "won" to 3L, "lost" to 1L, "tied" to 0L, "points" to 6L, "runsFor" to 648L, "ballsFaced" to 480L, "runsAgainst" to 601L, "ballsBowled" to 474L, "nrr" to 0.492),
                        mapOf("teamName" to "Camden Royals", "played" to 4L, "won" to 1L, "lost" to 3L, "tied" to 0L, "points" to 2L, "runsFor" to 590L, "ballsFaced" to 480L, "runsAgainst" to 644L, "ballsBowled" to 468L, "nrr" to -0.881),
                        mapOf("teamName" to "Richmond CC", "played" to 4L, "won" to 1L, "lost" to 3L, "tied" to 0L, "points" to 2L, "runsFor" to 575L, "ballsFaced" to 480L, "runsAgainst" to 640L, "ballsBowled" to 480L, "nrr" to -0.813)
                    ),
                    fixtures = listOf(
                        mapOf("fixtureId" to "fx_1", "round" to "Group Stage", "teamAName" to "Metro Kings XI (Demo)", "teamBName" to "Thames Strikers (Demo)", "status" to "LIVE", "scoreSummary" to "In Progress", "winnerName" to ""),
                        mapOf("fixtureId" to "sf_1", "round" to "Semi-Final 1", "teamAName" to "Metro Kings XI (Demo)", "teamBName" to "Richmond CC", "status" to "SCHEDULED", "scoreSummary" to "Sat 14:00 • Oval 1", "winnerName" to ""),
                        mapOf("fixtureId" to "sf_2", "round" to "Semi-Final 2", "teamAName" to "Thames Strikers (Demo)", "teamBName" to "Camden Royals", "status" to "SCHEDULED", "scoreSummary" to "Sun 14:00 • Oval 2", "winnerName" to ""),
                        mapOf("fixtureId" to "final", "round" to "Final", "teamAName" to "Winner SF1", "teamBName" to "Winner SF2", "status" to "SCHEDULED", "scoreSummary" to "Championship Final", "winnerName" to "")
                    ),
                    status = "ACTIVE", demoData = true
                ).toCreateMap()
            ).await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "demo_seed")
            Result.failure(e)
        }
    }
}
