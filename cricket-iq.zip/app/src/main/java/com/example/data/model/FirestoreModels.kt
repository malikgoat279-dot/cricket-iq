package com.example.data.model

import androidx.annotation.Keep
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.MatchFormat
import com.example.domain.scoring.RecordedDelivery
import com.example.domain.scoring.WicketType
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class UserRole(val label: String, val description: String) {
    PLAYER("Individual Player", "Track personal stats, form & match history"),
    SCORER("Official Scorer", "Score matches ball-by-ball & sync live centres"),
    CAPTAIN("Team Captain", "Manage Playing XI, toss & match tactics"),
    CLUB_ADMIN("Club Administrator", "Manage squads, analytics & club subscriptions"),
    TOURNAMENT_ADMIN("Tournament Admin", "Organise leagues, knockouts & NRR tables");

    companion object {
        fun fromRaw(raw: String): UserRole =
            entries.firstOrNull { it.name == raw } ?: PLAYER
    }
}

enum class SubscriptionTier(
    val title: String,
    val priceLabel: String,
    val tagline: String,
    val features: List<String>
) {
    FREE(
        title = "Free",
        priceLabel = "£0 / month",
        tagline = "Essential match-day scoring",
        features = listOf(
            "Basic ball-by-ball scoring (T10, T20, ODI, Test)",
            "Up to 5 recent matches in personal view",
            "Basic player statistics & 1 active team",
            "Live Match Centre sharing link"
        )
    ),
    PREMIUM_PLAYER(
        title = "Premium Player",
        priceLabel = "£1.99 / month",
        tagline = "For ambitious club & league players",
        features = listOf(
            "Unlimited personal match history",
            "Advanced player analytics & form graphs",
            "Side-by-side batting & bowling comparisons",
            "Detailed season & career reports"
        )
    ),
    CLUB_PRO(
        title = "Club Pro",
        priceLabel = "£3.99 / month",
        tagline = "Complete club & tournament suite",
        features = listOf(
            "Unlimited teams & squad role management",
            "Smart DRS manual video review studio",
            "Full tournament, league & knockout NRR engine",
            "Exportable scorecards (Text & CSV) + advanced club analytics"
        )
    );

    companion object {
        fun fromRaw(raw: String): SubscriptionTier =
            entries.firstOrNull { it.name == raw } ?: FREE
    }
}

enum class PlayerRole(val label: String) {
    BATTER("Batter"),
    BOWLER("Bowler"),
    ALL_ROUNDER("All-Rounder"),
    WICKETKEEPER("Wicketkeeper");

    companion object {
        fun fromRaw(raw: String): PlayerRole =
            entries.firstOrNull { it.name == raw } ?: ALL_ROUNDER
    }
}

enum class MatchStatus(val label: String) {
    UPCOMING("Upcoming"),
    LIVE("Live"),
    INNINGS_BREAK("Innings Break"),
    COMPLETED("Completed");

    companion object {
        fun fromRaw(raw: String): MatchStatus =
            entries.firstOrNull { it.name == raw } ?: LIVE
    }
}

enum class DrsCategory(val label: String) {
    LBW("LBW"),
    CAUGHT("Caught Behind / Catch"),
    RUN_OUT("Run Out"),
    STUMPED("Stumping"),
    BOUNDARY("Boundary Check");

    companion object {
        fun fromRaw(raw: String): DrsCategory =
            entries.firstOrNull { it.name == raw } ?: LBW
    }
}

enum class UmpireDecision(val label: String) {
    OUT("Out"),
    NOT_OUT("Not Out"),
    BOUNDARY_4("Boundary (4)"),
    BOUNDARY_6("Six (6)"),
    SHORT_RUN("Short Run");

    companion object {
        fun fromRaw(raw: String): UmpireDecision =
            entries.firstOrNull { it.name == raw } ?: NOT_OUT
    }
}

enum class DrsOutcome(val label: String) {
    PENDING("Pending Review"),
    UPHELD("Original Decision Upheld"),
    OVERTURNED("Decision Overturned"),
    UMPIRES_CALL("Umpire's Call"),
    INCONCLUSIVE("Inconclusive Footage");

    companion object {
        fun fromRaw(raw: String): DrsOutcome =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val role: String = UserRole.SCORER.name,
    val clubName: String = "",
    val subscriptionTier: String = SubscriptionTier.FREE.name,
    val subscriptionMode: String = "FREE",
    val subscriptionStatus: String = "ACTIVE",
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    val parsedRole: UserRole get() = UserRole.fromRaw(role)
    val parsedTier: SubscriptionTier get() = SubscriptionTier.fromRaw(subscriptionTier)

    fun toCreateMap(): Map<String, Any> {
        val raw = mutableMapOf<String, Any?>(
            "userId" to userId,
            "displayName" to displayName.take(60).ifBlank { "Cricket IQ Player" },
            "email" to email.take(120),
            "photoUrl" to photoUrl?.take(500),
            "role" to UserRole.fromRaw(role).name,
            "clubName" to clubName.take(80),
            "subscriptionTier" to SubscriptionTier.fromRaw(subscriptionTier).name,
            "subscriptionMode" to if (subscriptionMode == "PREVIEW_SANDBOX") "PREVIEW_SANDBOX" else "FREE",
            "subscriptionStatus" to subscriptionStatus.ifBlank { "ACTIVE" },
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        @Suppress("UNCHECKED_CAST")
        return raw.filterValues { it != null } as Map<String, Any>
    }
}

typealias ServerTimestampCompat = com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class PlayerProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val memberUids: List<String> = emptyList(),
    val name: String = "",
    val teamId: String = "",
    val teamName: String = "",
    val role: String = PlayerRole.ALL_ROUNDER.name,
    val battingStyle: String = "Right-hand bat",
    val bowlingStyle: String = "Right-arm medium",
    val matchesPlayed: Long = 0L,
    val inningsBatted: Long = 0L,
    val runs: Long = 0L,
    val ballsFaced: Long = 0L,
    val fours: Long = 0L,
    val sixes: Long = 0L,
    val highestScore: Long = 0L,
    val notOuts: Long = 0L,
    val wickets: Long = 0L,
    val ballsBowled: Long = 0L,
    val runsConceded: Long = 0L,
    val bestBowlingWickets: Long = 0L,
    val bestBowlingRuns: Long = 0L,
    val catches: Long = 0L,
    val stumpings: Long = 0L,
    val recentScores: List<Long> = emptyList(),
    val demoData: Boolean = false,
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    val parsedRole: PlayerRole get() = PlayerRole.fromRaw(role)

    val battingAverage: Double
        get() {
            val dismissals = (inningsBatted - notOuts).coerceAtLeast(0L)
            return if (dismissals > 0) runs.toDouble() / dismissals else runs.toDouble()
        }

    val battingStrikeRate: Double
        get() = if (ballsFaced > 0) (runs * 100.0) / ballsFaced else 0.0

    val bowlingEconomy: Double
        get() = if (ballsBowled > 0) runsConceded / (ballsBowled / 6.0) else 0.0

    val bestBowlingDisplay: String
        get() = if (bestBowlingWickets == 0L && bestBowlingRuns == 0L) "-" else "$bestBowlingWickets/$bestBowlingRuns"

    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "memberUids" to memberUids.ifEmpty { listOf(userId) }.take(50),
        "name" to name.take(60).ifBlank { "Unnamed Player" },
        "teamId" to teamId.take(128),
        "teamName" to teamName.take(60),
        "role" to PlayerRole.fromRaw(role).name,
        "battingStyle" to battingStyle.take(40),
        "bowlingStyle" to bowlingStyle.take(40),
        "matchesPlayed" to matchesPlayed.coerceAtLeast(0L),
        "inningsBatted" to inningsBatted.coerceAtLeast(0L),
        "runs" to runs.coerceAtLeast(0L),
        "ballsFaced" to ballsFaced.coerceAtLeast(0L),
        "fours" to fours.coerceAtLeast(0L),
        "sixes" to sixes.coerceAtLeast(0L),
        "highestScore" to highestScore.coerceAtLeast(0L),
        "notOuts" to notOuts.coerceAtLeast(0L),
        "wickets" to wickets.coerceAtLeast(0L),
        "ballsBowled" to ballsBowled.coerceAtLeast(0L),
        "runsConceded" to runsConceded.coerceAtLeast(0L),
        "bestBowlingWickets" to bestBowlingWickets.coerceAtLeast(0L),
        "bestBowlingRuns" to bestBowlingRuns.coerceAtLeast(0L),
        "catches" to catches.coerceAtLeast(0L),
        "stumpings" to stumpings.coerceAtLeast(0L),
        "recentScores" to recentScores.takeLast(20),
        "demoData" to demoData,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class Team(
    @DocumentId val id: String = "",
    val userId: String = "",
    val controllerUids: List<String> = emptyList(),
    val memberUids: List<String> = emptyList(),
    val name: String = "",
    val shortName: String = "",
    val captainPlayerId: String = "",
    val wicketkeeperPlayerId: String = "",
    val playingXiIds: List<String> = emptyList(),
    val substituteIds: List<String> = emptyList(),
    val playerIds: List<String> = emptyList(),
    val inviteCode: String = "CIQ100",
    val matchesPlayed: Long = 0L,
    val wins: Long = 0L,
    val losses: Long = 0L,
    val ties: Long = 0L,
    val netRunRate: Double = 0.0,
    val demoData: Boolean = false,
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "controllerUids" to controllerUids.ifEmpty { listOf(userId) }.take(20),
        "memberUids" to memberUids.ifEmpty { listOf(userId) }.take(50),
        "name" to name.take(60).ifBlank { "Club XI" },
        "shortName" to shortName.take(8).ifBlank { "CLB" },
        "captainPlayerId" to captainPlayerId.take(128),
        "wicketkeeperPlayerId" to wicketkeeperPlayerId.take(128),
        "playingXiIds" to playingXiIds.take(11),
        "substituteIds" to substituteIds.take(10),
        "playerIds" to playerIds.take(30),
        "inviteCode" to inviteCode.take(16).ifBlank { "CIQ100" },
        "matchesPlayed" to matchesPlayed.coerceAtLeast(0L),
        "wins" to wins.coerceAtLeast(0L),
        "losses" to losses.coerceAtLeast(0L),
        "ties" to ties.coerceAtLeast(0L),
        "netRunRate" to netRunRate,
        "demoData" to demoData,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class CricketMatch(
    @DocumentId val id: String = "",
    val userId: String = "",
    val controllerUids: List<String> = emptyList(),
    val publicShared: Boolean = false,
    val shareCode: String = "",
    val format: String = MatchFormat.T20.name,
    val oversLimit: Long = 20L,
    val playersPerSide: Long = 11L,
    val maxOversPerBowler: Long = 4L,
    val teamAId: String = "",
    val teamAName: String = "",
    val teamAShort: String = "",
    val teamBId: String = "",
    val teamBName: String = "",
    val teamBShort: String = "",
    val venue: String = "",
    val status: String = MatchStatus.LIVE.name,
    val tossWinnerName: String = "",
    val tossDecision: String = "BAT",
    val currentInnings: Long = 1L,
    val battingTeamName: String = "",
    val bowlingTeamName: String = "",
    val totalRuns: Long = 0L,
    val wickets: Long = 0L,
    val legalBalls: Long = 0L,
    val targetRuns: Long = 0L,
    val strikerName: String = "",
    val nonStrikerName: String = "",
    val bowlerName: String = "",
    val recentBalls: List<String> = emptyList(),
    val inningsSummaries: List<Map<String, Any>> = emptyList(),
    val resultSummary: String = "",
    val winnerTeamName: String = "",
    val teamAPlayerNames: List<String> = emptyList(),
    val teamBPlayerNames: List<String> = emptyList(),
    val demoData: Boolean = false,
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    val parsedFormat: MatchFormat get() = MatchFormat.fromRaw(format)
    val parsedStatus: MatchStatus get() = MatchStatus.fromRaw(status)
    val oversString: String get() = "${legalBalls / 6}.${legalBalls % 6}"
    val currentRunRate: Double get() = if (legalBalls > 0) totalRuns / (legalBalls / 6.0) else 0.0

    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "controllerUids" to controllerUids.ifEmpty { listOf(userId) }.take(10),
        "publicShared" to publicShared,
        "shareCode" to shareCode.take(16).ifBlank { "CIQ000" },
        "format" to MatchFormat.fromRaw(format).name,
        "oversLimit" to oversLimit.coerceIn(0L, 450L),
        "playersPerSide" to playersPerSide.coerceIn(2L, 11L),
        "maxOversPerBowler" to maxOversPerBowler.coerceIn(0L, 100L),
        "teamAId" to teamAId.take(128),
        "teamAName" to teamAName.take(60).ifBlank { "Team A" },
        "teamAShort" to teamAShort.take(8).ifBlank { "TMA" },
        "teamBId" to teamBId.take(128),
        "teamBName" to teamBName.take(60).ifBlank { "Team B" },
        "teamBShort" to teamBShort.take(8).ifBlank { "TMB" },
        "venue" to venue.take(100),
        "status" to MatchStatus.fromRaw(status).name,
        "tossWinnerName" to tossWinnerName.take(60),
        "tossDecision" to if (tossDecision == "BOWL") "BOWL" else "BAT",
        "currentInnings" to currentInnings.coerceIn(1L, 4L),
        "battingTeamName" to battingTeamName.take(60).ifBlank { teamAName.ifBlank { "Team A" } },
        "bowlingTeamName" to bowlingTeamName.take(60).ifBlank { teamBName.ifBlank { "Team B" } },
        "totalRuns" to totalRuns.coerceAtLeast(0L),
        "wickets" to wickets.coerceIn(0L, 10L),
        "legalBalls" to legalBalls.coerceAtLeast(0L),
        "targetRuns" to targetRuns.coerceAtLeast(0L),
        "strikerName" to strikerName.take(60),
        "nonStrikerName" to nonStrikerName.take(60),
        "bowlerName" to bowlerName.take(60),
        "recentBalls" to recentBalls.takeLast(18),
        "inningsSummaries" to inningsSummaries.take(4),
        "resultSummary" to resultSummary.take(200),
        "winnerTeamName" to winnerTeamName.take(60),
        "teamAPlayerNames" to teamAPlayerNames.take(15),
        "teamBPlayerNames" to teamBPlayerNames.take(15),
        "demoData" to demoData,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

@Keep
@IgnoreExtraProperties
data class DeliveryRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val controllerUids: List<String> = emptyList(),
    val publicShared: Boolean = false,
    val matchId: String = "",
    val sequenceNumber: Long = 0L,
    val inningsNumber: Long = 1L,
    val overNumber: Long = 0L,
    val ballNumber: Long = 0L,
    val legalDelivery: Boolean = true,
    val strikerId: String = "",
    val strikerName: String = "",
    val nonStrikerId: String = "",
    val nonStrikerName: String = "",
    val bowlerId: String = "",
    val bowlerName: String = "",
    val batterRuns: Long = 0L,
    val extraType: String = ExtraType.NONE.name,
    val extraRuns: Long = 0L,
    val totalRunsOnBall: Long = 0L,
    val wicketType: String = WicketType.NONE.name,
    val dismissedPlayerId: String = "",
    val dismissedPlayerName: String = "",
    val fielderName: String = "",
    val nextBatterName: String = "",
    @ServerTimestampCompat val createdAt: Timestamp? = null
) {
    fun toDomain(): RecordedDelivery = RecordedDelivery(
        sequenceNumber = sequenceNumber.toInt(),
        inningsNumber = inningsNumber.toInt(),
        overNumber = overNumber.toInt(),
        ballNumber = ballNumber.toInt(),
        legalDelivery = legalDelivery,
        strikerId = strikerId,
        strikerName = strikerName,
        nonStrikerId = nonStrikerId,
        nonStrikerName = nonStrikerName,
        bowlerId = bowlerId,
        bowlerName = bowlerName,
        batterRuns = batterRuns.toInt(),
        extraType = ExtraType.fromRaw(extraType),
        extraRuns = extraRuns.toInt(),
        totalRunsOnBall = totalRunsOnBall.toInt(),
        wicketType = WicketType.fromRaw(wicketType),
        dismissedPlayerId = dismissedPlayerId,
        dismissedPlayerName = dismissedPlayerName,
        fielderName = fielderName,
        nextBatterName = nextBatterName
    )

    companion object {
        fun createPayload(
            uid: String,
            controllerUids: List<String>,
            publicShared: Boolean,
            matchId: String,
            d: RecordedDelivery
        ): Map<String, Any> = mapOf(
            "userId" to uid,
            "controllerUids" to controllerUids.ifEmpty { listOf(uid) }.take(10),
            "publicShared" to publicShared,
            "matchId" to matchId,
            "sequenceNumber" to d.sequenceNumber.toLong(),
            "inningsNumber" to d.inningsNumber.toLong(),
            "overNumber" to d.overNumber.toLong(),
            "ballNumber" to d.ballNumber.coerceIn(0, 6).toLong(),
            "legalDelivery" to d.legalDelivery,
            "strikerId" to d.strikerId.take(128),
            "strikerName" to d.strikerName.take(60).ifBlank { "Striker" },
            "nonStrikerId" to d.nonStrikerId.take(128),
            "nonStrikerName" to d.nonStrikerName.take(60).ifBlank { "Non-Striker" },
            "bowlerId" to d.bowlerId.take(128),
            "bowlerName" to d.bowlerName.take(60).ifBlank { "Bowler" },
            "batterRuns" to d.batterRuns.coerceIn(0, 12).toLong(),
            "extraType" to d.extraType.name,
            "extraRuns" to d.extraRuns.coerceIn(0, 20).toLong(),
            "totalRunsOnBall" to d.totalRunsOnBall.coerceIn(0, 25).toLong(),
            "wicketType" to d.wicketType.name,
            "dismissedPlayerId" to d.dismissedPlayerId.take(128),
            "dismissedPlayerName" to d.dismissedPlayerName.take(60),
            "fielderName" to d.fielderName.take(60),
            "createdAt" to FieldValue.serverTimestamp()
        )
    }
}

@Keep
@IgnoreExtraProperties
data class Tournament(
    @DocumentId val id: String = "",
    val userId: String = "",
    val controllerUids: List<String> = emptyList(),
    val publicShared: Boolean = false,
    val name: String = "",
    val format: String = MatchFormat.T20.name,
    val oversLimit: Long = 20L,
    val tournamentType: String = "LEAGUE_KNOCKOUT",
    val teamNames: List<String> = emptyList(),
    val standings: List<Map<String, Any>> = emptyList(),
    val fixtures: List<Map<String, Any>> = emptyList(),
    val status: String = "ACTIVE",
    val demoData: Boolean = false,
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "controllerUids" to controllerUids.ifEmpty { listOf(userId) }.take(10),
        "publicShared" to publicShared,
        "name" to name.take(80).ifBlank { "Club Championship" },
        "format" to MatchFormat.fromRaw(format).name,
        "oversLimit" to oversLimit.coerceIn(1L, 450L),
        "tournamentType" to tournamentType,
        "teamNames" to teamNames.take(20),
        "standings" to standings.take(20),
        "fixtures" to fixtures.take(40),
        "status" to status,
        "demoData" to demoData,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}

data class DrsAnnotationItem(
    val type: String = "LINE", // LINE, MARKER
    val x1: Float = 0.5f,
    val y1: Float = 0.5f,
    val x2: Float = 0.5f,
    val y2: Float = 0.5f,
    val colorHex: String = "#00E676"
) {
    fun toMap(): Map<String, Any> = mapOf(
        "type" to type,
        "x1" to x1.toDouble(),
        "y1" to y1.toDouble(),
        "x2" to x2.toDouble(),
        "y2" to y2.toDouble(),
        "colorHex" to colorHex
    )

    companion object {
        fun fromMap(map: Map<String, Any?>): DrsAnnotationItem = DrsAnnotationItem(
            type = map["type"] as? String ?: "LINE",
            x1 = (map["x1"] as? Number)?.toFloat() ?: 0.5f,
            y1 = (map["y1"] as? Number)?.toFloat() ?: 0.5f,
            x2 = (map["x2"] as? Number)?.toFloat() ?: 0.5f,
            y2 = (map["y2"] as? Number)?.toFloat() ?: 0.5f,
            colorHex = map["colorHex"] as? String ?: "#00E676"
        )
    }
}

@Keep
@IgnoreExtraProperties
data class DrsReview(
    @DocumentId val id: String = "",
    val userId: String = "",
    val matchId: String = "",
    val deliveryId: String = "",
    val matchTitle: String = "",
    val overBallLabel: String = "1.1",
    val category: String = DrsCategory.LBW.name,
    val videoUri: String = "",
    val umpireDecision: String = UmpireDecision.NOT_OUT.name,
    val finalOutcome: String = DrsOutcome.PENDING.name,
    val notes: String = "",
    val primaryTimestampMs: Long = 0L,
    val compareTimestampMs: Long = 0L,
    val annotations: List<Map<String, Any>> = emptyList(),
    @ServerTimestampCompat val createdAt: Timestamp? = null,
    @ServerTimestampCompat val updatedAt: Timestamp? = null
) {
    val parsedCategory: DrsCategory get() = DrsCategory.fromRaw(category)
    val parsedUmpireDecision: UmpireDecision get() = UmpireDecision.fromRaw(umpireDecision)
    val parsedOutcome: DrsOutcome get() = DrsOutcome.fromRaw(finalOutcome)

    fun toCreateMap(): Map<String, Any> = mapOf(
        "userId" to userId,
        "matchId" to matchId.take(128),
        "deliveryId" to deliveryId.take(128),
        "matchTitle" to matchTitle.take(100).ifBlank { "Practice Review" },
        "overBallLabel" to overBallLabel.take(30).ifBlank { "0.1" },
        "category" to DrsCategory.fromRaw(category).name,
        "videoUri" to videoUri.take(500),
        "umpireDecision" to UmpireDecision.fromRaw(umpireDecision).name,
        "finalOutcome" to DrsOutcome.fromRaw(finalOutcome).name,
        "notes" to notes.take(500),
        "primaryTimestampMs" to primaryTimestampMs.coerceAtLeast(0L),
        "compareTimestampMs" to compareTimestampMs.coerceAtLeast(0L),
        "annotations" to annotations.take(30),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )
}
