package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CricketMatch
import com.example.data.model.DeliveryRecord
import com.example.data.model.MatchStatus
import com.example.data.model.Team
import com.example.domain.scoring.DeliveryInput
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.MatchEngineState
import com.example.domain.scoring.MatchFormat
import com.example.domain.scoring.WicketType
import com.example.ui.components.BallChip
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.BoundaryGoldBg
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.SkyInfoBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson
import com.example.ui.theme.WicketCrimsonBg

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ScoreMatchScreen(
    activeMatch: CricketMatch?,
    activeDeliveries: List<DeliveryRecord>,
    engineState: MatchEngineState?,
    myMatches: List<CricketMatch>,
    teams: List<Team>,
    onStartNewMatch: (
        format: MatchFormat,
        oversLimit: Int,
        playersPerSide: Int,
        maxOversPerBowler: Int,
        teamAName: String,
        teamBName: String,
        venue: String,
        tossWinner: String,
        tossDecision: String,
        striker: String,
        nonStriker: String,
        bowler: String,
        teamAPlayers: List<String>,
        teamBPlayers: List<String>,
        publicShared: Boolean
    ) -> Unit,
    onResumeMatch: (CricketMatch) -> Unit,
    onSyncSnapshot: (CricketMatch, List<DeliveryRecord>) -> Unit,
    onRecordBall: (CricketMatch, DeliveryInput) -> Unit,
    onUndoBall: (CricketMatch, List<DeliveryRecord>) -> Unit,
    onChangeBowler: (String) -> Unit,
    onSwapStrike: () -> Unit,
    onSetNextBatter: (String) -> Unit,
    onEndInnings: (CricketMatch) -> Unit,
    onStartSecondInnings: (CricketMatch, String, String, String) -> Unit,
    onCloseActiveScoring: () -> Unit,
    onOpenDrsForBall: (String, String) -> Unit
) {
    LaunchedEffect(activeMatch?.id, activeDeliveries.size) {
        if (activeMatch != null) {
            onSyncSnapshot(activeMatch, activeDeliveries)
        }
    }

    if (activeMatch == null || engineState == null) {
        MatchSetupScreen(
            myMatches = myMatches,
            teams = teams,
            onCreateAndStart = onStartNewMatch,
            onResumeMatch = onResumeMatch
        )
        return
    }

    val inn = engineState.activeInnings
    var showExtrasDialog by remember { mutableStateOf<ExtraType?>(null) }
    var showWicketDialog by remember { mutableStateOf(false) }
    var showBowlerDialog by remember { mutableStateOf(false) }
    var showNextBatterDialog by remember { mutableStateOf(false) }
    var showSecondInningsDialog by remember { mutableStateOf(false) }

    LaunchedEffect(inn.needsBowlerChange, inn.needsNextBatter, inn.inningsComplete, engineState.currentInnings) {
        if (inn.needsNextBatter && !inn.inningsComplete) {
            showNextBatterDialog = true
        } else if (inn.needsBowlerChange && !inn.inningsComplete) {
            showBowlerDialog = true
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Compact Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${activeMatch.teamAShort} vs ${activeMatch.teamBShort} • Inn ${engineState.currentInnings}",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = engineState.resultSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = PitchGreen,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onCloseActiveScoring) {
                    Icon(Icons.Filled.Close, contentDescription = "Exit scoring console", tint = TextSecondary)
                }
            }
        }

        // Outdoor High-Contrast Scoreboard
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, PitchGreen.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = inn.battingTeamName.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "${inn.totalRuns}/${inn.wickets}",
                                style = MaterialTheme.typography.displayLarge,
                                color = PitchGreen
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${inn.oversString} / ${activeMatch.oversLimit} ov",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White
                            )
                            Text(
                                text = "CRR ${String.format("%.2f", inn.currentRunRate)}" +
                                    (inn.requiredRunRate?.let { " • RRR ${String.format("%.2f", it)}" } ?: ""),
                                style = MaterialTheme.typography.labelMedium,
                                color = BoundaryGold
                            )
                        }
                    }

                    // Active batters & bowler
                    val strikerStats = inn.batters.firstOrNull { it.name == inn.strikerName }
                    val nonStrikerStats = inn.batters.firstOrNull { it.name == inn.nonStrikerName }
                    val bowlerStats = inn.bowlers.firstOrNull { it.name == inn.currentBowlerName }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NavyElevated)
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🏏 ${inn.strikerName} *  ${strikerStats?.runs ?: 0}(${strikerStats?.ballsFaced ?: 0})",
                                style = MaterialTheme.typography.titleSmall,
                                color = PitchGreen,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "   ${inn.nonStrikerName}    ${nonStrikerStats?.runs ?: 0}(${nonStrikerStats?.ballsFaced ?: 0})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "⚾ ${inn.currentBowlerName}",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White,
                                maxLines = 1
                            )
                            Text(
                                text = "${bowlerStats?.wickets ?: 0}-${bowlerStats?.runsConceded ?: 0} (${bowlerStats?.oversString ?: "0.0"})",
                                style = MaterialTheme.typography.labelMedium,
                                color = SkyInfo
                            )
                        }
                    }

                    // This Over Timeline
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("This Over:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(inn.currentOverBalls) { d ->
                                BallChip(d.shortNotation())
                            }
                        }
                    }
                }
            }
        }

        // Innings Break / Match Completed Banner
        if (engineState.matchCompleted) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PitchGreenMuted),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("MATCH COMPLETE", style = MaterialTheme.typography.labelSmall, color = PitchGreen)
                        Text(engineState.resultSummary, style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Text(
                            "Scorecards and linked player career statistics have been updated.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        Button(
                            onClick = onCloseActiveScoring,
                            colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Done", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else if (inn.inningsComplete && engineState.currentInnings == 1) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BoundaryGoldBg),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BoundaryGold)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "INNINGS 1 COMPLETE (${inn.completionReason})",
                            style = MaterialTheme.typography.labelSmall,
                            color = BoundaryGold
                        )
                        Text(
                            text = "${inn.battingTeamName} posted ${inn.totalRuns}/${inn.wickets}. Target: ${inn.totalRuns + 1}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Button(
                            onClick = { showSecondInningsDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_second_innings_button")
                        ) {
                            Text("Start 2nd Innings", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // LARGE OUTDOOR SCORING BUTTONS (Runs 0, 1, 2, 3, 4, 6)
        if (!inn.inningsComplete && !engineState.matchCompleted) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ScoreRunButton("0", "DOT", NavyElevated, TextSecondary, Modifier.weight(1f).testTag("score_btn_0")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 0))
                        }
                        ScoreRunButton("1", "RUN", NavyElevated, Color.White, Modifier.weight(1f).testTag("score_btn_1")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 1))
                        }
                        ScoreRunButton("2", "RUNS", NavyElevated, Color.White, Modifier.weight(1f).testTag("score_btn_2")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 2))
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ScoreRunButton("3", "RUNS", NavyElevated, Color.White, Modifier.weight(1f).testTag("score_btn_3")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 3))
                        }
                        ScoreRunButton("4", "FOUR", BoundaryGoldBg, BoundaryGold, Modifier.weight(1f).testTag("score_btn_4")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 4))
                        }
                        ScoreRunButton("6", "SIX", PitchGreenMuted, PitchGreen, Modifier.weight(1f).testTag("score_btn_6")) {
                            onRecordBall(activeMatch, DeliveryInput(batterRuns = 6))
                        }
                    }
                }
            }

            // Extras Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExtraQuickButton("WD", Modifier.weight(1f).testTag("extra_btn_wd")) { showExtrasDialog = ExtraType.WIDE }
                    ExtraQuickButton("NB", Modifier.weight(1f).testTag("extra_btn_nb")) { showExtrasDialog = ExtraType.NO_BALL }
                    ExtraQuickButton("BYE", Modifier.weight(1f).testTag("extra_btn_b")) { showExtrasDialog = ExtraType.BYE }
                    ExtraQuickButton("LB", Modifier.weight(1f).testTag("extra_btn_lb")) { showExtrasDialog = ExtraType.LEG_BYE }
                    ExtraQuickButton("PEN", Modifier.weight(1f).testTag("extra_btn_pen")) { showExtrasDialog = ExtraType.PENALTY }
                }
            }

            // Wicket & Match Control Buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showWicketDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = WicketCrimson, contentColor = Color.White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(56.dp)
                            .testTag("wicket_button")
                    ) {
                        Text("WICKET", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { onUndoBall(activeMatch, activeDeliveries) },
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                            .testTag("undo_ball_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo", tint = BoundaryGold)
                        Spacer(Modifier.width(4.dp))
                        Text("Undo", color = BoundaryGold, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onSwapStrike,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                    ) {
                        Icon(Icons.Filled.SwapHoriz, contentDescription = null, tint = SkyInfo, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Swap Strike", color = SkyInfo)
                    }
                    OutlinedButton(
                        onClick = { showBowlerDialog = true },
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                    ) {
                        Text("Change Bowler", color = Color.White)
                    }
                    OutlinedButton(
                        onClick = {
                            onOpenDrsForBall(
                                "${activeMatch.teamAShort} vs ${activeMatch.teamBShort}",
                                "${inn.oversString}"
                            )
                        },
                        border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.Filled.VideoLibrary, contentDescription = null, tint = PitchGreen, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("DRS Review", color = PitchGreen)
                    }
                    OutlinedButton(
                        onClick = { onEndInnings(activeMatch) },
                        border = androidx.compose.foundation.BorderStroke(1.dp, WicketCrimson.copy(alpha = 0.6f))
                    ) {
                        Text(
                            if (activeMatch.parsedFormat == MatchFormat.TEST) "Declare / End Inn" else "End Innings",
                            color = WicketCrimson
                        )
                    }
                }
            }
        }
    }

    // Dialog: Extras Run Selector
    if (showExtrasDialog != null) {
        val type = showExtrasDialog!!
        var extraRuns by remember(type) { mutableIntStateOf(if (type == ExtraType.PENALTY) 5 else if (type == ExtraType.BYE || type == ExtraType.LEG_BYE) 1 else 0) }
        var batRunsOnNb by remember(type) { mutableIntStateOf(0) }
        AlertDialog(
            onDismissRequest = { showExtrasDialog = null },
            containerColor = NavyCard,
            title = { Text("${type.label} Details", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (type == ExtraType.NO_BALL) {
                        Text("Runs scored off bat (plus 1 Nb penalty):", color = TextSecondary)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(0, 1, 2, 3, 4, 6).forEach { r ->
                                FilterChip(
                                    selected = batRunsOnNb == r,
                                    onClick = { batRunsOnNb = r },
                                    label = { Text("$r") }
                                )
                            }
                        }
                    } else {
                        Text(
                            text = if (type == ExtraType.WIDE) "Additional runs run (+1 automatic Wide):" else "${type.label} runs:",
                            color = TextSecondary
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val options = if (type == ExtraType.PENALTY) listOf(5) else if (type == ExtraType.WIDE) listOf(0, 1, 2, 3, 4) else listOf(1, 2, 3, 4)
                            options.forEach { r ->
                                FilterChip(
                                    selected = extraRuns == r,
                                    onClick = { extraRuns = r },
                                    label = { Text("$r") }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRecordBall(
                            activeMatch,
                            DeliveryInput(
                                batterRuns = if (type == ExtraType.NO_BALL) batRunsOnNb else 0,
                                extraType = type,
                                additionalExtraRuns = if (type == ExtraType.NO_BALL) 0 else extraRuns
                            )
                        )
                        showExtrasDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Record ${type.shortCode}", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExtrasDialog = null }) { Text("Cancel") }
            }
        )
    }

    // Dialog: Wicket Dismissal
    if (showWicketDialog) {
        var wType by remember { mutableStateOf(WicketType.CAUGHT) }
        var fielder by remember { mutableStateOf("") }
        var dismissedName by remember { mutableStateOf(inn.strikerName) }
        var nextBatter by remember { mutableStateOf("") }
        var runOutRuns by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { showWicketDialog = false },
            containerColor = NavyCard,
            title = { Text("Record Wicket", color = WicketCrimson, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Dismissal Type", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        WicketType.entries.filter { it != WicketType.NONE }.forEach { wt ->
                            FilterChip(
                                selected = wType == wt,
                                onClick = { wType = wt },
                                label = { Text(wt.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = WicketCrimsonBg,
                                    selectedLabelColor = WicketCrimson
                                )
                            )
                        }
                    }
                    if (wType == WicketType.RUN_OUT) {
                        Text("Batter Dismissed:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(inn.strikerName, inn.nonStrikerName).forEach { name ->
                                FilterChip(
                                    selected = dismissedName == name,
                                    onClick = { dismissedName = name },
                                    label = { Text(name) }
                                )
                            }
                        }
                        Text("Runs completed before run out:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 1, 2, 3).forEach { r ->
                                FilterChip(selected = runOutRuns == r, onClick = { runOutRuns = r }, label = { Text("$r") })
                            }
                        }
                    }
                    if (wType in listOf(WicketType.CAUGHT, WicketType.RUN_OUT, WicketType.STUMPED)) {
                        OutlinedTextField(
                            value = fielder,
                            onValueChange = { fielder = it },
                            label = { Text("Fielder / Keeper Name (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    OutlinedTextField(
                        value = nextBatter,
                        onValueChange = { nextBatter = it },
                        label = { Text("Incoming Batter Name") },
                        placeholder = { Text("Enter next batter") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRecordBall(
                            activeMatch,
                            DeliveryInput(
                                batterRuns = if (wType == WicketType.RUN_OUT) runOutRuns else 0,
                                wicketType = wType,
                                dismissedBatterName = if (wType == WicketType.RUN_OUT) dismissedName else inn.strikerName,
                                fielderName = fielder.trim(),
                                nextBatterName = nextBatter.trim().takeIf { it.isNotBlank() }
                            )
                        )
                        showWicketDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WicketCrimson, contentColor = Color.White)
                ) {
                    Text("Confirm Wicket", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWicketDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Dialog: Change Bowler
    if (showBowlerDialog) {
        var bowlerInput by remember { mutableStateOf("") }
        val squadBowlers = (if (inn.bowlingTeamName == activeMatch.teamAName) activeMatch.teamAPlayerNames else activeMatch.teamBPlayerNames)
            .filter { it.isNotBlank() && it != inn.lastCompletedOverBowlerName }

        AlertDialog(
            onDismissRequest = { showBowlerDialog = false },
            containerColor = NavyCard,
            title = { Text("Select Next Bowler", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (inn.lastCompletedOverBowlerName.isNotBlank()) {
                        Text(
                            text = "${inn.lastCompletedOverBowlerName} bowled the last over and cannot bowl consecutive overs.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BoundaryGold
                        )
                    }
                    if (squadBowlers.isNotEmpty()) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            squadBowlers.forEach { name ->
                                FilterChip(
                                    selected = bowlerInput == name,
                                    onClick = { bowlerInput = name },
                                    label = { Text(name) }
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = bowlerInput,
                        onValueChange = { bowlerInput = it },
                        label = { Text("Bowler Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bowlerInput.isNotBlank()) {
                            onChangeBowler(bowlerInput)
                            showBowlerDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Set Bowler", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBowlerDialog = false }) { Text("Close") }
            }
        )
    }

    // Dialog: Select Next Batter
    if (showNextBatterDialog) {
        var batterInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showNextBatterDialog = false },
            containerColor = NavyCard,
            title = { Text("Incoming Batter", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = batterInput,
                    onValueChange = { batterInput = it },
                    label = { Text("Next Batter Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (batterInput.isNotBlank()) {
                            onSetNextBatter(batterInput)
                            showNextBatterDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Send to Crease", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Dialog: Start 2nd Innings
    if (showSecondInningsDialog) {
        var s1 by remember { mutableStateOf("") }
        var s2 by remember { mutableStateOf("") }
        var b1 by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSecondInningsDialog = false },
            containerColor = NavyCard,
            title = { Text("Start 2nd Innings", color = PitchGreen) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Target: ${engineState.innings1.totalRuns + 1} runs", color = BoundaryGold)
                    OutlinedTextField(value = s1, onValueChange = { s1 = it }, label = { Text("Striker") }, singleLine = true)
                    OutlinedTextField(value = s2, onValueChange = { s2 = it }, label = { Text("Non-Striker") }, singleLine = true)
                    OutlinedTextField(value = b1, onValueChange = { b1 = it }, label = { Text("Opening Bowler") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onStartSecondInnings(
                            activeMatch,
                            s1.ifBlank { "Opener 1" },
                            s2.ifBlank { "Opener 2" },
                            b1.ifBlank { "Bowler 1" }
                        )
                        showSecondInningsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Start Chase", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSecondInningsDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ScoreRunButton(
    mainText: String,
    subText: String,
    bgColor: Color,
    fgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, fgColor.copy(alpha = 0.45f)),
        modifier = modifier
            .height(66.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(mainText, style = MaterialTheme.typography.headlineMedium, color = fgColor, fontWeight = FontWeight.Bold)
            Text(subText, style = MaterialTheme.typography.labelSmall, color = fgColor.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun ExtraQuickButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = SkyInfoBg,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SkyInfo.copy(alpha = 0.5f)),
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = SkyInfo, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MatchSetupScreen(
    myMatches: List<CricketMatch>,
    teams: List<Team>,
    onCreateAndStart: (
        format: MatchFormat,
        oversLimit: Int,
        playersPerSide: Int,
        maxOversPerBowler: Int,
        teamAName: String,
        teamBName: String,
        venue: String,
        tossWinner: String,
        tossDecision: String,
        striker: String,
        nonStriker: String,
        bowler: String,
        teamAPlayers: List<String>,
        teamBPlayers: List<String>,
        publicShared: Boolean
    ) -> Unit,
    onResumeMatch: (CricketMatch) -> Unit
) {
    var selectedFormat by remember { mutableStateOf(MatchFormat.T20) }
    var customOvers by remember { mutableStateOf("20") }
    var playersPerSide by remember { mutableStateOf("11") }
    var teamAName by remember { mutableStateOf(teams.getOrNull(0)?.name ?: "Home XI") }
    var teamBName by remember { mutableStateOf(teams.getOrNull(1)?.name ?: "Visitors XI") }
    var venue by remember { mutableStateOf("Central Cricket Ground") }
    var tossIsTeamA by remember { mutableStateOf(true) }
    var tossDecision by remember { mutableStateOf("BAT") }
    var striker by remember { mutableStateOf("Opener 1") }
    var nonStriker by remember { mutableStateOf("Opener 2") }
    var bowler by remember { mutableStateOf("Opening Bowler") }
    var publicShared by remember { mutableStateOf(true) }

    val activeMatches = myMatches.filter { it.parsedStatus != MatchStatus.COMPLETED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (activeMatches.isNotEmpty()) {
            item {
                SectionHeader("Resume In-Progress Match", "Tap to reopen ball-by-ball console")
            }
            items(activeMatches, key = { it.id }) { m ->
                MatchSummaryCard(
                    match = m,
                    onClick = { onResumeMatch(m) },
                    primaryActionLabel = "Resume Scoring",
                    onPrimaryAction = { onResumeMatch(m) }
                )
            }
        }

        item {
            SectionHeader("Start New Match", "Configure format, teams, toss & openers")
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Match Format", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MatchFormat.entries.forEach { fmt ->
                            FilterChip(
                                selected = selectedFormat == fmt,
                                onClick = {
                                    selectedFormat = fmt
                                    customOvers = fmt.defaultOvers.toString()
                                },
                                label = { Text(fmt.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PitchGreenMuted,
                                    selectedLabelColor = PitchGreen
                                )
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customOvers,
                            onValueChange = { customOvers = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Overs") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = playersPerSide,
                            onValueChange = { playersPerSide = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Players/Side") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (teams.isNotEmpty()) {
                        Text("Quick Select Saved Teams", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(teams) { t ->
                                FilterChip(
                                    selected = teamAName == t.name || teamBName == t.name,
                                    onClick = {
                                        if (teamAName == "Home XI" || teamAName.isBlank()) teamAName = t.name
                                        else if (teamAName != t.name) teamBName = t.name
                                    },
                                    label = { Text(t.name) }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = teamAName,
                        onValueChange = { teamAName = it },
                        label = { Text("Team A Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("setup_team_a_input")
                    )
                    OutlinedTextField(
                        value = teamBName,
                        onValueChange = { teamBName = it },
                        label = { Text("Team B Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("setup_team_b_input")
                    )
                    OutlinedTextField(
                        value = venue,
                        onValueChange = { venue = it },
                        label = { Text("Ground / Venue") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Toss Winner & Decision", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = tossIsTeamA,
                            onClick = { tossIsTeamA = true },
                            label = { Text(teamAName.ifBlank { "Team A" }) }
                        )
                        FilterChip(
                            selected = !tossIsTeamA,
                            onClick = { tossIsTeamA = false },
                            label = { Text(teamBName.ifBlank { "Team B" }) }
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = tossDecision == "BAT", onClick = { tossDecision = "BAT" }, label = { Text("Elected to Bat") })
                        FilterChip(selected = tossDecision == "BOWL", onClick = { tossDecision = "BOWL" }, label = { Text("Elected to Bowl") })
                    }

                    Text("Opening Lineup", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                    OutlinedTextField(value = striker, onValueChange = { striker = it }, label = { Text("Striker") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = nonStriker, onValueChange = { nonStriker = it }, label = { Text("Non-Striker") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bowler, onValueChange = { bowler = it }, label = { Text("Opening Bowler") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Sync to Live Match Centre", style = MaterialTheme.typography.titleSmall, color = Color.White)
                            Text("Allow spectators with code to view live scorecard", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                        Switch(checked = publicShared, onCheckedChange = { publicShared = it })
                    }

                    Button(
                        onClick = {
                            val overs = (customOvers.toIntOrNull() ?: selectedFormat.defaultOvers).coerceIn(1, 450)
                            val pSide = (playersPerSide.toIntOrNull() ?: 11).coerceIn(2, 11)
                            val maxBowlerOvers = when (selectedFormat) {
                                MatchFormat.TEST -> overs
                                MatchFormat.T10 -> 2
                                MatchFormat.T20 -> 4
                                MatchFormat.ODI -> 10
                                MatchFormat.CUSTOM -> ((overs + 4) / 5).coerceAtLeast(1)
                            }
                            onCreateAndStart(
                                selectedFormat,
                                overs,
                                pSide,
                                maxBowlerOvers,
                                teamAName.ifBlank { "Home XI" },
                                teamBName.ifBlank { "Visitors XI" },
                                venue.ifBlank { "Club Ground" },
                                if (tossIsTeamA) teamAName.ifBlank { "Home XI" } else teamBName.ifBlank { "Visitors XI" },
                                tossDecision,
                                striker.ifBlank { "Opener 1" },
                                nonStriker.ifBlank { "Opener 2" },
                                bowler.ifBlank { "Opening Bowler" },
                                listOf(striker, nonStriker),
                                listOf(bowler),
                                publicShared
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("create_and_start_match_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Launch Live Scoring Console", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
