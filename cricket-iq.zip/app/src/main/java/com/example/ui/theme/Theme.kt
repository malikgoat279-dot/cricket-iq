package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CricketDarkColorScheme = darkColorScheme(
    primary = PitchGreen,
    onPrimary = NavyDeep,
    primaryContainer = PitchGreenMuted,
    onPrimaryContainer = PitchGreen,
    secondary = SkyInfo,
    onSecondary = NavyDeep,
    secondaryContainer = SkyInfoBg,
    onSecondaryContainer = SkyInfo,
    tertiary = BoundaryGold,
    onTertiary = NavyDeep,
    tertiaryContainer = BoundaryGoldBg,
    onTertiaryContainer = BoundaryGold,
    error = WicketCrimson,
    onError = TextPrimary,
    errorContainer = WicketCrimsonBg,
    onErrorContainer = WicketCrimson,
    background = NavyBase,
    onBackground = TextPrimary,
    surface = NavySurface,
    onSurface = TextPrimary,
    surfaceVariant = NavyCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = NavySurface,
    surfaceContainer = NavyCard,
    surfaceContainerHigh = NavyElevated,
    outline = NavyOutline,
    outlineVariant = NavyElevated
)

val CricketShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun CricketIqTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CricketDarkColorScheme,
        typography = CricketTypography,
        shapes = CricketShapes,
        content = content
    )
}
