package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.CricketMatch
import com.example.data.model.DeliveryRecord
import com.example.domain.scoring.CricketScoringEngine
import com.example.domain.scoring.InningsScorecard
import com.example.ui.components.BallChip
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson

@Composable
fun LiveScoresScreen(
    myMatches: List<CricketMatch>,
    publicMatches: List<CricketMatch>,
    selectedMatch: CricketMatch?,
    selectedMatchDeliveries: List<DeliveryRecord>,
    currentUserId: String,
    onSelectMatch: (CricketMatch) -> Unit,
    onClearSelection: () -> Unit,
    onJoinByCode: (String) -> Unit,
    onResumeScoring: (CricketMatch) -> Unit,
    onTogglePublicShare: (CricketMatch) -> Unit
) {
    if (selectedMatch != null) {
        BackHandler { onClearSelection() }
        LiveMatchCentreDetail(
            match = selectedMatch,
            deliveries = selectedMatchDeliveries,
            isController = selectedMatch.userId == currentUserId || selectedMatch.controllerUids.contains(currentUserId),
            onBack = onClearSelection,
            onResumeScoring = { onResumeScoring(selectedMatch) },
            onTogglePublicShare = { onTogglePublicShare(selectedMatch) }
        )
        return
    }

    var shareCodeInput by remember { mutableStateOf("") }
    val mergedMatches = remember(myMatches, publicMatches) {
        (myMatches + publicMatches).distinctBy { it.id }
            .sortedByDescending { it.updatedAt?.seconds ?: 0L }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Live Match Centre",
                subtitle = "Real-time synced scorecards & shared matches"
            )
        }

        // Join shared match by code
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = shareCodeInput,
                        onValueChange = { shareCodeInput = it.uppercase() },
                        label = { Text("Enter Live Share Code") },
                        placeholder = { Text("e.g. CIQ842") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = { if (shareCodeInput.isNotBlank()) onJoinByCode(shareCodeInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier.height(52.dp)
                    ) {
                        Text("Open", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (mergedMatches.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.LiveTv,
                    title = "No Live Matches Yet",
                    message = "Start scoring a match or enter a public match code shared by another scorer to follow live ball-by-ball."
                )
            }
        } else {
            items(mergedMatches, key = { it.id }) { match ->
                MatchSummaryCard(
                    match = match,
                    onClick = { onSelectMatch(match) },
                    primaryActionLabel = "Match Centre",
                    onPrimaryAction = { onSelectMatch(match) }
                )
            }
        }
    }
}

@Composable
private fun LiveMatchCentreDetail(
    match: CricketMatch,
    deliveries: List<DeliveryRecord>,
    isController: Boolean,
    onBack: () -> Unit,
    onResumeScoring: () -> Unit,
    onTogglePublicShare: () -> Unit
) {
    val context = LocalContext.current
    val engineState = remember(match, deliveries) {
        val firstBat = if (match.tossDecision == "BOWL") {
            if (match.tossWinnerName == match.teamAName) match.teamBName else match.teamAName
        } else {
            match.tossWinnerName.ifBlank { match.teamAName }
        }
        val firstBowl = if (firstBat == match.teamAName) match.teamBName else match.teamAName
        val engine = CricketScoringEngine(
            format = match.parsedFormat,
            oversLimit = match.oversLimit.toInt(),
            playersPerSide = match.playersPerSide.toInt(),
            maxOversPerBowler = match.maxOversPerBowler.toInt(),
            teamAName = match.teamAName,
            teamBName = match.teamBName,
            firstBattingTeam = firstBat,
            firstBowlingTeam = firstBowl,
            initialStriker = match.strikerName.ifBlank { "Opener 1" },
            initialNonStriker = match.nonStrikerName.ifBlank { "Opener 2" },
            initialBowler = match.bowlerName.ifBlank { "Bowler 1" }
        )
        engine.loadDeliveries(deliveries.map { it.toDomain() }, match.currentInnings.toInt())
        engine.getState()
    }

    val activeInn = engineState.activeInnings
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedInningsTab by remember { mutableIntStateOf(if (engineState.innings2 != null) 1 else 0) }
    val displayedInn = if (selectedInningsTab == 1 && engineState.innings2 != null) engineState.innings2 else engineState.innings1

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${match.teamAShort} vs ${match.teamBShort} • ${match.format}",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = match.venue.ifBlank { "Live Match Centre" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                IconButton(
                    onClick = {
                        if (!match.publicShared && isController) onTogglePublicShare()
                        val shareText = buildString {
                            appendLine("CRICKET IQ LIVE SCORECARD")
                            appendLine("${match.teamAName} vs ${match.teamBName} (${match.format})")
                            appendLine("${activeInn.battingTeamName}: ${activeInn.totalRuns}/${activeInn.wickets} (${activeInn.oversString} ov)")
                            if (activeInn.targetRuns > 0) appendLine("Target: ${activeInn.targetRuns}")
                            appendLine(engineState.resultSummary)
                            appendLine("Open in CRICKET IQ with Match Code: ${match.shareCode}")
                            append("https://cricketiq.app/match/${match.shareCode}")
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Live Scorecard"))
                    },
                    modifier = Modifier.testTag("live_share_button")
                ) {
                    Icon(Icons.Filled.Share, contentDescription = "Share Live Scorecard", tint = PitchGreen)
                }
            }
        }

        // Main Scoreboard Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(22.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.45f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(
                            text = match.parsedStatus.label.uppercase(),
                            color = PitchGreen,
                            backgroundColor = PitchGreenMuted
                        )
                        Text(
                            text = "Share Code: ${match.shareCode}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SkyInfo
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = activeInn.battingTeamName,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White
                            )
                            Text(
                                text = "${activeInn.totalRuns}/${activeInn.wickets}",
                                style = MaterialTheme.typography.displayLarge,
                                color = PitchGreen
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Overs: ${activeInn.oversString} / ${match.oversLimit}",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White
                            )
                            Text(
                                text = "CRR: ${String.format("%.2f", activeInn.currentRunRate)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                            if (activeInn.requiredRunRate != null) {
                                Text(
                                    text = "RRR: ${String.format("%.2f", activeInn.requiredRunRate)} • Target ${activeInn.targetRuns}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = BoundaryGold
                                )
                            }
                        }
                    }

                    Text(
                        text = engineState.resultSummary,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White
                    )

                    // Estimated Win Probability
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${match.teamAShort} ${engineState.winProbabilityTeamA}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = PitchGreen
                            )
                            Text(
                                text = "Win Probability (Estimate)",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Text(
                                text = "${match.teamBShort} ${100 - engineState.winProbabilityTeamA}%",
                                style = MaterialTheme.typography.labelSmall,
                                color = SkyInfo
                            )
                        }
                        LinearProgressIndicator(
                            progress = { engineState.winProbabilityTeamA / 100f },
                            color = PitchGreen,
                            trackColor = SkyInfo.copy(alpha = 0.4f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }

                    if (activeInn.recentDeliveries.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(activeInn.recentDeliveries.takeLast(10)) { d ->
                                BallChip(d.shortNotation())
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (isController && !engineState.matchCompleted) {
                            Button(
                                onClick = onResumeScoring,
                                colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Score Ball-by-Ball", fontWeight = FontWeight.Bold)
                            }
                        }
                        if (isController) {
                            OutlinedButton(
                                onClick = onTogglePublicShare,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SkyInfo),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (match.publicShared) "Public Link ON" else "Enable Public Link",
                                    color = SkyInfo,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        // Current Batters & Bowler strip
        item {
            val striker = activeInn.batters.firstOrNull { it.name == activeInn.strikerName }
            val nonStriker = activeInn.batters.firstOrNull { it.name == activeInn.nonStrikerName }
            val bowler = activeInn.bowlers.firstOrNull { it.name == activeInn.currentBowlerName }
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("At the Crease", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                    if (striker != null) {
                        CreaseRow("${striker.name} *", "${striker.runs} (${striker.ballsFaced})", "SR ${String.format("%.1f", striker.strikeRate)}")
                    }
                    if (nonStriker != null) {
                        CreaseRow(nonStriker.name, "${nonStriker.runs} (${nonStriker.ballsFaced})", "SR ${String.format("%.1f", nonStriker.strikeRate)}")
                    }
                    HorizontalDivider(color = NavyOutline)
                    if (bowler != null) {
                        CreaseRow("Bowler: ${bowler.name}", "${bowler.wickets}-${bowler.runsConceded} (${bowler.oversString})", "Econ ${String.format("%.2f", bowler.economy)}")
                    }
                }
            }
        }

        // Innings Switcher if 2nd innings exists
        if (engineState.innings2 != null) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(engineState.innings1, engineState.innings2).forEachIndexed { idx, inn ->
                        val selected = selectedInningsTab == idx
                        OutlinedButton(
                            onClick = { selectedInningsTab = idx },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (selected) PitchGreenMuted else Color.Transparent,
                                contentColor = if (selected) PitchGreen else TextSecondary
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) PitchGreen else NavyOutline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("${inn.battingTeamName} ${inn.totalRuns}/${inn.wickets}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        // Detailed Scorecard Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = NavyCard,
                contentColor = PitchGreen,
                edgePadding = 8.dp
            ) {
                listOf("Batting", "Bowling", "FOW & Partnerships", "Ball Log").forEachIndexed { i, title ->
                    Tab(
                        selected = selectedTab == i,
                        onClick = { selectedTab = i },
                        text = { Text(title) }
                    )
                }
            }
        }

        item {
            ScorecardTabContent(displayedInn, selectedTab)
        }
    }
}

@Composable
private fun CreaseRow(left: String, mid: String, right: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(left, style = MaterialTheme.typography.bodyLarge, color = Color.White, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(mid, style = MaterialTheme.typography.labelMedium, color = PitchGreen)
        Spacer(Modifier.width(12.dp))
        Text(right, style = MaterialTheme.typography.labelMedium, color = TextSecondary)
    }
}

@Composable
private fun ScorecardTabContent(inn: InningsScorecard, tabIndex: Int) {
    Card(
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tabIndex) {
                0 -> {
                    Row(Modifier.fillMaxWidth()) {
                        Text("Batter", Modifier.weight(1.8f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("R", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("B", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("4s", Modifier.weight(0.4f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("6s", Modifier.weight(0.4f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("SR", Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    HorizontalDivider(color = NavyOutline)
                    inn.batters.forEach { b ->
                        Column {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1.8f)) {
                                    Text(b.name, style = MaterialTheme.typography.bodyLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text(b.dismissalText, style = MaterialTheme.typography.labelSmall, color = if (b.out) WicketCrimson else PitchGreen)
                                }
                                Text("${b.runs}", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("${b.ballsFaced}", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text("${b.fours}", Modifier.weight(0.4f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text("${b.sixes}", Modifier.weight(0.4f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                Text(String.format("%.0f", b.strikeRate), Modifier.weight(0.7f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                            }
                            HorizontalDivider(color = NavyOutline.copy(alpha = 0.4f), modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    Text(
                        text = "Extras: ${inn.extras.total} (wd ${inn.extras.wides}, nb ${inn.extras.noBalls}, b ${inn.extras.byes}, lb ${inn.extras.legByes}, pen ${inn.extras.penalties})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SkyInfo
                    )
                }
                1 -> {
                    Row(Modifier.fillMaxWidth()) {
                        Text("Bowler", Modifier.weight(1.8f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("O", Modifier.weight(0.6f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("M", Modifier.weight(0.4f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("R", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("W", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text("ECON", Modifier.weight(0.7f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    HorizontalDivider(color = NavyOutline)
                    inn.bowlers.forEach { bw ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(bw.name, Modifier.weight(1.8f), style = MaterialTheme.typography.bodyLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(bw.oversString, Modifier.weight(0.6f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                            Text("${bw.maidens}", Modifier.weight(0.4f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                            Text("${bw.runsConceded}", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                            Text("${bw.wickets}", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = PitchGreen, fontWeight = FontWeight.Bold)
                            Text(String.format("%.2f", bw.economy), Modifier.weight(0.7f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                        }
                        HorizontalDivider(color = NavyOutline.copy(alpha = 0.4f))
                    }
                }
                2 -> {
                    Text("Partnerships", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                    if (inn.partnerships.isEmpty()) {
                        Text("No partnership data yet.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    } else {
                        inn.partnerships.forEach { p ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${p.batterOne} & ${p.batterTwo}", style = MaterialTheme.typography.bodyMedium, color = Color.White)
                                Text("${p.runs} (${p.balls}b)", style = MaterialTheme.typography.labelMedium, color = if (p.active) PitchGreen else TextSecondary)
                            }
                        }
                    }
                    HorizontalDivider(color = NavyOutline)
                    Text("Fall of Wickets", style = MaterialTheme.typography.titleSmall, color = WicketCrimson)
                    if (inn.fallOfWickets.isEmpty()) {
                        Text("No wickets fallen.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    } else {
                        inn.fallOfWickets.forEach { f ->
                            Text(
                                text = "${f.wicketNumber}-${f.score} (${f.batterName}, ${f.oversString} ov) • ${f.dismissalText}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }
                else -> {
                    if (inn.recentDeliveries.isEmpty()) {
                        Text("No deliveries recorded yet.", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                    } else {
                        inn.recentDeliveries.reversed().forEach { d ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${d.overNumber}.${d.ballNumber}  ${d.bowlerName} to ${d.strikerName}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White,
                                    modifier = Modifier.weight(1f)
                                )
                                BallChip(d.shortNotation())
                            }
                        }
                    }
                }
            }
        }
    }
}
