package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CricketMatch
import com.example.data.model.PlayerProfile
import com.example.data.model.SubscriptionTier
import com.example.data.model.Team
import com.example.data.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricTile
import com.example.ui.components.RunsBarChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.TrendLineChart
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StatisticsScreen(
    userProfile: UserProfile?,
    players: List<PlayerProfile>,
    teams: List<Team>,
    matches: List<CricketMatch>,
    onOpenDrsReview: () -> Unit,
    onOpenSubscriptionPage: () -> Unit
) {
    val context = LocalContext.current
    var playerA by remember(players) { mutableStateOf(players.getOrNull(0)) }
    var playerB by remember(players) { mutableStateOf(players.getOrNull(1) ?: players.getOrNull(0)) }
    var seasonFilter by remember { mutableStateOf("CAREER") }

    val totalRunsAll = players.sumOf { it.runs }
    val totalWicketsAll = players.sumOf { it.wickets }
    val totalMatchesRecorded = matches.size

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Analytics & Smart DRS",
                subtitle = "Performance graphs, comparisons & video review"
            )
        }

        // Smart DRS Banner Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, PitchGreen.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .clickable { onOpenDrsReview() }
                    .testTag("stats_drs_banner")
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_drs_pitch_banner),
                    contentDescription = "Smart DRS Video Review Studio",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(NavyBase.copy(alpha = 0.94f), NavyBase.copy(alpha = 0.45f))
                            )
                        )
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        StatusPill("SMART DRS STUDIO", PitchGreen, PitchGreenMuted)
                        Text("Manual Video Review", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Text(
                            "Frame-by-frame stepping, zoom, manual crease/impact lines & dual-frame compare.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = onOpenDrsReview,
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                    ) {
                        Icon(Icons.Filled.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Open", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Overview Metrics + Season/Career Filter
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = seasonFilter == "CAREER",
                    onClick = { seasonFilter = "CAREER" },
                    label = { Text("Career Stats") }
                )
                FilterChip(
                    selected = seasonFilter == "SEASON",
                    onClick = { seasonFilter = "SEASON" },
                    label = { Text("2026 Season") }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricTile("MATCHES", "$totalMatchesRecorded", SkyInfo, Modifier.weight(1f))
                MetricTile("TOTAL RUNS", "$totalRunsAll", PitchGreen, Modifier.weight(1f))
                MetricTile("WICKETS", "$totalWicketsAll", BoundaryGold, Modifier.weight(1f))
            }
        }

        if (players.isEmpty() && matches.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.Analytics,
                    title = "No Match Analytics Yet",
                    message = "Score matches or add players in the Teams hub to generate batting form graphs, bowling comparisons, and exportable scorecards."
                )
            }
        }

        // Player Performance Graph
        if (players.isNotEmpty()) {
            item {
                val activePlayer = playerA ?: players.first()
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Player Performance Graph", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            players.take(6).forEach { p ->
                                FilterChip(
                                    selected = activePlayer.id == p.id,
                                    onClick = { playerA = p },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                        val scores = activePlayer.recentScores.ifEmpty { listOf(activePlayer.runs) }.map { it.toInt() }
                        RunsBarChart(
                            values = scores,
                            labels = scores.indices.map { "M${it + 1}" },
                            accentColor = PitchGreen
                        )
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Avg: ${String.format("%.1f", activePlayer.battingAverage)}", style = MaterialTheme.typography.labelMedium, color = PitchGreen)
                            Text("SR: ${String.format("%.1f", activePlayer.battingStrikeRate)}", style = MaterialTheme.typography.labelMedium, color = SkyInfo)
                            Text("Econ: ${String.format("%.2f", activePlayer.bowlingEconomy)}", style = MaterialTheme.typography.labelMedium, color = BoundaryGold)
                        }
                    }
                }
            }
        }

        // Batting & Bowling Comparison
        if (players.size >= 2) {
            item {
                val p1 = playerA ?: players[0]
                val p2 = playerB ?: players[1]
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Player Head-to-Head Comparison", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text("Select Comparison Player:", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            players.take(6).forEach { p ->
                                FilterChip(
                                    selected = p2.id == p.id,
                                    onClick = { playerB = p },
                                    label = { Text(p.name) }
                                )
                            }
                        }
                        TrendLineChart(
                            seriesA = p1.recentScores.ifEmpty { listOf(p1.runs) }.map { it.toFloat() },
                            seriesB = p2.recentScores.ifEmpty { listOf(p2.runs) }.map { it.toFloat() },
                            colorA = PitchGreen,
                            colorB = SkyInfo
                        )
                        ComparisonRow("Runs", "${p1.runs}", "${p2.runs}")
                        ComparisonRow("Batting Avg", String.format("%.1f", p1.battingAverage), String.format("%.1f", p2.battingAverage))
                        ComparisonRow("Strike Rate", String.format("%.1f", p1.battingStrikeRate), String.format("%.1f", p2.battingStrikeRate))
                        ComparisonRow("Wickets", "${p1.wickets}", "${p2.wickets}")
                        ComparisonRow("Economy", String.format("%.2f", p1.bowlingEconomy), String.format("%.2f", p2.bowlingEconomy))
                    }
                }
            }
        }

        // Team Performance
        if (teams.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Team Performance", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        RunsBarChart(
                            values = teams.map { it.wins.toInt() },
                            labels = teams.map { it.shortName },
                            accentColor = SkyInfo
                        )
                        teams.forEach { t ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(t.name, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                                Text(
                                    text = "${t.wins}W-${t.losses}L • NRR ${String.format("%+.2f", t.netRunRate)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = PitchGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        // Match History & Exportable Scorecards
        if (matches.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Match History & Export",
                    subtitle = if (userProfile?.parsedTier == SubscriptionTier.CLUB_PRO) "Club Pro CSV & Text Export Active" else "Export match summaries"
                )
            }
            items(matches, key = { it.id }) { m ->
                Surface(
                    color = NavyCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("${m.teamAName} vs ${m.teamBName}", style = MaterialTheme.typography.titleSmall, color = Color.White)
                            Text(
                                text = m.resultSummary.ifBlank { "${m.battingTeamName} ${m.totalRuns}/${m.wickets} (${m.oversString})" },
                                style = MaterialTheme.typography.bodyMedium,
                                color = PitchGreen
                            )
                        }
                        OutlinedButton(
                            onClick = {
                                val csv = buildString {
                                    appendLine("CRICKET IQ SCORECARD EXPORT")
                                    appendLine("Match,${m.teamAName} vs ${m.teamBName}")
                                    appendLine("Format,${m.format}")
                                    appendLine("Venue,${m.venue}")
                                    appendLine("Score,${m.totalRuns}/${m.wickets} (${m.oversString} ov)")
                                    appendLine("Summary,${m.resultSummary}")
                                }
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                }
                                context.startActivity(Intent.createChooser(intent, "Export Match Scorecard"))
                            }
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = "Export", tint = SkyInfo, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Export", color = SkyInfo)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComparisonRow(metric: String, valA: String, valB: String) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(valA, style = MaterialTheme.typography.labelMedium, color = PitchGreen, fontWeight = FontWeight.Bold)
            Text(metric, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Text(valB, style = MaterialTheme.typography.labelMedium, color = SkyInfo, fontWeight = FontWeight.Bold)
        }
        HorizontalDivider(color = NavyOutline.copy(alpha = 0.4f))
    }
}
