package com.example.ui.viewmodel

import com.example.data.model.CricketMatch
import com.example.data.model.DeliveryRecord
import com.example.data.model.DrsCategory
import com.example.data.model.DrsOutcome
import com.example.data.model.DrsReview
import com.example.data.model.MatchStatus
import com.example.data.model.PlayerProfile
import com.example.data.model.PlayerRole
import com.example.data.model.SubscriptionTier
import com.example.data.model.Team
import com.example.data.model.Tournament
import com.example.data.model.UmpireDecision
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.domain.scoring.CricketScoringEngine
import com.example.domain.scoring.DeliveryInput
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.MatchFormat
import com.example.domain.scoring.WicketType
import com.google.firebase.Timestamp

data class GuestSeedBundle(
    val profile: UserProfile,
    val teams: List<Team>,
    val players: List<PlayerProfile>,
    val matches: List<CricketMatch>,
    val deliveriesByMatchId: Map<String, List<DeliveryRecord>>,
    val tournaments: List<Tournament>,
    val drsReviews: List<DrsReview>
)

object GuestDemoFactory {
    const val GUEST_UID = "guest_local"

    fun createSeedData(): GuestSeedBundle {
        val now = Timestamp.now()

        val profile = UserProfile(
            id = GUEST_UID,
            userId = GUEST_UID,
            displayName = "Guest Scorer",
            email = "Guest Mode • Local Session",
            role = UserRole.SCORER.name,
            clubName = "Cricket IQ Demo Club",
            subscriptionTier = SubscriptionTier.FREE.name,
            subscriptionMode = "FREE",
            subscriptionStatus = "ACTIVE",
            createdAt = now,
            updatedAt = now
        )

        val team1Id = "guest_team_mkx"
        val team2Id = "guest_team_ths"

        val players = listOf(
            PlayerProfile(
                id = "guest_p1",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Aarav Sharma (Demo)",
                teamId = team1Id,
                teamName = "Metro Kings XI (Demo)",
                role = PlayerRole.BATTER.name,
                battingStyle = "Right-hand bat",
                bowlingStyle = "Right-arm offbreak",
                matchesPlayed = 18,
                inningsBatted = 17,
                runs = 642,
                ballsFaced = 438,
                fours = 68,
                sixes = 24,
                highestScore = 94,
                notOuts = 3,
                wickets = 4,
                ballsBowled = 60,
                runsConceded = 71,
                bestBowlingWickets = 2,
                bestBowlingRuns = 19,
                catches = 9,
                recentScores = listOf(42, 68, 19, 94, 53, 77),
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            PlayerProfile(
                id = "guest_p2",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Liam Bennett (Demo)",
                teamId = team1Id,
                teamName = "Metro Kings XI (Demo)",
                role = PlayerRole.ALL_ROUNDER.name,
                battingStyle = "Left-hand bat",
                bowlingStyle = "Left-arm fast-medium",
                matchesPlayed = 18,
                inningsBatted = 15,
                runs = 385,
                ballsFaced = 270,
                fours = 34,
                sixes = 17,
                highestScore = 61,
                notOuts = 4,
                wickets = 27,
                ballsBowled = 384,
                runsConceded = 412,
                bestBowlingWickets = 4,
                bestBowlingRuns = 21,
                catches = 11,
                recentScores = listOf(28, 44, 61, 12, 39, 51),
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            PlayerProfile(
                id = "guest_p3",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Zaid Qureshi (Demo)",
                teamId = team2Id,
                teamName = "Thames Strikers (Demo)",
                role = PlayerRole.WICKETKEEPER.name,
                battingStyle = "Right-hand bat",
                bowlingStyle = "Does not bowl",
                matchesPlayed = 16,
                inningsBatted = 16,
                runs = 514,
                ballsFaced = 362,
                fours = 55,
                sixes = 15,
                highestScore = 82,
                notOuts = 2,
                catches = 14,
                stumpings = 7,
                recentScores = listOf(31, 82, 24, 49, 66, 38),
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            PlayerProfile(
                id = "guest_p4",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Marcus Cole (Demo)",
                teamId = team2Id,
                teamName = "Thames Strikers (Demo)",
                role = PlayerRole.BOWLER.name,
                battingStyle = "Right-hand bat",
                bowlingStyle = "Right-arm fast",
                matchesPlayed = 16,
                inningsBatted = 8,
                runs = 76,
                ballsFaced = 62,
                fours = 6,
                sixes = 3,
                highestScore = 22,
                notOuts = 3,
                wickets = 31,
                ballsBowled = 360,
                runsConceded = 378,
                bestBowlingWickets = 5,
                bestBowlingRuns = 18,
                catches = 5,
                recentScores = listOf(8, 14, 22, 4, 11),
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            PlayerProfile(
                id = "guest_p5",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Rohan Mehta (Demo)",
                teamId = team1Id,
                teamName = "Metro Kings XI (Demo)",
                role = PlayerRole.ALL_ROUNDER.name,
                battingStyle = "Right-hand bat",
                bowlingStyle = "Legbreak googly",
                matchesPlayed = 15,
                inningsBatted = 13,
                runs = 298,
                ballsFaced = 212,
                fours = 27,
                sixes = 9,
                highestScore = 54,
                notOuts = 2,
                wickets = 19,
                ballsBowled = 300,
                runsConceded = 342,
                bestBowlingWickets = 3,
                bestBowlingRuns = 24,
                catches = 8,
                recentScores = listOf(18, 54, 33, 21, 46),
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            PlayerProfile(
                id = "guest_p6",
                userId = GUEST_UID,
                memberUids = listOf(GUEST_UID),
                name = "Ethan Wright (Demo)",
                teamId = team2Id,
                teamName = "Thames Strikers (Demo)",
                role = PlayerRole.BATTER.name,
                battingStyle = "Left-hand bat",
                bowlingStyle = "Right-arm medium",
                matchesPlayed = 14,
                inningsBatted = 14,
                runs = 471,
                ballsFaced = 335,
                fours = 49,
                sixes = 16,
                highestScore = 88,
                notOuts = 1,
                catches = 6,
                recentScores = listOf(62, 15, 88, 41, 70),
                demoData = true,
                createdAt = now,
                updatedAt = now
            )
        )

        val teams = listOf(
            Team(
                id = team1Id,
                userId = GUEST_UID,
                controllerUids = listOf(GUEST_UID),
                memberUids = listOf(GUEST_UID),
                name = "Metro Kings XI (Demo)",
                shortName = "MKX",
                captainPlayerId = "guest_p1",
                wicketkeeperPlayerId = "guest_p2",
                playingXiIds = listOf("guest_p1", "guest_p2", "guest_p5"),
                substituteIds = emptyList(),
                playerIds = listOf("guest_p1", "guest_p2", "guest_p5"),
                inviteCode = "MKX26",
                matchesPlayed = 18,
                wins = 13,
                losses = 5,
                netRunRate = 1.245,
                demoData = true,
                createdAt = now,
                updatedAt = now
            ),
            Team(
                id = team2Id,
                userId = GUEST_UID,
                controllerUids = listOf(GUEST_UID),
                memberUids = listOf(GUEST_UID),
                name = "Thames Strikers (Demo)",
                shortName = "THS",
                captainPlayerId = "guest_p3",
                wicketkeeperPlayerId = "guest_p3",
                playingXiIds = listOf("guest_p3", "guest_p4", "guest_p6"),
                substituteIds = emptyList(),
                playerIds = listOf("guest_p3", "guest_p4", "guest_p6"),
                inviteCode = "THS26",
                matchesPlayed = 16,
                wins = 10,
                losses = 6,
                netRunRate = 0.680,
                demoData = true,
                createdAt = now,
                updatedAt = now
            )
        )

        // Build Live Demo Match with realistic ball-by-ball history
        val liveMatchId = "guest_demo_live_1"
        val liveEngine = CricketScoringEngine(
            format = MatchFormat.T20,
            oversLimit = 20,
            playersPerSide = 11,
            maxOversPerBowler = 4,
            teamAName = "Metro Kings XI (Demo)",
            teamBName = "Thames Strikers (Demo)",
            firstBattingTeam = "Metro Kings XI (Demo)",
            firstBowlingTeam = "Thames Strikers (Demo)",
            initialStriker = "Aarav Sharma (Demo)",
            initialNonStriker = "Liam Bennett (Demo)",
            initialBowler = "Marcus Cole (Demo)"
        )
        val liveInputs = listOf(
            DeliveryInput(batterRuns = 4),
            DeliveryInput(batterRuns = 1),
            DeliveryInput(extraType = ExtraType.WIDE),
            DeliveryInput(batterRuns = 0),
            DeliveryInput(batterRuns = 6),
            DeliveryInput(batterRuns = 2),
            DeliveryInput(
                batterRuns = 0,
                wicketType = WicketType.CAUGHT,
                dismissedBatterName = "Liam Bennett (Demo)",
                fielderName = "Zaid Qureshi (Demo)",
                nextBatterName = "Rohan Mehta (Demo)"
            )
        )
        val liveDeliveries = mutableListOf<DeliveryRecord>()
        for (inp in liveInputs) {
            liveEngine.recordDelivery(inp).getOrNull()?.let { d ->
                liveDeliveries.add(toGuestDeliveryRecord(liveMatchId, d))
            }
        }
        liveEngine.setBowler("Ethan Wright (Demo)")
        liveEngine.recordDelivery(DeliveryInput(batterRuns = 1)).getOrNull()?.let {
            liveDeliveries.add(toGuestDeliveryRecord(liveMatchId, it))
        }
        liveEngine.recordDelivery(DeliveryInput(batterRuns = 4)).getOrNull()?.let {
            liveDeliveries.add(toGuestDeliveryRecord(liveMatchId, it))
        }
        val liveState = liveEngine.getState()
        val liveMatch = CricketMatch(
            id = liveMatchId,
            userId = GUEST_UID,
            controllerUids = listOf(GUEST_UID),
            publicShared = false,
            shareCode = "DEMO20",
            format = MatchFormat.T20.name,
            oversLimit = 20L,
            playersPerSide = 11L,
            maxOversPerBowler = 4L,
            teamAId = team1Id,
            teamAName = "Metro Kings XI (Demo)",
            teamAShort = "MKX",
            teamBId = team2Id,
            teamBName = "Thames Strikers (Demo)",
            teamBShort = "THS",
            venue = "Regent's Park Oval (Demo)",
            status = MatchStatus.LIVE.name,
            tossWinnerName = "Metro Kings XI (Demo)",
            tossDecision = "BAT",
            currentInnings = 1L,
            battingTeamName = liveState.activeInnings.battingTeamName,
            bowlingTeamName = liveState.activeInnings.bowlingTeamName,
            totalRuns = liveState.activeInnings.totalRuns.toLong(),
            wickets = liveState.activeInnings.wickets.toLong(),
            legalBalls = liveState.activeInnings.legalBalls.toLong(),
            targetRuns = 0L,
            strikerName = liveState.activeInnings.strikerName,
            nonStrikerName = liveState.activeInnings.nonStrikerName,
            bowlerName = liveState.activeInnings.currentBowlerName,
            recentBalls = liveState.activeInnings.recentDeliveries.map { it.shortNotation() },
            resultSummary = liveState.resultSummary,
            teamAPlayerNames = listOf("Aarav Sharma (Demo)", "Liam Bennett (Demo)", "Rohan Mehta (Demo)", "Dev Patel", "Noah Grant"),
            teamBPlayerNames = listOf("Marcus Cole (Demo)", "Zaid Qureshi (Demo)", "Ethan Wright (Demo)", "Owen Bell", "Tariq Ali"),
            demoData = true,
            createdAt = now,
            updatedAt = now
        )

        // Build Completed Match History Demo
        val historyMatchId = "guest_demo_completed_1"
        val histEngine = CricketScoringEngine(
            format = MatchFormat.T10,
            oversLimit = 2,
            playersPerSide = 11,
            maxOversPerBowler = 1,
            teamAName = "Camden Royals (Demo)",
            teamBName = "Metro Kings XI (Demo)",
            firstBattingTeam = "Camden Royals (Demo)",
            firstBowlingTeam = "Metro Kings XI (Demo)",
            initialStriker = "H. Patel",
            initialNonStriker = "S. Roy",
            initialBowler = "Liam Bennett (Demo)",
            secondInningsInitialStriker = "Aarav Sharma (Demo)",
            secondInningsInitialNonStriker = "Rohan Mehta (Demo)",
            secondInningsInitialBowler = "D. Hughes"
        )
        val histDeliveries = mutableListOf<DeliveryRecord>()
        val inn1Inputs = listOf(
            DeliveryInput(batterRuns = 2),
            DeliveryInput(batterRuns = 4),
            DeliveryInput(batterRuns = 1),
            DeliveryInput(batterRuns = 0),
            DeliveryInput(batterRuns = 6),
            DeliveryInput(batterRuns = 1),
        )
        for (inp in inn1Inputs) {
            histEngine.recordDelivery(inp).getOrNull()?.let {
                histDeliveries.add(toGuestDeliveryRecord(historyMatchId, it))
            }
        }
        histEngine.setBowler("Rohan Mehta (Demo)")
        repeat(6) {
            histEngine.recordDelivery(DeliveryInput(batterRuns = 1)).getOrNull()?.let {
                histDeliveries.add(toGuestDeliveryRecord(historyMatchId, it))
            }
        }
        histEngine.startSecondInnings("Aarav Sharma (Demo)", "Rohan Mehta (Demo)", "D. Hughes")
        listOf(
            DeliveryInput(batterRuns = 4),
            DeliveryInput(batterRuns = 6),
            DeliveryInput(batterRuns = 4),
            DeliveryInput(batterRuns = 4),
            DeliveryInput(batterRuns = 4)
        ).forEach { inp ->
            histEngine.recordDelivery(inp).getOrNull()?.let {
                histDeliveries.add(toGuestDeliveryRecord(historyMatchId, it))
            }
        }
        val histState = histEngine.getState()
        val historyMatch = CricketMatch(
            id = historyMatchId,
            userId = GUEST_UID,
            controllerUids = listOf(GUEST_UID),
            publicShared = false,
            shareCode = "HIST10",
            format = MatchFormat.T10.name,
            oversLimit = 2L,
            playersPerSide = 11L,
            maxOversPerBowler = 1L,
            teamAId = "guest_team_camden",
            teamAName = "Camden Royals (Demo)",
            teamAShort = "CMR",
            teamBId = team1Id,
            teamBName = "Metro Kings XI (Demo)",
            teamBShort = "MKX",
            venue = "Hampstead Heath Ground (Demo)",
            status = MatchStatus.COMPLETED.name,
            tossWinnerName = "Camden Royals (Demo)",
            tossDecision = "BAT",
            currentInnings = 2L,
            battingTeamName = histState.activeInnings.battingTeamName,
            bowlingTeamName = histState.activeInnings.bowlingTeamName,
            totalRuns = histState.activeInnings.totalRuns.toLong(),
            wickets = histState.activeInnings.wickets.toLong(),
            legalBalls = histState.activeInnings.legalBalls.toLong(),
            targetRuns = histState.activeInnings.targetRuns.toLong(),
            strikerName = histState.activeInnings.strikerName,
            nonStrikerName = histState.activeInnings.nonStrikerName,
            bowlerName = histState.activeInnings.currentBowlerName,
            recentBalls = histState.activeInnings.recentDeliveries.map { it.shortNotation() },
            resultSummary = histState.resultSummary,
            winnerTeamName = histState.winnerTeamName,
            teamAPlayerNames = listOf("H. Patel", "S. Roy", "D. Hughes"),
            teamBPlayerNames = listOf("Aarav Sharma (Demo)", "Rohan Mehta (Demo)", "Liam Bennett (Demo)"),
            demoData = true,
            createdAt = now,
            updatedAt = now
        )

        val tournament = Tournament(
            id = "guest_demo_tour_1",
            userId = GUEST_UID,
            controllerUids = listOf(GUEST_UID),
            publicShared = false,
            name = "London Club T20 Cup (Demo)",
            format = MatchFormat.T20.name,
            oversLimit = 20L,
            tournamentType = "LEAGUE_KNOCKOUT",
            teamNames = listOf("Metro Kings XI (Demo)", "Thames Strikers (Demo)", "Camden Royals (Demo)", "Richmond CC (Demo)"),
            standings = listOf(
                mapOf("teamName" to "Metro Kings XI (Demo)", "played" to 4L, "won" to 3L, "lost" to 1L, "tied" to 0L, "points" to 6L, "runsFor" to 684L, "ballsFaced" to 468L, "runsAgainst" to 612L, "ballsBowled" to 480L, "nrr" to 1.120),
                mapOf("teamName" to "Thames Strikers (Demo)", "played" to 4L, "won" to 3L, "lost" to 1L, "tied" to 0L, "points" to 6L, "runsFor" to 648L, "ballsFaced" to 480L, "runsAgainst" to 601L, "ballsBowled" to 474L, "nrr" to 0.492),
                mapOf("teamName" to "Camden Royals (Demo)", "played" to 4L, "won" to 1L, "lost" to 3L, "tied" to 0L, "points" to 2L, "runsFor" to 590L, "ballsFaced" to 480L, "runsAgainst" to 644L, "ballsBowled" to 468L, "nrr" to -0.881),
                mapOf("teamName" to "Richmond CC (Demo)", "played" to 4L, "won" to 1L, "lost" to 3L, "tied" to 0L, "points" to 2L, "runsFor" to 575L, "ballsFaced" to 480L, "runsAgainst" to 640L, "ballsBowled" to 480L, "nrr" to -0.813)
            ),
            fixtures = listOf(
                mapOf("fixtureId" to "fx_1", "round" to "Group Stage", "teamAName" to "Metro Kings XI (Demo)", "teamBName" to "Thames Strikers (Demo)", "status" to "LIVE", "scoreSummary" to "In Progress", "winnerName" to ""),
                mapOf("fixtureId" to "sf_1", "round" to "Semi-Final 1", "teamAName" to "Metro Kings XI (Demo)", "teamBName" to "Richmond CC (Demo)", "status" to "SCHEDULED", "scoreSummary" to "Sat 14:00 • Oval 1", "winnerName" to ""),
                mapOf("fixtureId" to "sf_2", "round" to "Semi-Final 2", "teamAName" to "Thames Strikers (Demo)", "teamBName" to "Camden Royals (Demo)", "status" to "SCHEDULED", "scoreSummary" to "Sun 14:00 • Oval 2", "winnerName" to ""),
                mapOf("fixtureId" to "final", "round" to "Final", "teamAName" to "Winner SF1", "teamBName" to "Winner SF2", "status" to "SCHEDULED", "scoreSummary" to "Championship Final", "winnerName" to "")
            ),
            status = "ACTIVE",
            demoData = true,
            createdAt = now,
            updatedAt = now
        )

        val drsReview = DrsReview(
            id = "guest_demo_drs_1",
            userId = GUEST_UID,
            matchId = liveMatchId,
            deliveryId = "guest_del_1",
            matchTitle = "Metro Kings XI vs Thames Strikers (Demo)",
            overBallLabel = "1.2",
            category = DrsCategory.LBW.name,
            videoUri = "",
            umpireDecision = UmpireDecision.NOT_OUT.name,
            finalOutcome = DrsOutcome.UMPIRES_CALL.name,
            notes = "Sample manual crease & impact line check: pitched outside off, impact on off stump.",
            primaryTimestampMs = 0L,
            compareTimestampMs = 0L,
            annotations = emptyList(),
            createdAt = now,
            updatedAt = now
        )

        return GuestSeedBundle(
            profile = profile,
            teams = teams,
            players = players,
            matches = listOf(liveMatch, historyMatch),
            deliveriesByMatchId = mapOf(
                liveMatchId to liveDeliveries,
                historyMatchId to histDeliveries
            ),
            tournaments = listOf(tournament),
            drsReviews = listOf(drsReview)
        )
    }

    fun toGuestDeliveryRecord(matchId: String, d: com.example.domain.scoring.RecordedDelivery): DeliveryRecord {
        return DeliveryRecord(
            id = "guest_del_${matchId}_${d.sequenceNumber}",
            userId = GUEST_UID,
            controllerUids = listOf(GUEST_UID),
            publicShared = false,
            matchId = matchId,
            sequenceNumber = d.sequenceNumber.toLong(),
            inningsNumber = d.inningsNumber.toLong(),
            overNumber = d.overNumber.toLong(),
            ballNumber = d.ballNumber.toLong(),
            legalDelivery = d.legalDelivery,
            strikerId = d.strikerId,
            strikerName = d.strikerName,
            nonStrikerId = d.nonStrikerId,
            nonStrikerName = d.nonStrikerName,
            bowlerId = d.bowlerId,
            bowlerName = d.bowlerName,
            batterRuns = d.batterRuns.toLong(),
            extraType = d.extraType.name,
            extraRuns = d.extraRuns.toLong(),
            totalRunsOnBall = d.totalRunsOnBall.toLong(),
            wicketType = d.wicketType.name,
            dismissedPlayerId = d.dismissedPlayerId,
            dismissedPlayerName = d.dismissedPlayerName,
            fielderName = d.fielderName,
            nextBatterName = d.nextBatterName,
            createdAt = Timestamp.now()
        )
    }
}
