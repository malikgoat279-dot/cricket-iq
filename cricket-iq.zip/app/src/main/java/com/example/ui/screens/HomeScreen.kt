package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CricketMatch
import com.example.data.model.MatchStatus
import com.example.data.model.PlayerProfile
import com.example.data.model.Team
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.ui.components.BallChip
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricTile
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson
import com.example.ui.theme.WicketCrimsonBg

@Composable
fun HomeScreen(
    isGuestMode: Boolean = false,
    userProfile: UserProfile?,
    myMatches: List<CricketMatch>,
    teams: List<Team>,
    players: List<PlayerProfile>,
    tournaments: List<Tournament>,
    onStartNewMatch: () -> Unit,
    onContinueMatch: (CricketMatch) -> Unit,
    onOpenLiveMatch: (CricketMatch) -> Unit,
    onOpenTeams: () -> Unit,
    onOpenDrsReview: () -> Unit,
    onLoadDemoData: () -> Unit,
    onOpenProfileSignIn: () -> Unit = {}
) {
    val liveMatches = myMatches.filter {
        it.parsedStatus == MatchStatus.LIVE || it.parsedStatus == MatchStatus.INNINGS_BREAK
    }
    val recentMatches = myMatches.filter { it.parsedStatus == MatchStatus.COMPLETED }.take(5)
    val resumableMatch = liveMatches.firstOrNull()
    val upcomingFixtures = tournaments.flatMap { tour ->
        tour.fixtures.filter { (it["status"] as? String) != "COMPLETED" }
            .map { tour.name to it }
    }.take(4)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Hero Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, NavyOutline, RoundedCornerShape(24.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_stadium_hero),
                    contentDescription = "Cricket IQ Match Centre Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                )
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    NavyBase.copy(alpha = 0.2f),
                                    NavyBase.copy(alpha = 0.88f),
                                    NavyBase
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CRICKET IQ",
                                style = MaterialTheme.typography.headlineMedium,
                                color = PitchGreen
                            )
                            Text(
                                text = if (isGuestMode) "Welcome, Guest Scorer" else "Welcome, ${userProfile?.displayName ?: "Scorer"}",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                        }
                        if (isGuestMode) {
                            Surface(
                                color = NavyElevated,
                                shape = RoundedCornerShape(50),
                                border = androidx.compose.foundation.BorderStroke(1.dp, BoundaryGold.copy(alpha = 0.7f)),
                                modifier = Modifier
                                    .clickable { onOpenProfileSignIn() }
                                    .testTag("home_guest_signin_chip")
                            ) {
                                Text(
                                    text = "GUEST • SIGN IN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = BoundaryGold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        } else {
                            StatusPill(
                                text = userProfile?.parsedTier?.title?.uppercase() ?: "FREE",
                                color = PitchGreen,
                                backgroundColor = PitchGreenMuted
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onStartNewMatch,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PitchGreen,
                                contentColor = NavyBase
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("home_start_match_button")
                        ) {
                            Icon(Icons.Filled.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Start Match", fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = onOpenDrsReview,
                            border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PitchGreen),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("home_drs_button")
                        ) {
                            Icon(Icons.Filled.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("DRS Review", fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }

                    if (resumableMatch != null) {
                        Surface(
                            color = PitchGreenMuted.copy(alpha = 0.85f),
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onContinueMatch(resumableMatch) }
                                .testTag("home_continue_scoring_card")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "CONTINUE SCORING • ${resumableMatch.format}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PitchGreen
                                    )
                                    Text(
                                        text = "${resumableMatch.battingTeamName} ${resumableMatch.totalRuns}/${resumableMatch.wickets} (${resumableMatch.oversString})",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color.White
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Continue scoring",
                                    tint = PitchGreen
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Workspace Onboarding if empty
        if (myMatches.isEmpty() && teams.isEmpty() && players.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.SportsCricket,
                    title = "Ready for Match Day",
                    message = "Start scoring a live match immediately, create your club squad, or load clearly-labelled sample club data to explore Cricket IQ.",
                    action = {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onLoadDemoData,
                                colors = ButtonDefaults.buttonColors(containerColor = NavyElevated, contentColor = PitchGreen),
                                modifier = Modifier.testTag("home_load_demo_button")
                            ) {
                                Text("Load Demo Club Data")
                            }
                        }
                    }
                )
            }
        }

        // Live Matches
        if (liveMatches.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Live Matches",
                    subtitle = "${liveMatches.size} active fixture${if (liveMatches.size == 1) "" else "s"}"
                )
            }
            items(liveMatches, key = { it.id }) { match ->
                MatchSummaryCard(
                    match = match,
                    onClick = { onOpenLiveMatch(match) },
                    primaryActionLabel = "Score",
                    onPrimaryAction = { onContinueMatch(match) }
                )
            }
        }

        // My Teams
        item {
            SectionHeader(
                title = "My Teams",
                subtitle = "${teams.size} registered squad${if (teams.size == 1) "" else "s"}",
                trailing = {
                    OutlinedButton(
                        onClick = onOpenTeams,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Manage", color = PitchGreen)
                    }
                }
            )
            Spacer(Modifier.height(10.dp))
            if (teams.isEmpty()) {
                Surface(
                    color = NavyCard,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenTeams() }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Groups, contentDescription = null, tint = PitchGreen)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "Create your first club or school team and assign Playing XI.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(teams, key = { it.id }) { team ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = NavyCard),
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                            modifier = Modifier
                                .width(200.dp)
                                .clickable { onOpenTeams() }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Image(
                                        painter = painterResource(id = R.drawable.img_club_crest),
                                        contentDescription = team.name,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = team.shortName,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PitchGreen
                                        )
                                        Text(
                                            text = team.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Text(
                                    text = "${team.wins}W • ${team.losses}L • NRR ${String.format("%+.2f", team.netRunRate)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Player Performance Spotlight
        if (players.isNotEmpty()) {
            item {
                val topBatter = players.maxByOrNull { it.runs }
                val topBowler = players.maxByOrNull { it.wickets }
                SectionHeader(
                    title = "Player Performance",
                    subtitle = "Top club performers"
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (topBatter != null) {
                        MetricTile(
                            label = "LEADING BAT • ${topBatter.name}",
                            value = "${topBatter.runs} runs",
                            accent = PitchGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (topBowler != null) {
                        MetricTile(
                            label = "LEADING BOWL • ${topBowler.name}",
                            value = "${topBowler.wickets} wkts",
                            accent = BoundaryGold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Upcoming Fixtures
        if (upcomingFixtures.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Upcoming Fixtures",
                    subtitle = "Tournament schedule"
                )
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    upcomingFixtures.forEach { (tourName, fx) ->
                        Surface(
                            color = NavyCard,
                            shape = RoundedCornerShape(14.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "$tourName • ${fx["round"] as? String ?: "Match"}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SkyInfo
                                    )
                                    Text(
                                        text = "${fx["teamAName"] as? String ?: ""} vs ${fx["teamBName"] as? String ?: ""}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = fx["scoreSummary"] as? String ?: "Scheduled",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        // Recent Completed Matches
        if (recentMatches.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Recent Matches",
                    subtitle = "Completed results"
                )
            }
            items(recentMatches, key = { it.id }) { match ->
                MatchSummaryCard(
                    match = match,
                    onClick = { onOpenLiveMatch(match) },
                    primaryActionLabel = "Scorecard",
                    onPrimaryAction = { onOpenLiveMatch(match) }
                )
            }
        }
    }
}

@Composable
fun MatchSummaryCard(
    match: CricketMatch,
    onClick: () -> Unit,
    primaryActionLabel: String,
    onPrimaryAction: () -> Unit
) {
    val isLive = match.parsedStatus == MatchStatus.LIVE || match.parsedStatus == MatchStatus.INNINGS_BREAK
    Card(
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isLive) PitchGreen.copy(alpha = 0.6f) else NavyOutline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = if (isLive) "● ${match.parsedStatus.label.uppercase()}" else "COMPLETED",
                        color = if (isLive) WicketCrimson else TextSecondary,
                        backgroundColor = if (isLive) WicketCrimsonBg else NavyElevated
                    )
                    Text(
                        text = "${match.format} • ${match.venue.ifBlank { "Club Ground" }}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (match.demoData) {
                    StatusPill(text = "DEMO", color = BoundaryGold, backgroundColor = NavyElevated)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = match.battingTeamName,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "vs ${match.bowlingTeamName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${match.totalRuns}/${match.wickets}",
                        style = MaterialTheme.typography.displayMedium,
                        color = PitchGreen
                    )
                    Text(
                        text = "${match.oversString} / ${match.oversLimit} ov • CRR ${String.format("%.2f", match.currentRunRate)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }

            if (match.recentBalls.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(match.recentBalls.takeLast(8)) { ball ->
                        BallChip(ball)
                    }
                }
            }

            if (match.resultSummary.isNotBlank()) {
                Text(
                    text = match.resultSummary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = PitchGreen
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = onPrimaryAction,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.6f)),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(primaryActionLabel, color = PitchGreen, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        Icons.Filled.ArrowForward,
                        contentDescription = null,
                        tint = PitchGreen,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
