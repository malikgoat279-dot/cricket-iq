package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.PlayerProfile
import com.example.data.model.PlayerRole
import com.example.data.model.Team
import com.example.data.model.Tournament
import com.example.domain.scoring.MatchFormat
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.MetricTile
import com.example.ui.components.RunsBarChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun TeamsHubScreen(
    teams: List<Team>,
    players: List<PlayerProfile>,
    tournaments: List<Tournament>,
    onCreateTeam: (String, String) -> Unit,
    onUpdateTeamLineup: (Team, String, String, List<String>, List<String>) -> Unit,
    onCreatePlayer: (String, String, String, PlayerRole, String, String) -> Unit,
    onCreateTournament: (String, MatchFormat, Int, String, List<String>) -> Unit,
    onRecordFixtureResult: (Tournament, String, Int, Int, Int, Int) -> Unit
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = NavyCard,
            contentColor = PitchGreen
        ) {
            Tab(selected = selectedSubTab == 0, onClick = { selectedSubTab = 0 }, text = { Text("Teams") })
            Tab(selected = selectedSubTab == 1, onClick = { selectedSubTab = 1 }, text = { Text("Players") })
            Tab(selected = selectedSubTab == 2, onClick = { selectedSubTab = 2 }, text = { Text("Tournaments") })
        }

        when (selectedSubTab) {
            0 -> TeamsTabContent(
                teams = teams,
                players = players,
                onCreateTeam = onCreateTeam,
                onUpdateTeamLineup = onUpdateTeamLineup
            )
            1 -> PlayersTabContent(
                teams = teams,
                players = players,
                onCreatePlayer = onCreatePlayer
            )
            else -> TournamentsTabContent(
                teams = teams,
                players = players,
                tournaments = tournaments,
                onCreateTournament = onCreateTournament,
                onRecordFixtureResult = onRecordFixtureResult
            )
        }
    }
}

@Composable
private fun TeamsTabContent(
    teams: List<Team>,
    players: List<PlayerProfile>,
    onCreateTeam: (String, String) -> Unit,
    onUpdateTeamLineup: (Team, String, String, List<String>, List<String>) -> Unit
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }
    var managingTeam by remember { mutableStateOf<Team?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Team Management",
                subtitle = "Playing XI, Captain, Keeper & Invites",
                trailing = {
                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier.testTag("create_team_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("New Team", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        if (teams.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.Groups,
                    title = "No Teams Registered",
                    message = "Create your club or tournament team to assign captains, wicketkeepers, Playing XI, and substitutes."
                )
            }
        } else {
            items(teams, key = { it.id }) { team ->
                val teamPlayers = players.filter { it.teamId == team.id || team.playerIds.contains(it.id) }
                val captainName = players.firstOrNull { it.id == team.captainPlayerId }?.name ?: "Unassigned"
                val keeperName = players.firstOrNull { it.id == team.wicketkeeperPlayerId }?.name ?: "Unassigned"

                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_club_crest),
                                    contentDescription = team.name,
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text(team.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                        if (team.demoData) {
                                            StatusPill("DEMO", BoundaryGold, NavyElevated)
                                        }
                                    }
                                    Text(
                                        text = "${team.shortName} • Invite Code: ${team.inviteCode}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SkyInfo
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    val share = "Join ${team.name} on CRICKET IQ! Team Invite Code: ${team.inviteCode} • Record: ${team.wins}W-${team.losses}L (NRR ${String.format("%+.2f", team.netRunRate)})"
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, share)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share Team Profile & Invite"))
                                }
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = "Share Team", tint = PitchGreen)
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Captain (C): $captainName", style = MaterialTheme.typography.bodyMedium, color = PitchGreen)
                            Text("Keeper (WK): $keeperName", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                        Text(
                            text = "Playing XI: ${team.playingXiIds.size}/11 • Squad: ${teamPlayers.size} • Record: ${team.wins}W ${team.losses}L ${team.ties}T",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { managingTeam = team },
                                border = androidx.compose.foundation.BorderStroke(1.dp, PitchGreen.copy(alpha = 0.6f))
                            ) {
                                Text("Manage XI & Roles", color = PitchGreen)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        var shortName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = NavyCard,
            title = { Text("Create Team", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Team Name") }, singleLine = true)
                    OutlinedTextField(value = shortName, onValueChange = { shortName = it.take(6).uppercase() }, label = { Text("Short Code (e.g. MKX)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onCreateTeam(name, shortName)
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Create", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (managingTeam != null) {
        val team = managingTeam!!
        val squadCandidates = players.filter { it.teamId == team.id || players.isNotEmpty() }
        var captainId by remember { mutableStateOf(team.captainPlayerId) }
        var keeperId by remember { mutableStateOf(team.wicketkeeperPlayerId) }
        var xiIds by remember { mutableStateOf(team.playingXiIds.toSet()) }
        var subIds by remember { mutableStateOf(team.substituteIds.toSet()) }

        AlertDialog(
            onDismissRequest = { managingTeam = null },
            containerColor = NavyCard,
            title = { Text("${team.name} Lineup", color = Color.White) },
            text = {
                LazyColumn(
                    modifier = Modifier.height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (squadCandidates.isEmpty()) {
                        item {
                            Text("Add players in the Players tab first to build your Playing XI.", color = TextSecondary)
                        }
                    } else {
                        items(squadCandidates, key = { it.id }) { p ->
                            val inXi = xiIds.contains(p.id)
                            val inSub = subIds.contains(p.id)
                            Surface(
                                color = NavyElevated,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(p.name, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = inXi,
                                                onCheckedChange = { checked ->
                                                    if (checked && xiIds.size < 11) {
                                                        xiIds = xiIds + p.id
                                                        subIds = subIds - p.id
                                                    } else if (!checked) {
                                                        xiIds = xiIds - p.id
                                                    }
                                                }
                                            )
                                            Text("XI", style = MaterialTheme.typography.labelSmall, color = PitchGreen)
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        FilterChip(
                                            selected = captainId == p.id,
                                            onClick = { captainId = p.id },
                                            label = { Text("Captain") }
                                        )
                                        FilterChip(
                                            selected = keeperId == p.id,
                                            onClick = { keeperId = p.id },
                                            label = { Text("Keeper") }
                                        )
                                        FilterChip(
                                            selected = inSub,
                                            onClick = {
                                                if (inSub) subIds = subIds - p.id
                                                else {
                                                    subIds = subIds + p.id
                                                    xiIds = xiIds - p.id
                                                }
                                            },
                                            label = { Text("Sub") }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateTeamLineup(team, captainId, keeperId, xiIds.toList(), subIds.toList())
                        managingTeam = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Save Squad", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { managingTeam = null }) { Text("Close") }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PlayersTabContent(
    teams: List<Team>,
    players: List<PlayerProfile>,
    onCreatePlayer: (String, String, String, PlayerRole, String, String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedPlayer by remember { mutableStateOf<PlayerProfile?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            SectionHeader(
                title = "Player Profiles",
                subtitle = "Career stats auto-update after completed matches",
                trailing = {
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier.testTag("add_player_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add Player", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        if (players.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.Person,
                    title = "No Players Yet",
                    message = "Add players with batting/bowling styles to build squads and track career averages."
                )
            }
        } else {
            items(players, key = { it.id }) { p ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlayer = p }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(PitchGreenMuted),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = p.name.take(2).uppercase(),
                                        style = MaterialTheme.typography.titleSmall,
                                        color = PitchGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(p.name, style = MaterialTheme.typography.titleMedium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        text = "${p.parsedRole.label} • ${p.teamName.ifBlank { "Free Agent" }}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondary
                                    )
                                }
                            }
                            StatusPill("${p.matchesPlayed} MAT", SkyInfo, NavyElevated)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Runs: ${p.runs} (HS ${p.highestScore})", style = MaterialTheme.typography.labelMedium, color = PitchGreen)
                            Text("Avg ${String.format("%.1f", p.battingAverage)} • SR ${String.format("%.1f", p.battingStrikeRate)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Wkts: ${p.wickets} (Best ${p.bestBowlingDisplay})", style = MaterialTheme.typography.labelMedium, color = BoundaryGold)
                            Text("Econ ${String.format("%.2f", p.bowlingEconomy)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var selectedTeam by remember { mutableStateOf(teams.firstOrNull()) }
        var role by remember { mutableStateOf(PlayerRole.ALL_ROUNDER) }
        var batStyle by remember { mutableStateOf("Right-hand bat") }
        var bowlStyle by remember { mutableStateOf("Right-arm medium") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = NavyCard,
            title = { Text("Add Player Profile", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, singleLine = true)
                    Text("Playing Role", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PlayerRole.entries.forEach { r ->
                            FilterChip(selected = role == r, onClick = { role = r }, label = { Text(r.label) })
                        }
                    }
                    if (teams.isNotEmpty()) {
                        Text("Assign Team", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            teams.forEach { t ->
                                FilterChip(
                                    selected = selectedTeam?.id == t.id,
                                    onClick = { selectedTeam = t },
                                    label = { Text(t.shortName) }
                                )
                            }
                        }
                    }
                    OutlinedTextField(value = batStyle, onValueChange = { batStyle = it }, label = { Text("Batting Style") }, singleLine = true)
                    OutlinedTextField(value = bowlStyle, onValueChange = { bowlStyle = it }, label = { Text("Bowling Style") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onCreatePlayer(
                                name,
                                selectedTeam?.id ?: "",
                                selectedTeam?.name ?: "Independent",
                                role,
                                batStyle,
                                bowlStyle
                            )
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Save Player", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (selectedPlayer != null) {
        val p = selectedPlayer!!
        AlertDialog(
            onDismissRequest = { selectedPlayer = null },
            containerColor = NavyCard,
            title = {
                Column {
                    Text(p.name, color = Color.White)
                    Text("${p.parsedRole.label} • ${p.battingStyle} • ${p.bowlingStyle}", style = MaterialTheme.typography.bodyMedium, color = PitchGreen)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile("RUNS", "${p.runs}", PitchGreen, Modifier.weight(1f))
                        MetricTile("AVG", String.format("%.1f", p.battingAverage), SkyInfo, Modifier.weight(1f))
                        MetricTile("HS", "${p.highestScore}", BoundaryGold, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile("WKTS", "${p.wickets}", BoundaryGold, Modifier.weight(1f))
                        MetricTile("ECON", String.format("%.2f", p.bowlingEconomy), PitchGreen, Modifier.weight(1f))
                        MetricTile("BEST", p.bestBowlingDisplay, SkyInfo, Modifier.weight(1f))
                    }
                    if (p.recentScores.isNotEmpty()) {
                        Text("Recent Innings Form", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        RunsBarChart(
                            values = p.recentScores.map { it.toInt() },
                            labels = p.recentScores.indices.map { "I${it + 1}" }
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPlayer = null }) { Text("Close", color = PitchGreen) }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TournamentsTabContent(
    teams: List<Team>,
    players: List<PlayerProfile>,
    tournaments: List<Tournament>,
    onCreateTournament: (String, MatchFormat, Int, String, List<String>) -> Unit,
    onRecordFixtureResult: (Tournament, String, Int, Int, Int, Int) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var activeFixtureDialog by remember { mutableStateOf<Pair<Tournament, Map<String, Any>>?>(null) }

    val topScorers = remember(players) { players.sortedByDescending { it.runs }.take(3) }
    val topWicketTakers = remember(players) { players.sortedByDescending { it.wickets }.take(3) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Tournaments & Fixtures",
                subtitle = "League points tables, NRR & knockout brackets",
                trailing = {
                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier.testTag("create_tournament_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Create", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        if (players.isNotEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(18.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Tournament Leaders", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text("Top Run Scorers", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                topScorers.forEach { p ->
                                    Text("${p.name}: ${p.runs}", style = MaterialTheme.typography.bodyMedium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Column(Modifier.weight(1f)) {
                                Text("Top Wicket Takers", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                topWicketTakers.forEach { p ->
                                    Text("${p.name}: ${p.wickets}", style = MaterialTheme.typography.bodyMedium, color = BoundaryGold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (tournaments.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.EmojiEvents,
                    title = "No Tournaments Created",
                    message = "Create a League, Knockout, or League + Semi-Finals/Final competition with automatic Net Run Rate (NRR) tracking."
                )
            }
        } else {
            items(tournaments, key = { it.id }) { t ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(t.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                Text("${t.format} • ${t.oversLimit} overs • ${t.tournamentType.replace("_", " + ")}", style = MaterialTheme.typography.labelSmall, color = SkyInfo)
                            }
                            if (t.demoData) StatusPill("DEMO", BoundaryGold, NavyElevated)
                        }

                        // Points Table
                        if (t.standings.isNotEmpty()) {
                            Text("Points Table & NRR", style = MaterialTheme.typography.titleSmall, color = PitchGreen)
                            Row(Modifier.fillMaxWidth()) {
                                Text("Team", Modifier.weight(2f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("P", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("W", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("L", Modifier.weight(0.5f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("PTS", Modifier.weight(0.6f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                Text("NRR", Modifier.weight(0.9f), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            }
                            HorizontalDivider(color = NavyOutline)
                            t.standings.forEach { row ->
                                val teamName = row["teamName"] as? String ?: ""
                                val played = (row["played"] as? Number)?.toInt() ?: 0
                                val won = (row["won"] as? Number)?.toInt() ?: 0
                                val lost = (row["lost"] as? Number)?.toInt() ?: 0
                                val pts = (row["points"] as? Number)?.toInt() ?: 0
                                val nrr = (row["nrr"] as? Number)?.toDouble() ?: 0.0
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(teamName, Modifier.weight(2f), style = MaterialTheme.typography.bodyMedium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("$played", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                    Text("$won", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                    Text("$lost", Modifier.weight(0.5f), style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                                    Text("$pts", Modifier.weight(0.6f), style = MaterialTheme.typography.labelMedium, color = PitchGreen, fontWeight = FontWeight.Bold)
                                    Text(String.format("%+.2f", nrr), Modifier.weight(0.9f), style = MaterialTheme.typography.labelMedium, color = if (nrr >= 0) PitchGreen else TextSecondary)
                                }
                            }
                        }

                        // Fixtures
                        if (t.fixtures.isNotEmpty()) {
                            HorizontalDivider(color = NavyOutline)
                            Text("Fixtures & Knockouts", style = MaterialTheme.typography.titleSmall, color = SkyInfo)
                            t.fixtures.forEach { fx ->
                                val fxId = fx["fixtureId"] as? String ?: ""
                                val round = fx["round"] as? String ?: ""
                                val tA = fx["teamAName"] as? String ?: ""
                                val tB = fx["teamBName"] as? String ?: ""
                                val status = fx["status"] as? String ?: "SCHEDULED"
                                val scoreSummary = fx["scoreSummary"] as? String ?: ""

                                Surface(
                                    color = NavyElevated,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text(round, style = MaterialTheme.typography.labelSmall, color = BoundaryGold)
                                            Text("$tA vs $tB", style = MaterialTheme.typography.bodyMedium, color = Color.White, fontWeight = FontWeight.SemiBold)
                                            Text(scoreSummary, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                        }
                                        if (status != "COMPLETED" && fxId.isNotBlank()) {
                                            TextButton(onClick = { activeFixtureDialog = t to fx }) {
                                                Text("Enter Result", color = PitchGreen)
                                            }
                                        } else {
                                            StatusPill(status, PitchGreen, PitchGreenMuted)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        var tName by remember { mutableStateOf("") }
        var fmt by remember { mutableStateOf(MatchFormat.T20) }
        var tType by remember { mutableStateOf("LEAGUE_KNOCKOUT") }
        var teamsCsv by remember {
            mutableStateOf(
                if (teams.size >= 2) teams.joinToString(", ") { it.name }
                else "Northwood XI, Surrey Strikers, Camden Royals, Richmond CC"
            )
        }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = NavyCard,
            title = { Text("Create Tournament", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = tName, onValueChange = { tName = it }, label = { Text("Tournament Name") }, singleLine = true)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("LEAGUE" to "League", "KNOCKOUT" to "Knockout", "LEAGUE_KNOCKOUT" to "League + Knockouts").forEach { (k, label) ->
                            FilterChip(selected = tType == k, onClick = { tType = k }, label = { Text(label) })
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(MatchFormat.T10, MatchFormat.T20, MatchFormat.ODI).forEach { f ->
                            FilterChip(selected = fmt == f, onClick = { fmt = f }, label = { Text(f.displayName) })
                        }
                    }
                    OutlinedTextField(
                        value = teamsCsv,
                        onValueChange = { teamsCsv = it },
                        label = { Text("Teams (comma-separated)") },
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val teamList = teamsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        if (tName.isNotBlank() && teamList.size >= 2) {
                            onCreateTournament(tName, fmt, fmt.defaultOvers, tType, teamList)
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Create", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (activeFixtureDialog != null) {
        val (tour, fx) = activeFixtureDialog!!
        val fxId = fx["fixtureId"] as? String ?: ""
        val tA = fx["teamAName"] as? String ?: "Team A"
        val tB = fx["teamBName"] as? String ?: "Team B"
        var scoreA by remember { mutableStateOf("155") }
        var oversA by remember { mutableStateOf(tour.oversLimit.toString()) }
        var scoreB by remember { mutableStateOf("142") }
        var oversB by remember { mutableStateOf(tour.oversLimit.toString()) }

        AlertDialog(
            onDismissRequest = { activeFixtureDialog = null },
            containerColor = NavyCard,
            title = { Text("Record Match Result", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("$tA vs $tB", color = PitchGreen, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = scoreA, onValueChange = { scoreA = it.filter { c -> c.isDigit() } }, label = { Text("$tA Runs") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = oversA, onValueChange = { oversA = it.filter { c -> c.isDigit() } }, label = { Text("Overs") }, modifier = Modifier.weight(0.7f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = scoreB, onValueChange = { scoreB = it.filter { c -> c.isDigit() } }, label = { Text("$tB Runs") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = oversB, onValueChange = { oversB = it.filter { c -> c.isDigit() } }, label = { Text("Overs") }, modifier = Modifier.weight(0.7f))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val rA = scoreA.toIntOrNull() ?: 0
                        val bA = ((oversA.toIntOrNull() ?: tour.oversLimit.toInt()).coerceAtLeast(1)) * 6
                        val rB = scoreB.toIntOrNull() ?: 0
                        val bB = ((oversB.toIntOrNull() ?: tour.oversLimit.toInt()).coerceAtLeast(1)) * 6
                        onRecordFixtureResult(tour, fxId, rA, bA, rB, bB)
                        activeFixtureDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                ) {
                    Text("Save & Update NRR", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeFixtureDialog = null }) { Text("Cancel") }
            }
        )
    }
}
