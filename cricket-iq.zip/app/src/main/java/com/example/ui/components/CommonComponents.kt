package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.BoundaryGoldBg
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson
import com.example.ui.theme.WicketCrimsonBg
import kotlin.math.max

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailing != null) {
            trailing()
        }
    }
}

@Composable
fun StatusPill(
    text: String,
    color: Color = PitchGreen,
    backgroundColor: Color = PitchGreenMuted
) {
    Surface(
        color = backgroundColor,
        shape = RoundedCornerShape(50),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.55f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun BallChip(label: String) {
    val (bg, fg, border) = when {
        label.startsWith("W") && !label.endsWith("d") -> Triple(WicketCrimsonBg, WicketCrimson, WicketCrimson)
        label == "4" || label == "6" -> Triple(BoundaryGoldBg, BoundaryGold, BoundaryGold)
        label.contains("Wd") || label.contains("Nb") -> Triple(NavyElevated, SkyInfo, SkyInfo)
        label == "0" -> Triple(NavyElevated, TextMuted, NavyOutline)
        else -> Triple(PitchGreenMuted, PitchGreen, PitchGreen.copy(alpha = 0.6f))
    }
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, border, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = fg,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    message: String,
    action: (@Composable () -> Unit)? = null
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(PitchGreenMuted),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = PitchGreen,
                    modifier = Modifier.size(28.dp)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            if (action != null) {
                Spacer(Modifier.height(4.dp))
                action()
            }
        }
    }
}

@Composable
fun RunsBarChart(
    values: List<Int>,
    labels: List<String>,
    accentColor: Color = PitchGreen,
    modifier: Modifier = Modifier
) {
    if (values.isEmpty()) return
    val maxVal = max(1, values.maxOrNull() ?: 1)
    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .padding(top = 8.dp)
        ) {
            val count = values.size
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.56f).coerceAtMost(36.dp.toPx())
            val chartHeight = size.height - 12.dp.toPx()

            // Grid lines
            for (i in 0..3) {
                val y = chartHeight * (i / 3f)
                drawLine(
                    color = NavyOutline.copy(alpha = 0.45f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            values.forEachIndexed { idx, v ->
                val ratio = v.toFloat() / maxVal.toFloat()
                val barHeight = (chartHeight * ratio).coerceAtLeast(4.dp.toPx())
                val x = idx * slotWidth + (slotWidth - barWidth) / 2f
                val y = chartHeight - barHeight
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(accentColor, accentColor.copy(alpha = 0.35f))
                    ),
                    topLeft = Offset(x, y),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            labels.forEachIndexed { i, lbl ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = values.getOrElse(i) { 0 }.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                    Text(
                        text = lbl,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }
        }
    }
}

@Composable
fun TrendLineChart(
    seriesA: List<Float>,
    seriesB: List<Float> = emptyList(),
    colorA: Color = PitchGreen,
    colorB: Color = SkyInfo,
    modifier: Modifier = Modifier
) {
    if (seriesA.isEmpty()) return
    val maxVal = max(1f, (seriesA + seriesB).maxOrNull() ?: 1f)
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .padding(vertical = 8.dp)
    ) {
        val h = size.height
        val w = size.width
        for (i in 0..3) {
            val y = h * (i / 3f)
            drawLine(
                color = NavyOutline.copy(alpha = 0.4f),
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        fun drawSeries(data: List<Float>, color: Color) {
            if (data.size == 1) {
                val y = h - (data[0] / maxVal) * h
                drawCircle(color = color, radius = 5.dp.toPx(), center = Offset(w / 2f, y))
                return
            }
            val path = Path()
            val step = w / (data.size - 1).coerceAtLeast(1)
            data.forEachIndexed { idx, value ->
                val x = idx * step
                val y = h - ((value / maxVal) * (h - 12.dp.toPx())) - 6.dp.toPx()
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
            )
            data.forEachIndexed { idx, value ->
                val x = idx * step
                val y = h - ((value / maxVal) * (h - 12.dp.toPx())) - 6.dp.toPx()
                drawCircle(color = color, radius = 4.dp.toPx(), center = Offset(x, y))
            }
        }

        drawSeries(seriesA, colorA)
        if (seriesB.isNotEmpty()) drawSeries(seriesB, colorB)
    }
}

@Composable
fun MetricTile(
    label: String,
    value: String,
    accent: Color = PitchGreen,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NavyCard,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                color = accent,
                maxLines = 1
            )
        }
    }
}
