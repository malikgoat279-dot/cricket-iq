package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CricketMatch
import com.example.data.model.DeliveryRecord
import com.example.data.model.DrsReview
import com.example.data.model.MatchStatus
import com.example.data.model.PlayerProfile
import com.example.data.model.PlayerRole
import com.example.data.model.SubscriptionTier
import com.example.data.model.Team
import com.example.data.model.Tournament
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.remote.CricketIqRepository
import com.example.domain.scoring.CricketScoringEngine
import com.example.domain.scoring.DeliveryInput
import com.example.domain.scoring.MatchEngineState
import com.example.domain.scoring.MatchFormat
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class CricketIqViewModel(
    private val repository: CricketIqRepository?,
    private val authenticatedUserId: String?
) : ViewModel() {

    val isGuestMode: Boolean = authenticatedUserId == null || repository == null
    val effectiveUserId: String = authenticatedUserId ?: GuestDemoFactory.GUEST_UID

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _activeScoringMatchId = MutableStateFlow<String?>(null)
    val activeScoringMatchId: StateFlow<String?> = _activeScoringMatchId.asStateFlow()

    private val _selectedLiveMatchId = MutableStateFlow<String?>(null)
    val selectedLiveMatchId: StateFlow<String?> = _selectedLiveMatchId.asStateFlow()

    private val _activeEngineState = MutableStateFlow<MatchEngineState?>(null)
    val activeEngineState: StateFlow<MatchEngineState?> = _activeEngineState.asStateFlow()

    private var activeEngine: CricketScoringEngine? = null
    private var lastSyncedMatchId: String? = null
    private var lastLoadedDeliveries: List<DeliveryRecord> = emptyList()
    private val statsSyncedForMatchIds = mutableSetOf<String>()

    // Local in-session state for Guest Mode
    private val initialGuestSeed = if (isGuestMode) GuestDemoFactory.createSeedData() else null
    private val _guestProfile = MutableStateFlow(initialGuestSeed?.profile)
    private val _guestMatches = MutableStateFlow(initialGuestSeed?.matches.orEmpty())
    private val _guestDeliveriesByMatch = MutableStateFlow(initialGuestSeed?.deliveriesByMatchId.orEmpty())
    private val _guestTeams = MutableStateFlow(initialGuestSeed?.teams.orEmpty())
    private val _guestPlayers = MutableStateFlow(initialGuestSeed?.players.orEmpty())
    private val _guestTournaments = MutableStateFlow(initialGuestSeed?.tournaments.orEmpty())
    private val _guestDrsReviews = MutableStateFlow(initialGuestSeed?.drsReviews.orEmpty())

    init {
        if (!isGuestMode && repository != null) {
            viewModelScope.launch {
                repository.ensureUserProfile()
            }
        }
    }

    private fun <T> Flow<T>.toUiStateFlow(tag: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Stream error in $tag", root)
                emit(UiState.Error(root.message ?: "Failed to load $tag"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    val userProfile: StateFlow<UiState<UserProfile?>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestProfile.map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.profile))
        } else {
            repository.observeUserProfile(authenticatedUserId).toUiStateFlow("profile")
        }

    val myMatches: StateFlow<UiState<List<CricketMatch>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestMatches.map<List<CricketMatch>, UiState<List<CricketMatch>>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.matches.orEmpty()))
        } else {
            repository.observeMyMatches(authenticatedUserId).toUiStateFlow("myMatches")
        }

    val publicSharedMatches: StateFlow<UiState<List<CricketMatch>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            MutableStateFlow<UiState<List<CricketMatch>>>(UiState.Success(emptyList())).asStateFlow()
        } else {
            repository.observePublicSharedMatches(authenticatedUserId).toUiStateFlow("publicMatches")
        }

    val teams: StateFlow<UiState<List<Team>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestTeams.map<List<Team>, UiState<List<Team>>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.teams.orEmpty()))
        } else {
            repository.observeTeams(authenticatedUserId).toUiStateFlow("teams")
        }

    val players: StateFlow<UiState<List<PlayerProfile>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestPlayers.map<List<PlayerProfile>, UiState<List<PlayerProfile>>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.players.orEmpty()))
        } else {
            repository.observePlayers(authenticatedUserId).toUiStateFlow("players")
        }

    val tournaments: StateFlow<UiState<List<Tournament>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestTournaments.map<List<Tournament>, UiState<List<Tournament>>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.tournaments.orEmpty()))
        } else {
            repository.observeTournaments(authenticatedUserId).toUiStateFlow("tournaments")
        }

    val drsReviews: StateFlow<UiState<List<DrsReview>>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            _guestDrsReviews.map<List<DrsReview>, UiState<List<DrsReview>>> { UiState.Success(it) }
                .stateIn(viewModelScope, SharingStarted.Eagerly, UiState.Success(initialGuestSeed?.drsReviews.orEmpty()))
        } else {
            repository.observeDrsReviews(authenticatedUserId).toUiStateFlow("drsReviews")
        }

    val activeScoringMatch: StateFlow<CricketMatch?> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            combine(_activeScoringMatchId, _guestMatches) { id, list ->
                if (id.isNullOrBlank()) null else list.firstOrNull { it.id == id }
            }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        } else {
            _activeScoringMatchId
                .flatMapLatest { id ->
                    if (id.isNullOrBlank()) flowOf(null) else repository.observeMatch(authenticatedUserId, id)
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    emit(null)
                }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)
        }

    val selectedLiveMatch: StateFlow<CricketMatch?> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            combine(_selectedLiveMatchId, _guestMatches) { id, list ->
                if (id.isNullOrBlank()) null else list.firstOrNull { it.id == id }
            }.stateIn(viewModelScope, SharingStarted.Eagerly, null)
        } else {
            _selectedLiveMatchId
                .flatMapLatest { id ->
                    if (id.isNullOrBlank()) flowOf(null) else repository.observeMatch(authenticatedUserId, id)
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    emit(null)
                }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)
        }

    val selectedLiveDeliveries: StateFlow<List<DeliveryRecord>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            combine(_selectedLiveMatchId, _guestDeliveriesByMatch) { id, map ->
                if (id.isNullOrBlank()) emptyList() else map[id].orEmpty()
            }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        } else {
            selectedLiveMatch
                .flatMapLatest { match ->
                    if (match == null) flowOf(emptyList())
                    else if (match.userId == authenticatedUserId) repository.observeDeliveries(authenticatedUserId, match.id)
                    else repository.observePublicDeliveries(authenticatedUserId, match.id)
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    emit(emptyList())
                }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        }

    val activeScoringDeliveries: StateFlow<List<DeliveryRecord>> =
        if (isGuestMode || repository == null || authenticatedUserId == null) {
            combine(_activeScoringMatchId, _guestDeliveriesByMatch) { id, map ->
                if (id.isNullOrBlank()) emptyList() else map[id].orEmpty()
            }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
        } else {
            _activeScoringMatchId
                .flatMapLatest { id ->
                    if (id.isNullOrBlank()) flowOf(emptyList()) else repository.observeDeliveries(authenticatedUserId, id)
                }
                .catch { error ->
                    if (error is CancellationException) throw error
                    emit(emptyList())
                }
                .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showMessage(msg: String) {
        _toastMessage.value = msg
    }

    fun selectLiveMatch(matchId: String) {
        _selectedLiveMatchId.value = matchId
    }

    fun openMatchForScoring(match: CricketMatch, deliveries: List<DeliveryRecord>) {
        _activeScoringMatchId.value = match.id
        val effectiveDeliveries = if (isGuestMode && deliveries.isEmpty()) {
            _guestDeliveriesByMatch.value[match.id].orEmpty()
        } else {
            deliveries
        }
        rebuildEngine(match, effectiveDeliveries)
    }

    fun syncEngineWithSnapshot(match: CricketMatch, deliveries: List<DeliveryRecord>) {
        if (lastSyncedMatchId != match.id || deliveries.size != lastLoadedDeliveries.size) {
            rebuildEngine(match, deliveries)
        }
    }

    private fun rebuildEngine(match: CricketMatch, deliveries: List<DeliveryRecord>) {
        lastSyncedMatchId = match.id
        lastLoadedDeliveries = deliveries
        val firstBat = if (match.tossDecision == "BOWL") {
            if (match.tossWinnerName == match.teamAName) match.teamBName else match.teamAName
        } else {
            match.tossWinnerName.ifBlank { match.teamAName }
        }
        val firstBowl = if (firstBat == match.teamAName) match.teamBName else match.teamAName
        val batPlayers = if (firstBat == match.teamAName) match.teamAPlayerNames else match.teamBPlayerNames
        val bowlPlayers = if (firstBowl == match.teamAName) match.teamAPlayerNames else match.teamBPlayerNames

        val engine = CricketScoringEngine(
            format = match.parsedFormat,
            oversLimit = match.oversLimit.toInt(),
            playersPerSide = match.playersPerSide.toInt(),
            maxOversPerBowler = match.maxOversPerBowler.toInt(),
            teamAName = match.teamAName,
            teamBName = match.teamBName,
            firstBattingTeam = firstBat,
            firstBowlingTeam = firstBowl,
            initialStriker = batPlayers.getOrNull(0) ?: match.strikerName.ifBlank { "Opener 1" },
            initialNonStriker = batPlayers.getOrNull(1) ?: match.nonStrikerName.ifBlank { "Opener 2" },
            initialBowler = bowlPlayers.getOrNull(0) ?: match.bowlerName.ifBlank { "Bowler 1" },
            secondInningsInitialStriker = bowlPlayers.getOrNull(0) ?: "Opener 1",
            secondInningsInitialNonStriker = bowlPlayers.getOrNull(1) ?: "Opener 2",
            secondInningsInitialBowler = batPlayers.getOrNull(0) ?: "Opening Bowler"
        )
        engine.loadDeliveries(deliveries.map { it.toDomain() }, match.currentInnings.toInt())
        activeEngine = engine
        _activeEngineState.value = engine.getState()
    }

    fun startNewMatch(
        format: MatchFormat,
        oversLimit: Int,
        playersPerSide: Int,
        maxOversPerBowler: Int,
        teamAName: String,
        teamBName: String,
        venue: String,
        tossWinnerName: String,
        tossDecision: String,
        strikerName: String,
        nonStrikerName: String,
        bowlerName: String,
        teamAPlayers: List<String>,
        teamBPlayers: List<String>,
        publicShared: Boolean,
        onCreated: (String) -> Unit
    ) {
        val batFirst = if (tossDecision == "BOWL") {
            if (tossWinnerName == teamAName) teamBName else teamAName
        } else {
            tossWinnerName
        }
        val bowlFirst = if (batFirst == teamAName) teamBName else teamAName
        val match = CricketMatch(
            userId = effectiveUserId,
            controllerUids = listOf(effectiveUserId),
            publicShared = if (isGuestMode) false else publicShared,
            shareCode = "CIQ" + (100..999).random(),
            format = format.name,
            oversLimit = oversLimit.toLong(),
            playersPerSide = playersPerSide.toLong(),
            maxOversPerBowler = maxOversPerBowler.toLong(),
            teamAName = teamAName.trim(),
            teamAShort = teamAName.trim().take(3).uppercase().ifBlank { "TMA" },
            teamBName = teamBName.trim(),
            teamBShort = teamBName.trim().take(3).uppercase().ifBlank { "TMB" },
            venue = venue.trim().ifBlank { "Club Ground" },
            status = MatchStatus.LIVE.name,
            tossWinnerName = tossWinnerName,
            tossDecision = tossDecision,
            currentInnings = 1L,
            battingTeamName = batFirst,
            bowlingTeamName = bowlFirst,
            strikerName = strikerName.trim().ifBlank { "Batter 1" },
            nonStrikerName = nonStrikerName.trim().ifBlank { "Batter 2" },
            bowlerName = bowlerName.trim().ifBlank { "Bowler 1" },
            teamAPlayerNames = teamAPlayers.ifEmpty { listOf(strikerName, nonStrikerName) },
            teamBPlayerNames = teamBPlayers.ifEmpty { listOf(bowlerName) },
            createdAt = Timestamp.now(),
            updatedAt = Timestamp.now()
        )

        if (isGuestMode || repository == null) {
            val newId = "guest_match_${System.currentTimeMillis()}"
            val created = match.copy(id = newId)
            _guestMatches.value = listOf(created) + _guestMatches.value
            _guestDeliveriesByMatch.value = _guestDeliveriesByMatch.value + (newId to emptyList())
            _activeScoringMatchId.value = newId
            rebuildEngine(created, emptyList())
            _toastMessage.value = "Match started in Guest Mode (local session)"
            onCreated(newId)
            return
        }

        viewModelScope.launch {
            val res = repository.createMatch(match)
            res.onSuccess { newId ->
                val created = match.copy(id = newId)
                _activeScoringMatchId.value = newId
                rebuildEngine(created, emptyList())
                onCreated(newId)
            }.onFailure { err ->
                _toastMessage.value = err.message ?: "Failed to create match"
            }
        }
    }

    fun recordBall(match: CricketMatch, input: DeliveryInput) {
        val engine = activeEngine ?: return
        val res = engine.recordDelivery(input)
        res.onFailure { err ->
            _toastMessage.value = err.message ?: "Invalid delivery"
        }.onSuccess { recorded ->
            val newState = engine.getState()
            _activeEngineState.value = newState

            if (isGuestMode || repository == null) {
                val rec = GuestDemoFactory.toGuestDeliveryRecord(match.id, recorded)
                val updatedList = _guestDeliveriesByMatch.value[match.id].orEmpty() + rec
                _guestDeliveriesByMatch.value = _guestDeliveriesByMatch.value + (match.id to updatedList)
                syncGuestMatchSummary(match.id, newState)
                if (newState.matchCompleted && !statsSyncedForMatchIds.contains(match.id)) {
                    statsSyncedForMatchIds.add(match.id)
                    updateGuestPlayerStatsAfterMatch(newState)
                }
                return
            }

            viewModelScope.launch {
                val syncRes = repository.recordDeliveryAndSyncMatch(match, recorded, newState)
                syncRes.onFailure { _toastMessage.value = it.message ?: "Sync failed" }
                if (newState.matchCompleted && !statsSyncedForMatchIds.contains(match.id)) {
                    statsSyncedForMatchIds.add(match.id)
                    val playerList = (players.value as? UiState.Success)?.data.orEmpty()
                    repository.updatePlayerStatsAfterMatch(newState, playerList)
                }
            }
        }
    }

    fun undoLastBall(match: CricketMatch, deliveries: List<DeliveryRecord>) {
        val engine = activeEngine ?: return
        val removed = engine.undoLastDelivery() ?: run {
            _toastMessage.value = "Nothing to undo."
            return
        }
        val newState = engine.getState()
        _activeEngineState.value = newState

        if (isGuestMode || repository == null) {
            val currentList = _guestDeliveriesByMatch.value[match.id].orEmpty()
            val updatedList = currentList.filterNot { it.sequenceNumber == removed.sequenceNumber.toLong() }
            _guestDeliveriesByMatch.value = _guestDeliveriesByMatch.value + (match.id to updatedList)
            syncGuestMatchSummary(match.id, newState)
            return
        }

        val docToDelete = deliveries.lastOrNull { it.sequenceNumber == removed.sequenceNumber.toLong() }?.id
        viewModelScope.launch {
            repository.undoLastDeliveryAndSync(match.id, docToDelete, newState)
                .onFailure { _toastMessage.value = it.message ?: "Undo sync failed" }
        }
    }

    fun changeBowler(bowlerName: String) {
        val engine = activeEngine ?: return
        engine.setBowler(bowlerName)
            .onSuccess {
                val state = engine.getState()
                _activeEngineState.value = state
                if (isGuestMode) {
                    _activeScoringMatchId.value?.let { syncGuestMatchSummary(it, state) }
                }
            }
            .onFailure { _toastMessage.value = it.message ?: "Cannot select bowler" }
    }

    fun swapStrike() {
        val engine = activeEngine ?: return
        engine.toggleStrikeAtCurrentPoint()
        val state = engine.getState()
        _activeEngineState.value = state
        if (isGuestMode) {
            _activeScoringMatchId.value?.let { syncGuestMatchSummary(it, state) }
        }
    }

    fun setNextBatter(name: String) {
        val engine = activeEngine ?: return
        engine.setNextBatter(name)
            .onSuccess {
                val state = engine.getState()
                _activeEngineState.value = state
                if (isGuestMode) {
                    _activeScoringMatchId.value?.let { syncGuestMatchSummary(it, state) }
                }
            }
            .onFailure { _toastMessage.value = it.message ?: "Invalid batter" }
    }

    fun endCurrentInnings(match: CricketMatch) {
        val engine = activeEngine ?: return
        engine.declareOrEndCurrentInnings()
        val newState = engine.getState()
        _activeEngineState.value = newState

        if (isGuestMode || repository == null) {
            syncGuestMatchSummary(match.id, newState)
            if (newState.matchCompleted && !statsSyncedForMatchIds.contains(match.id)) {
                statsSyncedForMatchIds.add(match.id)
                updateGuestPlayerStatsAfterMatch(newState)
            }
            return
        }

        viewModelScope.launch {
            repository.syncMatchSummary(match.id, newState)
            if (newState.matchCompleted && !statsSyncedForMatchIds.contains(match.id)) {
                statsSyncedForMatchIds.add(match.id)
                val playerList = (players.value as? UiState.Success)?.data.orEmpty()
                repository.updatePlayerStatsAfterMatch(newState, playerList)
            }
        }
    }

    fun startSecondInnings(match: CricketMatch, striker: String, nonStriker: String, bowler: String) {
        val engine = activeEngine ?: return
        engine.startSecondInnings(
            striker = striker.ifBlank { "Opener 1" },
            nonStriker = nonStriker.ifBlank { "Opener 2" },
            bowler = bowler.ifBlank { "Bowler 1" }
        )
        val newState = engine.getState()
        _activeEngineState.value = newState

        if (isGuestMode || repository == null) {
            syncGuestMatchSummary(match.id, newState)
            return
        }

        viewModelScope.launch {
            repository.syncMatchSummary(match.id, newState)
        }
    }

    fun togglePublicShare(match: CricketMatch) {
        if (isGuestMode || repository == null) {
            _toastMessage.value = "Sign in with Google in the Profile tab to share live cloud match links across devices."
            return
        }
        viewModelScope.launch {
            val next = !match.publicShared
            repository.toggleMatchPublicShare(match.id, next)
                .onSuccess {
                    _toastMessage.value = if (next) {
                        "Live scorecard is now shared (Code: ${match.shareCode})"
                    } else {
                        "Match sharing disabled"
                    }
                }
                .onFailure { _toastMessage.value = it.message ?: "Failed to update sharing" }
        }
    }

    fun joinMatchByShareCode(code: String, onFound: (String) -> Unit) {
        if (isGuestMode || repository == null) {
            val clean = code.trim().uppercase()
            val localMatch = _guestMatches.value.firstOrNull { it.shareCode.equals(clean, ignoreCase = true) }
            if (localMatch != null) {
                _selectedLiveMatchId.value = localMatch.id
                onFound(localMatch.id)
            } else {
                _toastMessage.value = "Sign in with Google in Profile to join remote live matches across devices."
            }
            return
        }
        viewModelScope.launch {
            repository.findSharedMatchByCode(code)
                .onSuccess { match ->
                    if (match != null) {
                        _selectedLiveMatchId.value = match.id
                        onFound(match.id)
                    } else {
                        _toastMessage.value = "No live shared match found for code $code"
                    }
                }
                .onFailure { _toastMessage.value = it.message ?: "Lookup failed" }
        }
    }

    fun createTeam(name: String, shortName: String) {
        if (name.trim().isEmpty()) {
            _toastMessage.value = "Team name required."
            return
        }
        if (isGuestMode || repository == null) {
            val trimmed = name.trim().take(60)
            val newTeam = Team(
                id = "guest_team_${System.currentTimeMillis()}",
                userId = effectiveUserId,
                controllerUids = listOf(effectiveUserId),
                memberUids = listOf(effectiveUserId),
                name = trimmed,
                shortName = shortName.trim().uppercase().take(8).ifBlank { trimmed.take(3).uppercase() },
                inviteCode = "CIQ" + (1000..9999).random(),
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            _guestTeams.value = listOf(newTeam) + _guestTeams.value
            _toastMessage.value = "Team $trimmed created in Guest Mode"
            return
        }
        viewModelScope.launch {
            repository.createTeam(name, shortName)
                .onSuccess { _toastMessage.value = "Team $name created" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to create team" }
        }
    }

    fun updateTeamLineup(
        team: Team,
        captainId: String,
        wicketkeeperId: String,
        playingXiIds: List<String>,
        substituteIds: List<String>
    ) {
        val allIds = (playingXiIds + substituteIds).distinct()
        if (isGuestMode || repository == null) {
            _guestTeams.value = _guestTeams.value.map {
                if (it.id == team.id) {
                    it.copy(
                        captainPlayerId = captainId,
                        wicketkeeperPlayerId = wicketkeeperId,
                        playingXiIds = playingXiIds.take(11),
                        substituteIds = substituteIds.take(10),
                        playerIds = allIds.take(30),
                        updatedAt = Timestamp.now()
                    )
                } else it
            }
            _toastMessage.value = "Squad roles & XI updated locally"
            return
        }
        viewModelScope.launch {
            repository.updateTeamLineup(team.id, captainId, wicketkeeperId, playingXiIds, substituteIds, allIds)
                .onSuccess { _toastMessage.value = "Squad roles & XI saved" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to update squad" }
        }
    }

    fun createPlayer(
        name: String,
        teamId: String,
        teamName: String,
        role: PlayerRole,
        battingStyle: String,
        bowlingStyle: String
    ) {
        if (name.trim().isEmpty()) {
            _toastMessage.value = "Player name required."
            return
        }
        if (isGuestMode || repository == null) {
            val trimmed = name.trim().take(60)
            val newPlayer = PlayerProfile(
                id = "guest_player_${System.currentTimeMillis()}",
                userId = effectiveUserId,
                memberUids = listOf(effectiveUserId),
                name = trimmed,
                teamId = teamId,
                teamName = teamName,
                role = role.name,
                battingStyle = battingStyle,
                bowlingStyle = bowlingStyle,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            _guestPlayers.value = listOf(newPlayer) + _guestPlayers.value
            _toastMessage.value = "Player $trimmed added in Guest Mode"
            return
        }
        viewModelScope.launch {
            repository.createPlayer(name, teamId, teamName, role, battingStyle, bowlingStyle)
                .onSuccess { _toastMessage.value = "Player $name added" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to add player" }
        }
    }

    fun createTournament(
        name: String,
        format: MatchFormat,
        oversLimit: Int,
        tournamentType: String,
        teamNames: List<String>
    ) {
        val cleanTeams = teamNames.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(20)
        if (cleanTeams.size < 2) {
            _toastMessage.value = "At least 2 teams are required for a tournament."
            return
        }
        if (isGuestMode || repository == null) {
            val standings = cleanTeams.map { team ->
                mapOf<String, Any>(
                    "teamName" to team, "played" to 0L, "won" to 0L, "lost" to 0L, "tied" to 0L,
                    "points" to 0L, "runsFor" to 0L, "ballsFaced" to 0L, "runsAgainst" to 0L,
                    "ballsBowled" to 0L, "nrr" to 0.0
                )
            }
            val fixtures = mutableListOf<Map<String, Any>>()
            if (tournamentType != "KNOCKOUT") {
                var idx = 1
                for (i in cleanTeams.indices) {
                    for (j in i + 1 until cleanTeams.size) {
                        fixtures.add(
                            mapOf(
                                "fixtureId" to "fx_$idx",
                                "round" to "Group Stage",
                                "teamAName" to cleanTeams[i],
                                "teamBName" to cleanTeams[j],
                                "status" to "SCHEDULED",
                                "scoreSummary" to "Scheduled",
                                "winnerName" to ""
                            )
                        )
                        idx++
                    }
                }
            }
            if (tournamentType != "LEAGUE") {
                fixtures.add(
                    mapOf(
                        "fixtureId" to "final",
                        "round" to "Final",
                        "teamAName" to cleanTeams[0],
                        "teamBName" to cleanTeams[1],
                        "status" to "SCHEDULED",
                        "scoreSummary" to "Championship Final",
                        "winnerName" to ""
                    )
                )
            }
            val created = Tournament(
                id = "guest_tour_${System.currentTimeMillis()}",
                userId = effectiveUserId,
                controllerUids = listOf(effectiveUserId),
                name = name.trim().ifBlank { "Club Championship" },
                format = format.name,
                oversLimit = oversLimit.toLong(),
                tournamentType = tournamentType,
                teamNames = cleanTeams,
                standings = standings,
                fixtures = fixtures.take(40),
                status = "ACTIVE",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            _guestTournaments.value = listOf(created) + _guestTournaments.value
            _toastMessage.value = "Tournament created in Guest Mode"
            return
        }
        viewModelScope.launch {
            repository.createTournament(name, format, oversLimit, tournamentType, teamNames)
                .onSuccess { _toastMessage.value = "Tournament created" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to create tournament" }
        }
    }

    fun recordFixtureResult(
        tournament: Tournament,
        fixtureId: String,
        teamAScore: Int,
        teamABalls: Int,
        teamBScore: Int,
        teamBBalls: Int
    ) {
        if (isGuestMode || repository == null) {
            val targetFx = tournament.fixtures.firstOrNull { (it["fixtureId"] as? String) == fixtureId }
            val tAName = targetFx?.get("teamAName") as? String ?: ""
            val tBName = targetFx?.get("teamBName") as? String ?: ""
            val updatedFixtures = tournament.fixtures.map { fx ->
                if ((fx["fixtureId"] as? String) == fixtureId) {
                    val winner = when {
                        teamAScore > teamBScore -> tAName
                        teamBScore > teamAScore -> tBName
                        else -> "Tie"
                    }
                    fx.toMutableMap().apply {
                        put("status", "COMPLETED")
                        put("winnerName", winner)
                        put("scoreSummary", "$tAName $teamAScore vs $tBName $teamBScore")
                    }
                } else fx
            }
            val updatedStandings = tournament.standings.map { st ->
                val tName = st["teamName"] as? String ?: ""
                if (tName != tAName && tName != tBName) st
                else {
                    val isA = tName == tAName
                    val myScore = if (isA) teamAScore else teamBScore
                    val myBalls = (if (isA) teamABalls else teamBBalls).coerceAtLeast(1)
                    val oppScore = if (isA) teamBScore else teamAScore
                    val oppBalls = (if (isA) teamBBalls else teamABalls).coerceAtLeast(1)
                    val played = ((st["played"] as? Number)?.toLong() ?: 0L) + 1L
                    val won = ((st["won"] as? Number)?.toLong() ?: 0L) + (if (myScore > oppScore) 1L else 0L)
                    val lost = ((st["lost"] as? Number)?.toLong() ?: 0L) + (if (myScore < oppScore) 1L else 0L)
                    val tied = ((st["tied"] as? Number)?.toLong() ?: 0L) + (if (myScore == oppScore) 1L else 0L)
                    val points = won * 2L + tied
                    val rf = ((st["runsFor"] as? Number)?.toLong() ?: 0L) + myScore
                    val bf = ((st["ballsFaced"] as? Number)?.toLong() ?: 0L) + myBalls
                    val ra = ((st["runsAgainst"] as? Number)?.toLong() ?: 0L) + oppScore
                    val bb = ((st["ballsBowled"] as? Number)?.toLong() ?: 0L) + oppBalls
                    val nrr = CricketScoringEngine.calculateNrr(rf.toInt(), bf.toInt(), ra.toInt(), bb.toInt())
                    mapOf(
                        "teamName" to tName, "played" to played, "won" to won, "lost" to lost,
                        "tied" to tied, "points" to points, "runsFor" to rf, "ballsFaced" to bf,
                        "runsAgainst" to ra, "ballsBowled" to bb, "nrr" to nrr
                    )
                }
            }.sortedWith(
                compareByDescending<Map<String, Any>> { (it["points"] as? Number)?.toLong() ?: 0L }
                    .thenByDescending { (it["nrr"] as? Number)?.toDouble() ?: 0.0 }
            )
            _guestTournaments.value = _guestTournaments.value.map {
                if (it.id == tournament.id) it.copy(fixtures = updatedFixtures, standings = updatedStandings, updatedAt = Timestamp.now())
                else it
            }
            _toastMessage.value = "Points table & NRR updated locally"
            return
        }
        viewModelScope.launch {
            repository.recordTournamentFixtureResult(
                tournament, fixtureId, teamAScore, teamABalls, teamBScore, teamBBalls
            ).onSuccess {
                _toastMessage.value = "Points table & NRR updated"
            }.onFailure {
                _toastMessage.value = it.message ?: "Failed to update fixture"
            }
        }
    }

    fun saveDrsReview(review: DrsReview) {
        if (isGuestMode || repository == null) {
            val saved = review.copy(
                id = review.id.ifBlank { "guest_drs_${System.currentTimeMillis()}" },
                userId = effectiveUserId,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            _guestDrsReviews.value = listOf(saved) + _guestDrsReviews.value.filterNot { it.id == saved.id }
            _toastMessage.value = "DRS Review saved locally in Guest Mode"
            return
        }
        viewModelScope.launch {
            repository.saveDrsReview(review)
                .onSuccess { _toastMessage.value = "DRS Review clip metadata saved" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to save DRS review" }
        }
    }

    fun updateProfile(displayName: String, role: UserRole, clubName: String) {
        if (isGuestMode || repository == null) {
            _guestProfile.value = (_guestProfile.value ?: GuestDemoFactory.createSeedData().profile).copy(
                displayName = displayName.trim().ifBlank { "Guest Scorer" },
                role = role.name,
                clubName = clubName.trim().ifBlank { "Cricket IQ Demo Club" },
                updatedAt = Timestamp.now()
            )
            _toastMessage.value = "Guest profile updated locally (sign in to save to account)"
            return
        }
        viewModelScope.launch {
            repository.updateUserProfile(displayName, role, clubName)
                .onSuccess { _toastMessage.value = "Profile updated" }
                .onFailure { _toastMessage.value = it.message ?: "Profile update failed" }
        }
    }

    fun selectSubscriptionPreview(tier: SubscriptionTier, status: String = "ACTIVE") {
        if (isGuestMode || repository == null) {
            _guestProfile.value = (_guestProfile.value ?: GuestDemoFactory.createSeedData().profile).copy(
                subscriptionTier = tier.name,
                subscriptionMode = if (tier == SubscriptionTier.FREE) "FREE" else "PREVIEW_SANDBOX",
                subscriptionStatus = status,
                updatedAt = Timestamp.now()
            )
            _toastMessage.value = "${tier.title} plan preview enabled locally"
            return
        }
        viewModelScope.launch {
            repository.updateSubscriptionPreview(tier, status)
                .onSuccess {
                    _toastMessage.value = if (status == "CANCELLED") {
                        "Preview subscription cancelled (reverted to Free)"
                    } else {
                        "${tier.title} plan preview enabled"
                    }
                }
                .onFailure { _toastMessage.value = it.message ?: "Failed to update plan" }
        }
    }

    fun loadDemoClubData() {
        if (isGuestMode || repository == null) {
            val seed = GuestDemoFactory.createSeedData()
            _guestTeams.value = seed.teams
            _guestPlayers.value = seed.players
            _guestMatches.value = seed.matches
            _guestDeliveriesByMatch.value = seed.deliveriesByMatchId
            _guestTournaments.value = seed.tournaments
            _guestDrsReviews.value = seed.drsReviews
            _toastMessage.value = "Demonstration matches & sample players refreshed"
            return
        }
        viewModelScope.launch {
            repository.loadDemoClubData()
                .onSuccess { _toastMessage.value = "Demonstration club data loaded" }
                .onFailure { _toastMessage.value = it.message ?: "Failed to load demo data" }
        }
    }

    fun clearActiveScoringSelection() {
        _activeScoringMatchId.value = null
        activeEngine = null
        _activeEngineState.value = null
    }

    private fun syncGuestMatchSummary(matchId: String, state: MatchEngineState) {
        val active = state.activeInnings
        val newStatus = when {
            state.matchCompleted -> MatchStatus.COMPLETED.name
            state.currentInnings == 1 && state.innings1.inningsComplete -> MatchStatus.INNINGS_BREAK.name
            else -> MatchStatus.LIVE.name
        }
        val recentLabels = active.recentDeliveries.takeLast(12).map { it.shortNotation() }
        _guestMatches.value = _guestMatches.value.map { m ->
            if (m.id == matchId) {
                m.copy(
                    status = newStatus,
                    currentInnings = state.currentInnings.toLong(),
                    battingTeamName = active.battingTeamName,
                    bowlingTeamName = active.bowlingTeamName,
                    totalRuns = active.totalRuns.toLong(),
                    wickets = active.wickets.coerceIn(0, 10).toLong(),
                    legalBalls = active.legalBalls.toLong(),
                    targetRuns = active.targetRuns.toLong(),
                    strikerName = active.strikerName,
                    nonStrikerName = active.nonStrikerName,
                    bowlerName = active.currentBowlerName,
                    recentBalls = recentLabels,
                    resultSummary = state.resultSummary,
                    winnerTeamName = state.winnerTeamName,
                    updatedAt = Timestamp.now()
                )
            } else m
        }
    }

    private fun updateGuestPlayerStatsAfterMatch(state: MatchEngineState) {
        val inningsList = listOfNotNull(state.innings1, state.innings2)
        _guestPlayers.value = _guestPlayers.value.map { player ->
            var participated = false
            var addRuns = 0L
            var addBallsFaced = 0L
            var addFours = 0L
            var addSixes = 0L
            var addInningsBatted = 0L
            var addNotOuts = 0L
            var newHigh = player.highestScore
            val recent = player.recentScores.toMutableList()
            var addWickets = 0L
            var addBallsBowled = 0L
            var addRunsConceded = 0L
            var bestW = player.bestBowlingWickets
            var bestR = player.bestBowlingRuns

            for (inn in inningsList) {
                val bat = inn.batters.firstOrNull { it.name.equals(player.name, ignoreCase = true) }
                if (bat != null && (bat.ballsFaced > 0 || bat.out)) {
                    participated = true
                    addInningsBatted += 1
                    addRuns += bat.runs
                    addBallsFaced += bat.ballsFaced
                    addFours += bat.fours
                    addSixes += bat.sixes
                    if (!bat.out) addNotOuts += 1
                    if (bat.runs > newHigh) newHigh = bat.runs.toLong()
                    recent.add(bat.runs.toLong())
                }
                val bowl = inn.bowlers.firstOrNull { it.name.equals(player.name, ignoreCase = true) }
                if (bowl != null && bowl.legalBalls > 0) {
                    participated = true
                    addWickets += bowl.wickets
                    addBallsBowled += bowl.legalBalls
                    addRunsConceded += bowl.runsConceded
                    if (bowl.wickets > bestW || (bowl.wickets.toLong() == bestW && bowl.runsConceded < bestR)) {
                        bestW = bowl.wickets.toLong()
                        bestR = bowl.runsConceded.toLong()
                    }
                }
            }
            if (participated) {
                player.copy(
                    matchesPlayed = player.matchesPlayed + 1,
                    inningsBatted = player.inningsBatted + addInningsBatted,
                    runs = player.runs + addRuns,
                    ballsFaced = player.ballsFaced + addBallsFaced,
                    fours = player.fours + addFours,
                    sixes = player.sixes + addSixes,
                    highestScore = newHigh,
                    notOuts = player.notOuts + addNotOuts,
                    wickets = player.wickets + addWickets,
                    ballsBowled = player.ballsBowled + addBallsBowled,
                    runsConceded = player.runsConceded + addRunsConceded,
                    bestBowlingWickets = bestW,
                    bestBowlingRuns = bestR,
                    recentScores = recent.takeLast(20),
                    updatedAt = Timestamp.now()
                )
            } else player
        }
    }

    private companion object {
        const val TAG = "CricketIqVM"
    }
}
