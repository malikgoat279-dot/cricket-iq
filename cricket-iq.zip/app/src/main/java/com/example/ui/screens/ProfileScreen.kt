package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.ui.auth.GoogleSignInButton
import com.example.ui.auth.signOut
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    isGuestMode: Boolean,
    userProfile: UserProfile?,
    onUpdateProfile: (String, UserRole, String) -> Unit,
    onSelectSubscriptionPreview: (SubscriptionTier, String) -> Unit,
    onLoadDemoData: () -> Unit,
    onSignInSuccess: () -> Unit,
    onSignedOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var displayName by remember(userProfile?.displayName) { mutableStateOf(userProfile?.displayName ?: "") }
    var clubName by remember(userProfile?.clubName) { mutableStateOf(userProfile?.clubName ?: "") }
    var selectedRole by remember(userProfile?.role) { mutableStateOf(userProfile?.parsedRole ?: UserRole.SCORER) }
    var authError by remember { mutableStateOf<String?>(null) }
    val activeTier = userProfile?.parsedTier ?: SubscriptionTier.FREE

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Account & Subscriptions",
                subtitle = if (isGuestMode) "Guest Mode active • Sign in to sync across devices" else "Role permissions, club profile & plan tiers"
            )
        }

        if (isGuestMode) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = NavyCard),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.5.dp, PitchGreen.copy(alpha = 0.65f))
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Sign in to Sync & Save", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            StatusPill("GUEST MODE", BoundaryGold, NavyElevated)
                        }
                        Text(
                            text = "You can score matches, manage demo teams, explore analytics, and test Smart DRS in Guest Mode without signing in. Sign in with Google when you want to save to your personal account, sync across devices, or share live match links.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                        GoogleSignInButton(
                            onAuthSuccess = {
                                authError = null
                                onSignInSuccess()
                            },
                            onAuthError = { msg -> authError = msg }
                        )
                        if (authError != null) {
                            Text(
                                text = authError!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = WicketCrimson
                            )
                        }
                    }
                }
            }
        }

        // User Account Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, NavyOutline)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(PitchGreenMuted),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (userProfile?.displayName ?: "CIQ").take(2).uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = PitchGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(userProfile?.displayName ?: "Cricket IQ User", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            Text(
                                text = if (isGuestMode) "Local Guest Session" else (userProfile?.email?.ifBlank { "Google Account" } ?: "Google Account"),
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                        StatusPill(activeTier.title.uppercase(), PitchGreen, PitchGreenMuted)
                    }

                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Display Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = clubName,
                        onValueChange = { clubName = it },
                        label = { Text("Club / School Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Account Role & Permissions", style = MaterialTheme.typography.labelSmall, color = PitchGreen)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        UserRole.entries.forEach { r ->
                            FilterChip(
                                selected = selectedRole == r,
                                onClick = { selectedRole = r },
                                label = { Text(r.label) }
                            )
                        }
                    }
                    Text(
                        text = selectedRole.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )

                    Button(
                        onClick = { onUpdateProfile(displayName, selectedRole, clubName) },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_profile_button")
                    ) {
                        Text("Save Account Settings", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Subscription Pricing & Entitlements Section
        item {
            SectionHeader(
                title = "CRICKET IQ Plans",
                subtitle = "Subscription architecture & entitlement controls"
            )
            Spacer(Modifier.height(8.dp))
            Surface(
                color = NavyCard,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, BoundaryGold.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "Billing Readiness Notice: Google Play Billing (Android) and Apple In-App Purchase (iOS) are wired at the entitlement layer for store release. Live payment processing is not yet enabled; you may test plan entitlements below in Sandbox Preview mode. No payment card details are stored in the app database.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        SubscriptionTier.entries.forEach { tier ->
            item(key = tier.name) {
                val isCurrent = activeTier == tier
                val borderCol = when {
                    isCurrent -> PitchGreen
                    tier == SubscriptionTier.CLUB_PRO -> BoundaryGold.copy(alpha = 0.7f)
                    else -> NavyOutline
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isCurrent) PitchGreenMuted.copy(alpha = 0.35f) else NavyCard),
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(if (isCurrent) 2.dp else 1.dp, borderCol)
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.WorkspacePremium,
                                    contentDescription = null,
                                    tint = if (tier == SubscriptionTier.CLUB_PRO) BoundaryGold else PitchGreen,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(tier.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Text(tier.tagline, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                                }
                            }
                            Text(
                                text = tier.priceLabel,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (tier == SubscriptionTier.CLUB_PRO) BoundaryGold else PitchGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        HorizontalDivider(color = NavyOutline)

                        tier.features.forEach { feat ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = PitchGreen, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(feat, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                            }
                        }

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (isCurrent) {
                                OutlinedButton(
                                    onClick = {
                                        if (tier != SubscriptionTier.FREE) {
                                            onSelectSubscriptionPreview(SubscriptionTier.FREE, "CANCELLED")
                                        }
                                    },
                                    enabled = tier != SubscriptionTier.FREE,
                                    border = BorderStroke(1.dp, if (tier == SubscriptionTier.FREE) PitchGreen else WicketCrimson),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = if (tier == SubscriptionTier.FREE) "Current Base Plan" else "Cancel Preview Plan",
                                        color = if (tier == SubscriptionTier.FREE) PitchGreen else WicketCrimson
                                    )
                                }
                            } else {
                                Button(
                                    onClick = { onSelectSubscriptionPreview(tier, "ACTIVE") },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (tier == SubscriptionTier.CLUB_PRO) BoundaryGold else PitchGreen,
                                        contentColor = NavyBase
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("select_plan_${tier.name.lowercase()}")
                                ) {
                                    Text(
                                        text = if (tier == SubscriptionTier.FREE) "Switch to Free" else "Preview ${tier.title} Entitlements",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Demo Data & Sign Out
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, NavyOutline)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Workspace Tools & Session", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    OutlinedButton(
                        onClick = onLoadDemoData,
                        border = BorderStroke(1.dp, SkyInfo),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isGuestMode) "Reset Demonstration Club Data" else "Load Demonstration Club Data",
                            color = SkyInfo
                        )
                    }
                    Text(
                        text = "Account Recovery: Password resets and additional email/password providers are managed via your linked Google Account or Firebase Authentication settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                    if (!isGuestMode) {
                        Button(
                            onClick = {
                                signOut(credentialManager, scope, onSignedOut)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyElevated, contentColor = WicketCrimson),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "Sign Out", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Sign Out", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
