package com.example.ui.screens

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.DrsAnnotationItem
import com.example.data.model.DrsCategory
import com.example.data.model.DrsOutcome
import com.example.data.model.DrsReview
import com.example.data.model.UmpireDecision
import com.example.ui.components.StatusPill
import com.example.ui.theme.BoundaryGold
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyOutline
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.SkyInfo
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DrsReviewScreen(
    initialMatchTitle: String,
    initialOverBall: String,
    savedReviews: List<DrsReview>,
    onSaveReview: (DrsReview) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCaptureUri by remember { mutableStateOf<Uri?>(null) }
    var matchTitle by remember(initialMatchTitle) { mutableStateOf(initialMatchTitle.ifBlank { "Club Match Review" }) }
    var overBallLabel by remember(initialOverBall) { mutableStateOf(initialOverBall.ifBlank { "14.3" }) }
    var category by remember { mutableStateOf(DrsCategory.LBW) }
    var umpireDecision by remember { mutableStateOf(UmpireDecision.NOT_OUT) }
    var finalOutcome by remember { mutableStateOf(DrsOutcome.PENDING) }
    var notes by remember { mutableStateOf("") }

    var isPlaying by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(0.5f) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var comparePosMs by remember { mutableLongStateOf(0L) }
    var showCompareMode by remember { mutableStateOf(false) }

    var primaryFrame by remember { mutableStateOf<Bitmap?>(null) }
    var compareFrame by remember { mutableStateOf<Bitmap?>(null) }

    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var drawMode by remember { mutableStateOf("LINE") } // LINE, MARKER, PAN
    var selectedColorHex by remember { mutableStateOf("#00E676") }
    val annotations = remember { mutableStateListOf<DrsAnnotationItem>() }
    var dragStartNorm by remember { mutableStateOf<Offset?>(null) }
    var dragEndNorm by remember { mutableStateOf<Offset?>(null) }

    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Zero-permission Android Photo Picker for cricket delivery videos
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                selectedVideoUri = uri
                isPlaying = false
                currentPosMs = 0L
                comparePosMs = 0L
            }
        }
    )

    // System Camera Capture via FileProvider
    val videoCapture = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo(),
        onResult = { success ->
            if (success && pendingCaptureUri != null) {
                selectedVideoUri = pendingCaptureUri
                isPlaying = false
                currentPosMs = 0L
                comparePosMs = 0L
            }
        }
    )

    // Extract duration and high-precision frames when seeking / stepping
    LaunchedEffect(selectedVideoUri) {
        val uri = selectedVideoUri ?: return@LaunchedEffect
        withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durStr?.toLongOrNull() ?: 0L
                primaryFrame = retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST)
            } catch (_: Exception) {
                durationMs = 0L
            } finally {
                retriever.release()
            }
        }
    }

    LaunchedEffect(selectedVideoUri, currentPosMs, isPlaying) {
        val uri = selectedVideoUri ?: return@LaunchedEffect
        if (!isPlaying) {
            withContext(Dispatchers.IO) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    primaryFrame = retriever.getFrameAtTime(currentPosMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                } catch (_: Exception) {
                } finally {
                    retriever.release()
                }
            }
        }
    }

    LaunchedEffect(selectedVideoUri, comparePosMs, showCompareMode) {
        val uri = selectedVideoUri ?: return@LaunchedEffect
        if (showCompareMode) {
            withContext(Dispatchers.IO) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    compareFrame = retriever.getFrameAtTime(comparePosMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)
                } catch (_: Exception) {
                } finally {
                    retriever.release()
                }
            }
        }
    }

    LaunchedEffect(isPlaying, playbackSpeed) {
        val mp = mediaPlayer
        if (mp != null) {
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    mp.playbackParams = mp.playbackParams.setSpeed(playbackSpeed)
                }
            } catch (_: Exception) {
            }
        }
        while (isPlaying && mediaPlayer != null) {
            try {
                val pos = mediaPlayer?.currentPosition?.toLong() ?: currentPosMs
                currentPosMs = pos
            } catch (_: Exception) {
            }
            delay(80L)
        }
    }

    DisposableEffect(selectedVideoUri) {
        onDispose {
            try {
                mediaPlayer?.release()
            } catch (_: Exception) {
            }
            mediaPlayer = null
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Smart DRS Video Review", style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text("Manual frame-by-frame & crease line review", style = MaterialTheme.typography.bodyMedium, color = PitchGreen)
                }
                StatusPill("MANUAL DRS", PitchGreen, PitchGreenMuted)
            }
        }

        // Honest Capability Disclosure Banner
        item {
            Surface(
                color = NavyCard,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SkyInfo.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "Practical Manual Review Tool: Inspect delivery footage frame-by-frame, zoom, draw reference lines, and compare two frames. Smartphone cameras do not provide automated Hawk-Eye ball tracking or edge detection.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Video Source Controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("drs_pick_video_button")
                ) {
                    Icon(Icons.Filled.VideoFile, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Upload Video", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = {
                        val dir = File(context.cacheDir, "drs_videos").apply { mkdirs() }
                        val videoFile = File(dir, "drs_${System.currentTimeMillis()}.mp4")
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", videoFile)
                        pendingCaptureUri = uri
                        videoCapture.launch(uri)
                    },
                    border = androidx.compose.foundation.BorderStroke(1.dp, SkyInfo),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("drs_record_video_button")
                ) {
                    Icon(Icons.Filled.Videocam, contentDescription = null, tint = SkyInfo, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Record Clip", color = SkyInfo, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Video Stage + Zoom + Annotation Overlay
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(NavyBase)
                    .border(1.dp, NavyOutline, RoundedCornerShape(18.dp))
                    .clipToBounds()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = zoomScale,
                            scaleY = zoomScale,
                            translationX = panOffset.x,
                            translationY = panOffset.y
                        )
                ) {
                    if (selectedVideoUri != null) {
                        if (isPlaying) {
                            AndroidView(
                                factory = { ctx ->
                                    TextureView(ctx).apply {
                                        surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                                            override fun onSurfaceTextureAvailable(st: android.graphics.SurfaceTexture, w: Int, h: Int) {
                                                val mp = MediaPlayer().apply {
                                                    setDataSource(ctx, selectedVideoUri!!)
                                                    setSurface(Surface(st))
                                                    isLooping = true
                                                    prepare()
                                                    seekTo(currentPosMs.toInt())
                                                    start()
                                                }
                                                mediaPlayer = mp
                                            }
                                            override fun onSurfaceTextureSizeChanged(st: android.graphics.SurfaceTexture, w: Int, h: Int) {}
                                            override fun onSurfaceTextureDestroyed(st: android.graphics.SurfaceTexture): Boolean {
                                                mediaPlayer?.release()
                                                mediaPlayer = null
                                                return true
                                            }
                                            override fun onSurfaceTextureUpdated(st: android.graphics.SurfaceTexture) {}
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        } else if (primaryFrame != null) {
                            Image(
                                bitmap = primaryFrame!!.asImageBitmap(),
                                contentDescription = "Selected Video Frame",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        // Built-in interactive pitch backdrop when no device video selected yet
                        Image(
                            painter = painterResource(id = R.drawable.img_drs_pitch_banner),
                            contentDescription = "Sample Pitch Reference Canvas",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Text(
                            text = "Upload or record a delivery clip above (or practice drawing lines here)",
                            style = MaterialTheme.typography.labelSmall,
                            color = PitchGreen,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .background(NavyBase.copy(alpha = 0.75f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    // Annotation Drawing Canvas
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(drawMode, selectedColorHex) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        if (drawMode == "LINE") {
                                            val norm = Offset(
                                                (offset.x / size.width).coerceIn(0f, 1f),
                                                (offset.y / size.height).coerceIn(0f, 1f)
                                            )
                                            dragStartNorm = norm
                                            dragEndNorm = norm
                                        } else if (drawMode == "MARKER") {
                                            val norm = Offset(
                                                (offset.x / size.width).coerceIn(0f, 1f),
                                                (offset.y / size.height).coerceIn(0f, 1f)
                                            )
                                            annotations.add(
                                                DrsAnnotationItem(
                                                    type = "MARKER",
                                                    x1 = norm.x,
                                                    y1 = norm.y,
                                                    colorHex = selectedColorHex
                                                )
                                            )
                                        }
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        if (drawMode == "PAN") {
                                            panOffset += dragAmount
                                        } else if (drawMode == "LINE") {
                                            dragEndNorm = Offset(
                                                (change.position.x / size.width).coerceIn(0f, 1f),
                                                (change.position.y / size.height).coerceIn(0f, 1f)
                                            )
                                        }
                                    },
                                    onDragEnd = {
                                        val s = dragStartNorm
                                        val e = dragEndNorm
                                        if (drawMode == "LINE" && s != null && e != null) {
                                            annotations.add(
                                                DrsAnnotationItem(
                                                    type = "LINE",
                                                    x1 = s.x,
                                                    y1 = s.y,
                                                    x2 = e.x,
                                                    y2 = e.y,
                                                    colorHex = selectedColorHex
                                                )
                                            )
                                        }
                                        dragStartNorm = null
                                        dragEndNorm = null
                                    }
                                )
                            }
                    ) {
                        fun parseColor(hex: String): Color = when (hex) {
                            "#FFB300" -> BoundaryGold
                            "#FF5252" -> WicketCrimson
                            "#FFFFFF" -> Color.White
                            else -> PitchGreen
                        }
                        annotations.forEach { ann ->
                            val col = parseColor(ann.colorHex)
                            if (ann.type == "MARKER") {
                                drawCircle(
                                    color = col,
                                    radius = 8.dp.toPx(),
                                    center = Offset(ann.x1 * size.width, ann.y1 * size.height)
                                )
                            } else {
                                drawLine(
                                    color = col,
                                    start = Offset(ann.x1 * size.width, ann.y1 * size.height),
                                    end = Offset(ann.x2 * size.width, ann.y2 * size.height),
                                    strokeWidth = 3.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                        val s = dragStartNorm
                        val e = dragEndNorm
                        if (s != null && e != null) {
                            drawLine(
                                color = parseColor(selectedColorHex),
                                start = Offset(s.x * size.width, s.y * size.height),
                                end = Offset(e.x * size.width, e.y * size.height),
                                strokeWidth = 3.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }
            }
        }

        // Playback, Speed, Frame-by-Frame & Compare Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Time: ${currentPosMs}ms / ${durationMs}ms",
                            style = MaterialTheme.typography.labelMedium,
                            color = PitchGreen
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0.25f, 0.5f, 1.0f, 1.5f).forEach { spd ->
                                FilterChip(
                                    selected = playbackSpeed == spd,
                                    onClick = { playbackSpeed = spd },
                                    label = { Text("${spd}x") }
                                )
                            }
                        }
                    }

                    if (durationMs > 0L) {
                        Slider(
                            value = currentPosMs.toFloat(),
                            onValueChange = {
                                isPlaying = false
                                currentPosMs = it.toLong()
                            },
                            valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(thumbColor = PitchGreen, activeTrackColor = PitchGreen)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            isPlaying = false
                            currentPosMs = (currentPosMs - 100L).coerceAtLeast(0L)
                        }) {
                            Icon(Icons.Filled.FastRewind, contentDescription = "-100ms", tint = Color.White)
                        }
                        OutlinedButton(onClick = {
                            isPlaying = false
                            currentPosMs = (currentPosMs - 33L).coerceAtLeast(0L)
                        }) {
                            Text("-1F", color = SkyInfo)
                        }
                        Button(
                            onClick = {
                                if (selectedVideoUri != null) {
                                    isPlaying = !isPlaying
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase)
                        ) {
                            Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play or Pause")
                        }
                        OutlinedButton(onClick = {
                            isPlaying = false
                            currentPosMs = (currentPosMs + 33L).coerceAtMost(durationMs.coerceAtLeast(1000L))
                        }) {
                            Text("+1F", color = SkyInfo)
                        }
                        IconButton(onClick = {
                            isPlaying = false
                            currentPosMs = (currentPosMs + 100L).coerceAtMost(durationMs.coerceAtLeast(1000L))
                        }) {
                            Icon(Icons.Filled.FastForward, contentDescription = "+100ms", tint = Color.White)
                        }
                    }

                    // Zoom & Drawing Tools
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Zoom ${String.format("%.1fx", zoomScale)}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                        Slider(
                            value = zoomScale,
                            onValueChange = { zoomScale = it },
                            valueRange = 1f..4f,
                            modifier = Modifier.weight(1f)
                        )
                        if (zoomScale > 1f || panOffset != Offset.Zero) {
                            TextButton(onClick = { zoomScale = 1f; panOffset = Offset.Zero }) {
                                Text("Reset", color = SkyInfo)
                            }
                        }
                    }

                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = drawMode == "LINE", onClick = { drawMode = "LINE" }, label = { Text("Draw Line") })
                        FilterChip(selected = drawMode == "MARKER", onClick = { drawMode = "MARKER" }, label = { Text("Mark Point") })
                        FilterChip(selected = drawMode == "PAN", onClick = { drawMode = "PAN" }, label = { Text("Pan Zoom") })
                        FilterChip(selected = selectedColorHex == "#00E676", onClick = { selectedColorHex = "#00E676" }, label = { Text("Green") })
                        FilterChip(selected = selectedColorHex == "#FFB300", onClick = { selectedColorHex = "#FFB300" }, label = { Text("Gold") })
                        FilterChip(selected = selectedColorHex == "#FF5252", onClick = { selectedColorHex = "#FF5252" }, label = { Text("Red") })
                        IconButton(onClick = { if (annotations.isNotEmpty()) annotations.removeAt(annotations.lastIndex) }) {
                            Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo line", tint = BoundaryGold)
                        }
                        IconButton(onClick = { annotations.clear() }) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear annotations", tint = WicketCrimson)
                        }
                    }

                    // Compare Two Frames Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                comparePosMs = currentPosMs
                                showCompareMode = true
                            },
                            border = androidx.compose.foundation.BorderStroke(1.dp, BoundaryGold),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Compare, contentDescription = null, tint = BoundaryGold, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Lock Frame B (${comparePosMs}ms)", color = BoundaryGold)
                        }
                        if (showCompareMode) {
                            TextButton(onClick = { showCompareMode = false }) { Text("Hide Compare") }
                        }
                    }

                    if (showCompareMode) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Frame A (${currentPosMs}ms)", style = MaterialTheme.typography.labelSmall, color = PitchGreen)
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(16f / 9f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(NavyElevated)
                                ) {
                                    if (primaryFrame != null) {
                                        Image(bitmap = primaryFrame!!.asImageBitmap(), contentDescription = "Frame A", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                    }
                                }
                            }
                            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Frame B (${comparePosMs}ms)", style = MaterialTheme.typography.labelSmall, color = BoundaryGold)
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(16f / 9f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(NavyElevated)
                                ) {
                                    if (compareFrame != null) {
                                        Image(bitmap = compareFrame!!.asImageBitmap(), contentDescription = "Frame B", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Review Decision & Metadata Form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCard),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Review Decision Record", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = matchTitle, onValueChange = { matchTitle = it }, label = { Text("Match") }, singleLine = true, modifier = Modifier.weight(1.4f))
                        OutlinedTextField(value = overBallLabel, onValueChange = { overBallLabel = it }, label = { Text("Over.Ball") }, singleLine = true, modifier = Modifier.weight(0.6f))
                    }

                    Text("Review Category", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DrsCategory.entries.forEach { c ->
                            FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c.label) })
                        }
                    }

                    Text("Umpire's Original Decision", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        UmpireDecision.entries.forEach { d ->
                            FilterChip(selected = umpireDecision == d, onClick = { umpireDecision = d }, label = { Text(d.label) })
                        }
                    }

                    Text("Final Review Outcome", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DrsOutcome.entries.forEach { o ->
                            FilterChip(selected = finalOutcome == o, onClick = { finalOutcome = o }, label = { Text(o.label) })
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Official Review Notes") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            onSaveReview(
                                DrsReview(
                                    matchTitle = matchTitle.ifBlank { "Club Match Review" },
                                    overBallLabel = overBallLabel.ifBlank { "0.1" },
                                    category = category.name,
                                    videoUri = selectedVideoUri?.toString().orEmpty().take(500),
                                    umpireDecision = umpireDecision.name,
                                    finalOutcome = finalOutcome.name,
                                    notes = notes,
                                    primaryTimestampMs = currentPosMs,
                                    compareTimestampMs = comparePosMs,
                                    annotations = annotations.map { it.toMap() }
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PitchGreen, contentColor = NavyBase),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("drs_save_review_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Save DRS Review Clip", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (savedReviews.isNotEmpty()) {
            item {
                Text("Saved DRS Reviews", style = MaterialTheme.typography.titleMedium, color = Color.White)
            }
            items(savedReviews, key = { it.id }) { rev ->
                Surface(
                    color = NavyCard,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NavyOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${rev.matchTitle} (${rev.overBallLabel})", style = MaterialTheme.typography.titleSmall, color = Color.White)
                            StatusPill(rev.parsedCategory.label, SkyInfo, NavyElevated)
                        }
                        Text(
                            text = "On-field: ${rev.parsedUmpireDecision.label} → Outcome: ${rev.parsedOutcome.label}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PitchGreen
                        )
                        if (rev.notes.isNotBlank()) {
                            Text(rev.notes, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
