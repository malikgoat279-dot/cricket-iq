package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyDeep = Color(0xFF070E1B)
val NavyBase = Color(0xFF091224)
val NavySurface = Color(0xFF101D36)
val NavyCard = Color(0xFF162746)
val NavyElevated = Color(0xFF1E345B)
val NavyOutline = Color(0xFF2B4572)

val PitchGreen = Color(0xFF00E676)
val PitchGreenDark = Color(0xFF00B85C)
val PitchGreenMuted = Color(0xFF0D3D2D)

val BoundaryGold = Color(0xFFFFB300)
val BoundaryGoldBg = Color(0xFF3A2A08)
val WicketCrimson = Color(0xFFFF5252)
val WicketCrimsonBg = Color(0xFF42151C)
val SkyInfo = Color(0xFF38BDF8)
val SkyInfoBg = Color(0xFF0F2F47)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB4C3DA)
val TextMuted = Color(0xFF7B8FAD)
