package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.UiState
import com.example.data.remote.CricketIqRepository
import com.example.ui.screens.DrsReviewScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LiveScoresScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScoreMatchScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.screens.TeamsHubScreen
import com.example.ui.theme.CricketIqTheme
import com.example.ui.theme.NavyBase
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.PitchGreen
import com.example.ui.theme.PitchGreenMuted
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WicketCrimson
import com.example.ui.theme.WicketCrimsonBg
import com.example.ui.viewmodel.CricketIqViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private enum class MainTab(
    val label: String,
    val icon: ImageVector,
    val tag: String
) {
    HOME("Home", Icons.Filled.Home, "nav_home"),
    LIVE("Live", Icons.Filled.LiveTv, "nav_live"),
    SCORE("Score", Icons.Filled.SportsCricket, "nav_score"),
    TEAMS("Teams", Icons.Filled.Groups, "nav_teams"),
    STATS("Stats", Icons.Filled.Analytics, "nav_stats"),
    PROFILE("Profile", Icons.Filled.Person, "nav_profile")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CricketIqTheme {
                CricketIqRoot()
            }
        }
    }
}

@Composable
private fun CricketIqRoot() {
    val auth = remember { Firebase.auth }
    var currentUser by remember { mutableStateOf(auth.currentUser) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            currentUser = firebaseAuth.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    val signedInUid = currentUser?.uid
    key(signedInUid ?: "guest_local") {
        CricketIqAppShell(
            authenticatedUserId = signedInUid,
            onAuthChanged = { currentUser = Firebase.auth.currentUser }
        )
    }
}

@Composable
private fun CricketIqAppShell(
    authenticatedUserId: String?,
    onAuthChanged: () -> Unit
) {
    val isGuestMode = authenticatedUserId == null
    val vm: CricketIqViewModel = viewModel(
        key = authenticatedUserId ?: "guest_local",
        factory = viewModelFactory {
            initializer {
                if (authenticatedUserId == null) {
                    CricketIqViewModel(
                        repository = null,
                        authenticatedUserId = null
                    )
                } else {
                    val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY])
                    val dbId = app.getString(R.string.firestore_database_id)
                    val firestore = FirebaseFirestore.getInstance(dbId)
                    CricketIqViewModel(
                        repository = CricketIqRepository(firestore),
                        authenticatedUserId = authenticatedUserId
                    )
                }
            }
        }
    )

    val userProfileState by vm.userProfile.collectAsStateWithLifecycle()
    val myMatchesState by vm.myMatches.collectAsStateWithLifecycle()
    val publicMatchesState by vm.publicSharedMatches.collectAsStateWithLifecycle()
    val teamsState by vm.teams.collectAsStateWithLifecycle()
    val playersState by vm.players.collectAsStateWithLifecycle()
    val tournamentsState by vm.tournaments.collectAsStateWithLifecycle()
    val drsReviewsState by vm.drsReviews.collectAsStateWithLifecycle()

    val activeScoringMatch by vm.activeScoringMatch.collectAsStateWithLifecycle()
    val activeScoringDeliveries by vm.activeScoringDeliveries.collectAsStateWithLifecycle()
    val activeEngineState by vm.activeEngineState.collectAsStateWithLifecycle()
    val selectedLiveMatch by vm.selectedLiveMatch.collectAsStateWithLifecycle()
    val selectedLiveDeliveries by vm.selectedLiveDeliveries.collectAsStateWithLifecycle()
    val toastMessage by vm.toastMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            vm.clearToast()
        }
    }

    var selectedTab by remember { mutableStateOf(MainTab.HOME) }
    var showDrsStudio by remember { mutableStateOf(false) }
    var drsInitialMatchTitle by remember { mutableStateOf("") }
    var drsInitialOverBall by remember { mutableStateOf("") }

    if (!showDrsStudio && selectedTab != MainTab.HOME) {
        BackHandler {
            selectedTab = MainTab.HOME
        }
    }

    val userProfile = (userProfileState as? UiState.Success)?.data
    val myMatches = (myMatchesState as? UiState.Success)?.data.orEmpty()
    val publicMatches = (publicMatchesState as? UiState.Success)?.data.orEmpty()
    val teams = (teamsState as? UiState.Success)?.data.orEmpty()
    val players = (playersState as? UiState.Success)?.data.orEmpty()
    val tournaments = (tournamentsState as? UiState.Success)?.data.orEmpty()
    val drsReviews = (drsReviewsState as? UiState.Success)?.data.orEmpty()

    val isLoading = listOf(
        userProfileState,
        myMatchesState,
        teamsState,
        playersState
    ).any { it is UiState.Loading }

    val firstError = listOf(
        userProfileState,
        myMatchesState,
        publicMatchesState,
        teamsState,
        playersState,
        tournamentsState,
        drsReviewsState
    ).filterIsInstance<UiState.Error>().firstOrNull()?.message

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyBase)
    ) {
        val isWideScreen = maxWidth >= 600.dp

        Scaffold(
            containerColor = NavyBase,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = NavyElevated,
                        contentColor = Color.White,
                        actionColor = PitchGreen
                    )
                }
            },
            bottomBar = {
                if (!isWideScreen && !showDrsStudio) {
                    NavigationBar(
                        containerColor = NavyCard,
                        tonalElevation = 0.dp
                    ) {
                        MainTab.entries.forEach { tab ->
                            NavigationBarItem(
                                selected = selectedTab == tab,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.size(22.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = PitchGreen,
                                    selectedTextColor = PitchGreen,
                                    indicatorColor = PitchGreenMuted,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                ),
                                modifier = Modifier.testTag(tab.tag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isWideScreen && !showDrsStudio) {
                    NavigationRail(
                        containerColor = NavyCard,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "CIQ",
                                style = MaterialTheme.typography.titleMedium,
                                color = PitchGreen,
                                fontWeight = FontWeight.Bold
                            )
                            MainTab.entries.forEach { tab ->
                                NavigationRailItem(
                                    selected = selectedTab == tab,
                                    onClick = { selectedTab = tab },
                                    icon = {
                                        Icon(tab.icon, contentDescription = tab.label)
                                    },
                                    label = {
                                        Text(tab.label, maxLines = 1)
                                    },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = PitchGreen,
                                        selectedTextColor = PitchGreen,
                                        indicatorColor = PitchGreenMuted,
                                        unselectedIconColor = TextMuted,
                                        unselectedTextColor = TextMuted
                                    ),
                                    modifier = Modifier.testTag(tab.tag)
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 1000.dp)
                    ) {
                        if (isLoading) {
                            LinearProgressIndicator(
                                color = PitchGreen,
                                trackColor = NavyCard,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (firstError != null) {
                            Surface(
                                color = WicketCrimsonBg,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "Sync warning: $firstError",
                                    color = WicketCrimson,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        if (showDrsStudio) {
                            DrsReviewScreen(
                                initialMatchTitle = drsInitialMatchTitle,
                                initialOverBall = drsInitialOverBall,
                                savedReviews = drsReviews,
                                onSaveReview = { review -> vm.saveDrsReview(review) },
                                onBack = { showDrsStudio = false }
                            )
                        } else {
                            when (selectedTab) {
                                MainTab.HOME -> HomeScreen(
                                    isGuestMode = isGuestMode,
                                    userProfile = userProfile,
                                    myMatches = myMatches,
                                    teams = teams,
                                    players = players,
                                    tournaments = tournaments,
                                    onStartNewMatch = {
                                        vm.clearActiveScoringSelection()
                                        selectedTab = MainTab.SCORE
                                    },
                                    onContinueMatch = { match ->
                                        vm.openMatchForScoring(match, emptyList())
                                        selectedTab = MainTab.SCORE
                                    },
                                    onOpenLiveMatch = { match ->
                                        vm.selectLiveMatch(match.id)
                                        selectedTab = MainTab.LIVE
                                    },
                                    onOpenTeams = { selectedTab = MainTab.TEAMS },
                                    onOpenDrsReview = {
                                        drsInitialMatchTitle = ""
                                        drsInitialOverBall = ""
                                        showDrsStudio = true
                                    },
                                    onLoadDemoData = { vm.loadDemoClubData() },
                                    onOpenProfileSignIn = { selectedTab = MainTab.PROFILE }
                                )

                                MainTab.LIVE -> LiveScoresScreen(
                                    myMatches = myMatches,
                                    publicMatches = publicMatches,
                                    selectedMatch = selectedLiveMatch,
                                    selectedMatchDeliveries = selectedLiveDeliveries,
                                    currentUserId = vm.effectiveUserId,
                                    onSelectMatch = { match -> vm.selectLiveMatch(match.id) },
                                    onClearSelection = { vm.selectLiveMatch("") },
                                    onJoinByCode = { code ->
                                        vm.joinMatchByShareCode(code) { }
                                    },
                                    onResumeScoring = { match ->
                                        vm.openMatchForScoring(match, selectedLiveDeliveries)
                                        selectedTab = MainTab.SCORE
                                    },
                                    onTogglePublicShare = { match -> vm.togglePublicShare(match) }
                                )

                                MainTab.SCORE -> ScoreMatchScreen(
                                    activeMatch = activeScoringMatch,
                                    activeDeliveries = activeScoringDeliveries,
                                    engineState = activeEngineState,
                                    myMatches = myMatches,
                                    teams = teams,
                                    onStartNewMatch = { format, oversLimit, playersPerSide, maxOversPerBowler, teamAName, teamBName, venue, tossWinner, tossDecision, striker, nonStriker, bowler, teamAPlayers, teamBPlayers, publicShared ->
                                        vm.startNewMatch(
                                            format = format,
                                            oversLimit = oversLimit,
                                            playersPerSide = playersPerSide,
                                            maxOversPerBowler = maxOversPerBowler,
                                            teamAName = teamAName,
                                            teamBName = teamBName,
                                            venue = venue,
                                            tossWinnerName = tossWinner,
                                            tossDecision = tossDecision,
                                            strikerName = striker,
                                            nonStrikerName = nonStriker,
                                            bowlerName = bowler,
                                            teamAPlayers = teamAPlayers,
                                            teamBPlayers = teamBPlayers,
                                            publicShared = publicShared,
                                            onCreated = { }
                                        )
                                    },
                                    onResumeMatch = { match ->
                                        vm.openMatchForScoring(match, emptyList())
                                    },
                                    onSyncSnapshot = { match, deliveries ->
                                        vm.syncEngineWithSnapshot(match, deliveries)
                                    },
                                    onRecordBall = { match, input ->
                                        vm.recordBall(match, input)
                                    },
                                    onUndoBall = { match, deliveries ->
                                        vm.undoLastBall(match, deliveries)
                                    },
                                    onChangeBowler = { bowlerName ->
                                        vm.changeBowler(bowlerName)
                                    },
                                    onSwapStrike = { vm.swapStrike() },
                                    onSetNextBatter = { batterName ->
                                        vm.setNextBatter(batterName)
                                    },
                                    onEndInnings = { match ->
                                        vm.endCurrentInnings(match)
                                    },
                                    onStartSecondInnings = { match, s1, s2, b1 ->
                                        vm.startSecondInnings(match, s1, s2, b1)
                                    },
                                    onCloseActiveScoring = {
                                        vm.clearActiveScoringSelection()
                                    },
                                    onOpenDrsForBall = { title, overBall ->
                                        drsInitialMatchTitle = title
                                        drsInitialOverBall = overBall
                                        showDrsStudio = true
                                    }
                                )

                                MainTab.TEAMS -> TeamsHubScreen(
                                    teams = teams,
                                    players = players,
                                    tournaments = tournaments,
                                    onCreateTeam = { name, shortName ->
                                        vm.createTeam(name, shortName)
                                    },
                                    onUpdateTeamLineup = { team, captainId, wkId, xiIds, subIds ->
                                        vm.updateTeamLineup(team, captainId, wkId, xiIds, subIds)
                                    },
                                    onCreatePlayer = { name, teamId, teamName, role, batStyle, bowlStyle ->
                                        vm.createPlayer(name, teamId, teamName, role, batStyle, bowlStyle)
                                    },
                                    onCreateTournament = { name, format, oversLimit, type, teamNames ->
                                        vm.createTournament(name, format, oversLimit, type, teamNames)
                                    },
                                    onRecordFixtureResult = { tour, fixtureId, scoreA, ballsA, scoreB, ballsB ->
                                        vm.recordFixtureResult(tour, fixtureId, scoreA, ballsA, scoreB, ballsB)
                                    }
                                )

                                MainTab.STATS -> StatisticsScreen(
                                    userProfile = userProfile,
                                    players = players,
                                    teams = teams,
                                    matches = myMatches,
                                    onOpenDrsReview = {
                                        drsInitialMatchTitle = ""
                                        drsInitialOverBall = ""
                                        showDrsStudio = true
                                    },
                                    onOpenSubscriptionPage = {
                                        selectedTab = MainTab.PROFILE
                                    }
                                )

                                MainTab.PROFILE -> ProfileScreen(
                                    isGuestMode = isGuestMode,
                                    userProfile = userProfile,
                                    onUpdateProfile = { name, role, club ->
                                        vm.updateProfile(name, role, club)
                                    },
                                    onSelectSubscriptionPreview = { tier, status ->
                                        vm.selectSubscriptionPreview(tier, status)
                                    },
                                    onLoadDemoData = { vm.loadDemoClubData() },
                                    onSignInSuccess = onAuthChanged,
                                    onSignedOut = onAuthChanged
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
