package com.example

import com.example.domain.scoring.CricketScoringEngine
import com.example.domain.scoring.DeliveryInput
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.MatchFormat
import com.example.domain.scoring.WicketType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CricketScoringEngineTest {

    @Test
    fun `runs and odd-run strike rotation work accurately`() {
        val engine = CricketScoringEngine(
            format = MatchFormat.T20,
            initialStriker = "A. Khan",
            initialNonStriker = "R. Patel",
            initialBowler = "J. Smith"
        )

        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 0)).isSuccess)
        assertEquals("A. Khan", engine.getState().activeInnings.strikerName)

        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 1)).isSuccess)
        assertEquals("R. Patel", engine.getState().activeInnings.strikerName)

        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 4)).isSuccess)
        assertEquals("R. Patel", engine.getState().activeInnings.strikerName)

        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 3)).isSuccess)
        assertEquals("A. Khan", engine.getState().activeInnings.strikerName)

        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 6)).isSuccess)
        val inn = engine.getState().activeInnings
        assertEquals(14, inn.totalRuns)
        assertEquals(5, inn.legalBalls)
        assertEquals("0.5", inn.oversString)
    }

    @Test
    fun `no-balls and wides do not count towards over totals and enforce dismissal rules`() {
        val engine = CricketScoringEngine(
            format = MatchFormat.T20,
            initialStriker = "Opener 1",
            initialNonStriker = "Opener 2",
            initialBowler = "Bowler 1"
        )

        val nb = engine.recordDelivery(DeliveryInput(batterRuns = 4, extraType = ExtraType.NO_BALL))
        assertTrue(nb.isSuccess)
        var inn = engine.getState().activeInnings
        assertEquals(5, inn.totalRuns)
        assertEquals(0, inn.legalBalls)
        assertEquals(1, inn.extras.noBalls)
        assertEquals(1, inn.batters.first().ballsFaced)

        val wd = engine.recordDelivery(DeliveryInput(extraType = ExtraType.WIDE, additionalExtraRuns = 1))
        assertTrue(wd.isSuccess)
        inn = engine.getState().activeInnings
        assertEquals(7, inn.totalRuns)
        assertEquals(0, inn.legalBalls)
        assertEquals(2, inn.extras.wides)
        assertEquals("Opener 2", inn.strikerName)

        assertTrue(engine.recordDelivery(DeliveryInput(extraType = ExtraType.NO_BALL, wicketType = WicketType.BOWLED)).isFailure)
        assertTrue(engine.recordDelivery(DeliveryInput(extraType = ExtraType.NO_BALL, wicketType = WicketType.CAUGHT)).isFailure)
        assertTrue(engine.recordDelivery(DeliveryInput(extraType = ExtraType.NO_BALL, wicketType = WicketType.LBW)).isFailure)

        val runOutOnNb = engine.recordDelivery(
            DeliveryInput(
                batterRuns = 1,
                extraType = ExtraType.NO_BALL,
                wicketType = WicketType.RUN_OUT,
                dismissedBatterName = "Opener 1",
                nextBatterName = "Number 3"
            )
        )
        assertTrue(runOutOnNb.isSuccess)
        assertEquals(0, engine.getState().activeInnings.legalBalls)
        assertEquals(1, engine.getState().activeInnings.wickets)
        assertEquals(0, engine.getState().activeInnings.bowlers.first().wickets)
    }

    @Test
    fun `over-end rotates strike and enforces consecutive over bowler restriction`() {
        val engine = CricketScoringEngine(
            format = MatchFormat.T10,
            initialStriker = "Batter A",
            initialNonStriker = "Batter B",
            initialBowler = "Bowler 1"
        )

        repeat(5) { assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 0)).isSuccess) }
        assertTrue(engine.recordDelivery(DeliveryInput(batterRuns = 1)).isSuccess)

        val inn = engine.getState().activeInnings
        assertEquals("1.0", inn.oversString)
        assertEquals("Batter A", inn.strikerName)
        assertTrue(inn.needsBowlerChange)
        assertTrue(engine.setBowler("Bowler 1").isFailure)
        assertTrue(engine.setBowler("Bowler 2").isSuccess)
    }

    @Test
    fun `byes leg-byes penalties partnerships undo and NRR reconcile accurately`() {
        val engine = CricketScoringEngine(
            format = MatchFormat.T10,
            oversLimit = 2,
            maxOversPerBowler = 1,
            teamAName = "Alpha",
            teamBName = "Beta",
            initialStriker = "Virat",
            initialNonStriker = "Rohit",
            initialBowler = "Starc"
        )

        engine.recordDelivery(DeliveryInput(batterRuns = 4))
        engine.recordDelivery(DeliveryInput(extraType = ExtraType.BYE, additionalExtraRuns = 1))
        assertEquals(0, engine.getState().activeInnings.bowlers.first().runsConceded - 4)
        engine.recordDelivery(
            DeliveryInput(
                wicketType = WicketType.CAUGHT,
                dismissedBatterName = "Rohit",
                fielderName = "Carey",
                nextBatterName = "Gill"
            )
        )

        val inn = engine.getState().activeInnings
        assertEquals(2, inn.partnerships.size)
        assertEquals(5, inn.partnerships[0].runs)
        assertEquals(3, inn.partnerships[0].balls)
        assertFalse(inn.partnerships[0].active)
        assertEquals(1, inn.fallOfWickets.size)

        engine.undoLastDelivery()
        assertEquals(0, engine.getState().activeInnings.wickets)
        assertEquals(1.0, CricketScoringEngine.calculateNrr(120, 120, 100, 120), 0.001)
    }
}
