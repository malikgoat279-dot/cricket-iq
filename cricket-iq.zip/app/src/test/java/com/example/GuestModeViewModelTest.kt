package com.example

import com.example.data.model.PlayerRole
import com.example.data.model.SubscriptionTier
import com.example.data.model.UiState
import com.example.domain.scoring.DeliveryInput
import com.example.domain.scoring.ExtraType
import com.example.domain.scoring.MatchFormat
import com.example.ui.viewmodel.CricketIqViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class GuestModeViewModelTest {

    private val testDispatcher = UnconfinedTestDispatcher()

    @Before
    fun setup() {
        Dispatchers.setMain(testDispatcher)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `guest mode initializes immediately with clearly labelled demo data and supports interactive scoring`() = runTest {
        val vm = CricketIqViewModel(repository = null, authenticatedUserId = null)
        assertTrue(vm.isGuestMode)

        val matches = (vm.myMatches.value as UiState.Success).data
        val teams = (vm.teams.value as UiState.Success).data
        val players = (vm.players.value as UiState.Success).data
        val tournaments = (vm.tournaments.value as UiState.Success).data
        val drs = (vm.drsReviews.value as UiState.Success).data

        assertTrue(matches.any { it.demoData && it.status == "LIVE" })
        assertTrue(matches.any { it.demoData && it.status == "COMPLETED" })
        assertTrue(teams.size >= 2 && teams.all { it.demoData })
        assertTrue(players.size >= 6 && players.all { it.demoData })
        assertTrue(tournaments.isNotEmpty() && tournaments.all { it.demoData })
        assertTrue(drs.isNotEmpty())

        // Create a new match in Guest Mode and score a ball + undo
        var createdId = ""
        vm.startNewMatch(
            format = MatchFormat.T10,
            oversLimit = 10,
            playersPerSide = 11,
            maxOversPerBowler = 2,
            teamAName = "Guest Strikers",
            teamBName = "Park XI",
            venue = "Local Oval",
            tossWinnerName = "Guest Strikers",
            tossDecision = "BAT",
            strikerName = "Opener 1",
            nonStrikerName = "Opener 2",
            bowlerName = "Bowler 1",
            teamAPlayers = listOf("Opener 1", "Opener 2"),
            teamBPlayers = listOf("Bowler 1"),
            publicShared = false,
            onCreated = { createdId = it }
        )
        assertTrue(createdId.isNotBlank())
        val match = (vm.myMatches.value as UiState.Success).data.first { it.id == createdId }
        vm.recordBall(match, DeliveryInput(batterRuns = 6))
        vm.recordBall(match, DeliveryInput(extraType = ExtraType.NO_BALL, batterRuns = 1))
        assertEquals(8, vm.activeEngineState.value?.activeInnings?.totalRuns)
        assertEquals(1, vm.activeEngineState.value?.activeInnings?.legalBalls)

        vm.undoLastBall(match, emptyList())
        assertEquals(6, vm.activeEngineState.value?.activeInnings?.totalRuns)

        // Create team & player in Guest Mode
        vm.createTeam("Village CC", "VCC")
        vm.createPlayer("Sam Taylor", "", "Village CC", PlayerRole.ALL_ROUNDER, "Right-hand bat", "Right-arm medium")
        assertTrue((vm.teams.value as UiState.Success).data.any { it.name == "Village CC" })
        assertTrue((vm.players.value as UiState.Success).data.any { it.name == "Sam Taylor" })

        // Preview subscription locally
        vm.selectSubscriptionPreview(SubscriptionTier.CLUB_PRO)
        val profile = (vm.userProfile.value as UiState.Success).data
        assertNotNull(profile)
        assertEquals(SubscriptionTier.CLUB_PRO, profile?.parsedTier)

        // Protected cloud share prompts sign-in instead of failing silently
        vm.togglePublicShare(match)
        assertFalse(match.publicShared)
        assertTrue(vm.toastMessage.value?.contains("Sign in", ignoreCase = true) == true)
    }
}
