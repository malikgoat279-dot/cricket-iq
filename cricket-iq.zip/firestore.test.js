const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validUserPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    displayName: "Alice Khan",
    email: "alice@cricketiq.test",
    role: "SCORER",
    clubName: "Royal Challengers Club",
    subscriptionTier: "FREE",
    subscriptionMode: "FREE",
    subscriptionStatus: "ACTIVE",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validMatchPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    controllerUids: [uid],
    publicShared: false,
    shareCode: "CIQ842",
    format: "T20",
    oversLimit: 20,
    playersPerSide: 11,
    maxOversPerBowler: 4,
    teamAId: "team_a",
    teamAName: "Northwood XI",
    teamAShort: "NWX",
    teamBId: "team_b",
    teamBName: "Surrey Strikers",
    teamBShort: "SRS",
    venue: "Lord's Nursery Ground",
    status: "LIVE",
    tossWinnerName: "Northwood XI",
    tossDecision: "BAT",
    currentInnings: 1,
    battingTeamName: "Northwood XI",
    bowlingTeamName: "Surrey Strikers",
    totalRuns: 0,
    wickets: 0,
    legalBalls: 0,
    targetRuns: 0,
    strikerName: "A. Khan",
    nonStrikerName: "R. Patel",
    bowlerName: "J. Smith",
    recentBalls: [],
    inningsSummaries: [],
    resultSummary: "",
    winnerTeamName: "",
    teamAPlayerNames: ["A. Khan", "R. Patel"],
    teamBPlayerNames: ["J. Smith", "T. Ali"],
    demoData: false,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function validDeliveryPayload(uid, matchId, overrides = {}) {
  return {
    userId: uid,
    controllerUids: [uid],
    publicShared: false,
    matchId,
    sequenceNumber: 1,
    inningsNumber: 1,
    overNumber: 0,
    ballNumber: 1,
    legalDelivery: true,
    strikerId: "p1",
    strikerName: "A. Khan",
    nonStrikerId: "p2",
    nonStrikerName: "R. Patel",
    bowlerId: "p3",
    bowlerName: "J. Smith",
    batterRuns: 4,
    extraType: "NONE",
    extraRuns: 0,
    totalRunsOnBall: 4,
    wicketType: "NONE",
    dismissedPlayerId: "",
    dismissedPlayerName: "",
    fielderName: "",
    createdAt: new Date(Date.now() - 1000),
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated users are denied across all collections", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("matches").where("publicShared", "==", true).get());
  await assertFails(unauth.collection("teams").where("userId", "==", ALICE_UID).get());
  await assertFails(unauth.collection("players").where("userId", "==", ALICE_UID).get());
  await assertFails(unauth.collection("tournaments").where("userId", "==", ALICE_UID).get());
  await assertFails(unauth.collection("drs_reviews").where("userId", "==", ALICE_UID).get());
});

test("User profile enforces strict owner PII isolation and rejects ghost fields / invalid mode", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validUserPayload(ALICE_UID))
  );

  // Partial update succeeds
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      role: "CLUB_ADMIN",
      subscriptionTier: "CLUB_PRO",
      subscriptionMode: "PREVIEW_SANDBOX",
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Bob cannot read or write Alice's PII
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).update({ role: "PLAYER" }));

  // Reject ghost field & future timestamp
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).set(validUserPayload(BOB_UID))
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      subscriptionMode: "STORE_VERIFIED",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      updatedAt: new Date(Date.now() + 60000),
    })
  );
});

test("Matches enforce controller ownership for writes, allow publicShared reads, and lock COMPLETED state", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

  await assertSucceeds(
    aliceDb.collection("matches").doc("match_1").set(validMatchPayload(ALICE_UID))
  );

  // Private match cannot be read or queried by Bob
  await assertFails(bobDb.collection("matches").doc("match_1").get());
  await assertFails(bobDb.collection("matches").get());

  // Bob cannot modify Alice's match
  await assertFails(
    bobDb.collection("matches").doc("match_1").update({
      totalRuns: 99,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Alice adds a delivery and shares match publicly
  await assertSucceeds(
    aliceDb
      .collection("matches")
      .doc("match_1")
      .collection("deliveries")
      .doc("del_1")
      .set(validDeliveryPayload(ALICE_UID, "match_1", { publicShared: false }))
  );

  // Alice can toggle publicShared on existing delivery
  await assertSucceeds(
    aliceDb
      .collection("matches")
      .doc("match_1")
      .collection("deliveries")
      .doc("del_1")
      .update({ publicShared: true })
  );

  // Alice cannot tamper with runs on an existing delivery; Bob cannot update delivery
  await assertFails(
    aliceDb
      .collection("matches")
      .doc("match_1")
      .collection("deliveries")
      .doc("del_1")
      .update({ batterRuns: 6, publicShared: true })
  );
  await assertFails(
    bobDb
      .collection("matches")
      .doc("match_1")
      .collection("deliveries")
      .doc("del_1")
      .update({ publicShared: false })
  );

  await assertSucceeds(
    aliceDb.collection("matches").doc("match_1").update({
      publicShared: true,
      totalRuns: 4,
      recentBalls: ["4"],
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Bob can now list publicShared matches & deliveries, but still cannot write
  await assertSucceeds(
    bobDb.collection("matches").where("publicShared", "==", true).get()
  );
  await assertSucceeds(
    bobDb
      .collection("matches")
      .doc("match_1")
      .collection("deliveries")
      .where("publicShared", "==", true)
      .get()
  );
  await assertFails(
    bobDb.collection("matches").doc("match_1").update({
      totalRuns: 10,
      updatedAt: new Date(Date.now() - 400),
    })
  );

  // Alice marks match COMPLETED -> further score edits blocked by terminal state lock
  await assertSucceeds(
    aliceDb.collection("matches").doc("match_1").update({
      status: "COMPLETED",
      resultSummary: "Northwood XI won by 15 runs",
      winnerTeamName: "Northwood XI",
      updatedAt: new Date(Date.now() - 300),
    })
  );

  await assertFails(
    aliceDb.collection("matches").doc("match_1").update({
      totalRuns: 100,
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Toggling publicShared on completed match still allowed
  await assertSucceeds(
    aliceDb.collection("matches").doc("match_1").update({
      publicShared: false,
      updatedAt: new Date(Date.now() - 100),
    })
  );
});

test("Teams, Players, Tournaments, and DRS Reviews enforce ownership and schema bounds", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    aliceDb.collection("teams").doc("team_1").set({
      userId: ALICE_UID,
      controllerUids: [ALICE_UID],
      memberUids: [ALICE_UID],
      name: "Northwood XI",
      shortName: "NWX",
      captainPlayerId: "p1",
      wicketkeeperPlayerId: "p2",
      playingXiIds: ["p1", "p2"],
      substituteIds: [],
      playerIds: ["p1", "p2"],
      inviteCode: "NWX2026",
      matchesPlayed: 0,
      wins: 0,
      losses: 0,
      ties: 0,
      netRunRate: 0.0,
      demoData: false,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    aliceDb.collection("teams").where("memberUids", "array-contains", ALICE_UID).get()
  );
  await assertFails(bobDb.collection("teams").doc("team_1").get());

  await assertSucceeds(
    aliceDb.collection("drs_reviews").doc("rev_1").set({
      userId: ALICE_UID,
      matchId: "match_1",
      deliveryId: "del_1",
      matchTitle: "Northwood XI vs Surrey Strikers",
      overBallLabel: "14.3",
      category: "LBW",
      videoUri: "content://media/video/123",
      umpireDecision: "NOT_OUT",
      finalOutcome: "OVERTURNED",
      notes: "Pitched in line, impact in line.",
      primaryTimestampMs: 1200,
      compareTimestampMs: 1350,
      annotations: [{ type: "LINE", x1: 0.2, y1: 0.3, x2: 0.5, y2: 0.7, colorHex: "#00E676" }],
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertFails(bobDb.collection("drs_reviews").doc("rev_1").get());
});
